import React from "react";
import Image from "next/image";
import RoboticsUsp from "@/components/robotics-automation/robotics-usp";

const AirMobilityHowWeHelpSection: React.FC = () => {
    return (
        <>
            <section className="pt-10 ">
                <div className="w-full  ">
                    <div>
                        <div className="grid md:grid-cols-2 gap-12 border-top">

                            {/* Left Image */}
                            <div className=" relative h-[400px]">
                                <Image
                                    src="/imgs/satellite-space-support.webp"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-center md:object-cover"
                                />
                            </div>

                            {/* Right Text Content */}
                            <div className="pt-10">
                                <h1 className="text-4xl font-bold text-gray-900">
                                    Precision Engineering for Mission-Critical Space Applications
                                </h1>

                                <p className="mt-4 text-gray-800">We provide space-grade precision machining, delivering components with tight tolerances to ensure orbital reliability. Our advanced materials include titanium, Inconel, carbon fiber, and ceramic composites, all engineered to perform in the extreme conditions of space. We support the entire manufacturing lifecycle, from prototyping to the production of flight-ready hardware, ensuring robust performance at every stage.</p>
                                <div className="mt-6 flex gap-4">

                                    <button
                                        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                        onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10894030-case-study-precision-engineered-titanium-brackets-for-a-leo-satellite-mission")}
                                    >
                                        Case Study
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <section>
                <RoboticsUsp />
            </section>
        </>
    );
};

export default AirMobilityHowWeHelpSection;




