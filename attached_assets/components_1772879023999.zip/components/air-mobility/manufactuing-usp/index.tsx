import React from 'react';

const ManufacturingUsp = () => {
    const items = [
        { icon: "gear", title: "CNC Machining", text: "5-axis milling, turning, tight tolerance parts" },
        { icon: "fill", title: "Additive Manufacturing", text: "Functional parts with SLS, MJF, SLA, DMLS" },
        { icon: "cubes", title: "Injection Molding", text: "Rapid molding for drone, aerospace applications" },
        { icon: "shield", title: "Post-Processing", text: "Finishing, painting, anodizing, and assembly" },
        { icon: "book", title: "Engineering Documentation", text: "FAI, inspections, certifications, and PPAP support" },
    ];


    return (
        <div className="mx-auto px-10 py-8">
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 justify-self-center lg:grid-cols-5 gap-6">
                {items.map((item, index) => (
                    <div key={index} className="flex flex-col items-center text-center md:text-start md:items-start space-y-3">
                        {/* Icon */}
                        <div className="flex justify-center  items-center w-16 h-16 bg-sky-100 rounded-full mb-4">
                            <i className={`fas fa-${item.icon} text-sky-500 text-3xl`} />
                        </div>

                        {/* Text Content */}
                        <div>
                            <p className="text-lg font-bold text-sky-500">{item.title}</p>
                            <p className="text-sm text-gray-600">{item.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ManufacturingUsp;
