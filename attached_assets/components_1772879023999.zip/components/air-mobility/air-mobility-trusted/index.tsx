'use client';
import React from "react";
import Slider from "react-slick";
import Image from "next/image";

interface RoboticIndustryImageCarouselProps { }

const AirMobilityIndustryImageCarousel: React.FC<RoboticIndustryImageCarouselProps> = () => {
    const settings = {
        dots: false, // Show navigation dots
        infinite: true, // Infinite looping
        speed: 4000, // Transition speed
        slidesToShow: 4, // Number of images visible at a time
        slidesToScroll: 1, // Number of images to scroll at a time
        autoplay: true, // Enable autoplay
        autoplaySpeed: 50, // Autoplay interval
        responsive: [
            {
                breakpoint: 768, // For smaller screens
                settings: {
                    slidesToShow: 1, // Show 1 image at a time
                },
            },
            {
                breakpoint: 1024, // For medium screens
                settings: {
                    slidesToShow: 2, // Show 2 images at a time
                },
            },
        ],
    };

    const images: string[] = [
        "/imgs/kuka.png",
        "/imgs/omron.png",
        "/imgs/ABB.png",
        "/imgs/honeywell-auto.png",
        "/imgs/universal-robots.png",
        "/imgs/rockwell-auto.png",
    ];

    return (
        <div className="mt-0 bg-white rounded-lg p-4">
            <p className="mt-8 mb-2 text-4xl font-bold text-gray-900 text-center">
                We Are a Trusted Partner for Global Aerospace  And Drones Companies
            </p>
        </div>


    );
};

export default AirMobilityIndustryImageCarousel;
