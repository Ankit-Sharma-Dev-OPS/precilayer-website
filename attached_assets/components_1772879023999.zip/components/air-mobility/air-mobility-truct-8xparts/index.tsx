import React from 'react';

const AirMobilityCompanyTrust8xPartsSection = () => {
    const items = [
        {
            icon: "jet-fighter-up",
            title: "Aerospace-Grade Quality",
            text: "Tight tolerances, premium materials, certified quality"
        },
        {
            icon: "bullseye",
            title: "Drone & eVTOL Ready Materials",
            text: "Carbon composites, PEEK, PEKK, ULTEM, aluminum"
        },
        {
            icon: "user-tie",
            title: "Agile Turnarounds",
            text: "Fast prototyping and production for flight"
        },
        {
            icon: "globe",
            title: "Made Outside China",
            text: "USA, India, EU network—zero China dependency"
        }
    ];


    return (
        <div className="mx-auto px-4 py-12 border-b">
            {/* Title Section */}
            <div className="text-center">
                <h2 className="text-4xl font-bold text-gray-900">Why Advanced Air Mobility companies choose 8X Parts</h2>
                <p className="mt-4 text-xl text-gray-600">Four Key Differentiators</p>
            </div>

            {/* Content Section */}
            <div className="mt-8 px-8 grid grid-cols-1 sm:grid-cols-2 justify-self-center md:grid-cols-4 gap-8">
                {items.map((item, index) => (
                    <div key={index} className="flex flex-col items-center text-center md:text-start md:items-start space-y-4">
                        {/* Icon */}
                        <div className="flex justify-center items-center w-16 h-16 bg-sky-100 rounded-full">
                            <i className={`fas fa-${item.icon} text-sky-500 text-3xl`} />
                        </div>

                        {/* Text Content */}
                        <div>
                            <p className="text-lg font-bold text-sky-500">{item.title}</p>
                            <p className="text-sm text-gray-600">{item.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AirMobilityCompanyTrust8xPartsSection;
