import React from "react";
import Image from "next/image";

interface PartsPost {
    title: string;
    icon: string;
    label: string;
}

const partsArray1: PartsPost[] = [
    {
        title: 'Rotor and impeller housings',
        icon: 'router-image.png',
        label: 'Precision parts for rotor and impeller systems',
    },
    {
        title: 'Battery trays and enclosures',
        icon: 'Battery-tray.png',
        label: 'Secure and durable battery housing solutions',
    },
];

const partsArray2: PartsPost[] = [
    {
        title: 'Flight control system brackets',
        icon: 'Flight-control.png',
        label: 'Support brackets for flight control components',
    },
    {
        title: 'Sensor & LiDAR mounts',
        icon: 'Sendor-mount.png',
        label: 'Mounting solutions for sensors and LiDAR units',
    },
    {
        title: 'Air duct and cooling parts',
        icon: 'air-duct-last.png',
        label: 'Components for airflow and thermal management',
    },
];


const AirMobilityPartWeManufacture: React.FC = () => {
    return (
        <section id="industries" className="bg-gray-50 pt-20 pb-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
                <div className="text-center">
                    <h2 className="text-4xl font-bold text-gray-900">Typical AAM Parts We Make</h2>
                    <p className="mt-4 text-xl text-gray-600">High-performance components for next-gen air mobility systems</p>
                </div>
                <div className="mt-16 grid md:grid-cols-2 gap-8">
                    {partsArray1.map((post) => (
                        <div key={post.title} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                            <Image src={`/imgs/${post.icon}`} width={200} height={200} className=" w-full h-[250px] mb-2" alt="" />
                            <h3 className="text-xl font-bold text-gray-900 flex">

                                <p className="flex items-center">{post.title}</p>
                            </h3>
                            <p className="mt-2 text-gray-600">{post.label}</p>
                        </div>
                    ))}
                </div>

                <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-start">
                    {partsArray2.map((post, index) => {
                        const isLastItem = index === partsArray2.length - 1;

                        return (
                            <div
                                key={post.title}
                                className={`bg-white rounded-lg p-6 h-[420px] shadow-sm hover:shadow-md transition-shadow 
        ${isLastItem ? "md:col-span-2 lg:col-span-1 md:w-[500px] md:mx-auto lg:w-full" : ""}`}
                            >
                                <Image
                                    src={`/imgs/${post.icon}`}
                                    width={200}
                                    height={200}
                                    className="w-full h-[250px] mb-2 object-contain"
                                    alt={post.title}
                                />
                                <h3 className="text-xl font-bold text-gray-900">
                                    <p className="flex items-center">{post.title}</p>
                                </h3>
                                <p className="mt-2 text-gray-600">{post.label}</p>
                            </div>
                        );
                    })}
                </div>
                    
            </div>

        </section>
    );
};

export default AirMobilityPartWeManufacture;


