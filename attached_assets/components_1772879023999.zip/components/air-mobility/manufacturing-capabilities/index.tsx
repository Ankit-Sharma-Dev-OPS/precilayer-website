import React, { forwardRef } from "react";
import Image from "next/image";
import ManufacturingUsp from "../../air-mobility/manufactuing-usp/index";

// Forward the ref to the section element
const AirMobilityManufacturingTechnologiesSection = forwardRef<HTMLDivElement, {}>((props, ref) => {
    return (
        <>
            <section ref={ref} className="pt-24">
                <div className="w-full mx-2 md:mx-0">
                    <div>

                        <div className="grid md:grid-cols-2 gap-12 border-top">

                            {/* Left Text Content */}
                            <div className=" md:pl-10 !mt-10">
                                <h1 className="text-2xl lg:text-4xl font-bold text-gray-900">
                                    Our Capabilities for AAM
                                </h1>

                                <p className="mt-4 ">We offer end-to-end manufacturing solutions tailored for aerospace and advanced mobility applications. Our CNC machining delivers flight-ready parts with ultra-tight tolerances, complex geometries, and high-end finishes. With additive manufacturing, we produce lightweight, functional components using SLS, MJF, SLA, and DMLS—ideal for housings, ducts, and enclosures. </p>
                                <p className="mt-4 ">Our rapid injection molding supports drones and eVTOL systems with engineering-grade polymers. We also provide post-processing services like painting, anodizing, and assembly, along with engineering documentation including FAI reports, inspections, certifications, and PPAP support.
                                </p>

                                {/* <div className="mt-6 flex gap-4  justify-start">
                                    <button
                                        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                        onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                                    >
                                        Materials Library
                                    </button>
                                </div> */}
                            </div>

                            {/* Right Image */}
                            <div className="   relative h-[400px]">
                                <Image
                                    src="/imgs/Our-capabilities.jpg"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-center object-cover"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <ManufacturingUsp />
            </section>
        </>
    );
});

// Set a display name for easier debugging in React DevTools
AirMobilityManufacturingTechnologiesSection.displayName = 'AirMobilityManufacturingTechnologiesSection';

export default AirMobilityManufacturingTechnologiesSection;
