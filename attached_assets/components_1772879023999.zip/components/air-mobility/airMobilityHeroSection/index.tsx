import React from "react";
import Image from "next/image";
import Script from "next/script";
import AirMobilityIndustryImageCarousel from "../air-mobility-trusted";
import ImageCard from "@/components/ImageCard";

interface AirMobilityHeroSectionProps {
    onViewCapabilitiesButtonClick: () => void; // The function passed from the parent
}


const AirMobilityHeroSection: React.FC<AirMobilityHeroSectionProps> = ({ onViewCapabilitiesButtonClick }) => {

    const handleMeetOurEngineerClick = () => {
        const meetLink = process.env.NEXT_PUBLIC_ENGINEER_MEET_LINK;
        if (meetLink) {
            window.open(meetLink, "_blank");
        } else {
            console.error("Meeting link is not defined in environment variables.");
        }
    };



    return (
        <section className="pt-24 ">
            <div className="">
                <div>
                    <div className="grid md:grid-cols-2   ">

                        {/* Left Image */}
                        <div className=" relative h-[400px]">
                            <Image
                                src="/imgs/AI_Video_Edge_-Computing.jpg"
                                alt="Robotic components in production"
                                fill
                                className="object-center md:object-cover"
                            />
                        </div>

                        {/* Right Text Content */}
                        <div className=" p-5 lg:py-10">
                            <h1 className="text-2xl lg:text-4xl font-bold text-gray-900">

                                Manufacturing Tomorrow’s Skies, Today.
                            </h1>

                            <p className=" mt-4">
                                From eVTOLs to autonomous drones, 8X Parts is accelerating the future of flight. Our digital manufacturing platform delivers high-precision parts for AAM innovators—built to fly, built to scale.
                            </p>

                            <div className="mt-6 flex gap-4">

                                <button
                                    className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                    onClick={() => window.open(process.env.NEXT_PUBLIC_MAKE_URL)}
                                >
                                    Get an Instant Quote
                                </button>

                                <button className="px-6 py-3 border border-gray-300 hover:border-gray-400 text-sky-500 hover:text-sky-600 font-medium rounded-lg transition-colors"
                                    onClick={onViewCapabilitiesButtonClick}
                                >
                                    View Capabilities
                                </button>
                            </div>

                            <div className="flex gap-2 mt-6 justify-evenly md:justify-start">
                                <ImageCard
                                    src="/imgs/ISO9001_2015.jpg"
                                    alt="Robotic components in production"
                                />
                                <ImageCard
                                    src="/imgs/AS9100D-Logo.jpg"
                                    alt="Robotic components in production"
                                />
                                <ImageCard
                                    src="/imgs/itar.jpg"
                                    alt="Robotic components in production"
                                />
                                <ImageCard
                                    src="/imgs/fast_delivery.png"
                                    alt="Robotic components in production"
                                />
                            </div>

                        </div>


                    </div>
                    <AirMobilityIndustryImageCarousel />

                    <div className="mt-2 flex justify-center flex-col sm:flex-row gap-4">

                        <button className="px-6 py-3 border border-gray-200 hover:border-gray-300 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors" onClick={handleMeetOurEngineerClick}>
                            Schedule a Technical Consultation
                        </button>
                    </div>

                </div>

            </div>

        </section>
    );
};

export default AirMobilityHeroSection;




