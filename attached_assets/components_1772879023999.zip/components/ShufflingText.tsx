'use client';

import React, { useState, useEffect } from 'react';

const ShufflingText: React.FC = () => {
  const lines: string[] = [
    "Optimize your designs with our free Design for Manufacturability (DFM) consultations.",
    "Streamline production and reduce costs with expert guidance tailored to your needs.",
    "Upload your files and get personalized feedback on improving manufacturability.",
    "Discover cost-saving strategies through data-driven design optimization.",
    "Collaborate with industry experts to make your designs production-ready.",
    "Unlock your design’s potential with actionable insights from seasoned professionals.",
    "Stay ahead with solutions that improve efficiency and scalability.",
    "Transform concepts into reality with precision-focused DFM support.",
    "Empower your engineering projects with expert reviews and hands-on consultation."
  ];

  const [currentText, setCurrentText] = useState<string>('');
  const [fullText, setFullText] = useState<string>(
    lines[Math.floor(Math.random() * lines.length)]
  );
  const [charIndex, setCharIndex] = useState<number>(0);
  const [previousText, setPreviousText] = useState<string>('');

  useEffect(() => {
    const typingTimeout = setTimeout(() => {
      if (charIndex < fullText.length) {
        setCurrentText((prev) => prev + fullText[charIndex]);
        setCharIndex((prev) => prev + 1);
      }
    }, 50);

    return () => clearTimeout(typingTimeout);
  }, [charIndex, fullText]);

  useEffect(() => {
    if (charIndex === fullText.length) {
      const shuffleTimeout = setTimeout(() => {
        setCurrentText('');
        setCharIndex(0);
        let nextText = lines[Math.floor(Math.random() * lines.length)];

        while (nextText === previousText) {
          nextText = lines[Math.floor(Math.random() * lines.length)];
        }

        setFullText(`${nextText}...`);
        setPreviousText(nextText);
      }, 2500);

      return () => clearTimeout(shuffleTimeout);
    }
  }, [charIndex, fullText, previousText]);

  return (
    <div className="text-lg text-gray-600 text-center mx-auto max-full mt-6 px-4 min-h-[50px]">
      {currentText}
    </div>
  );
};

export default ShufflingText;
