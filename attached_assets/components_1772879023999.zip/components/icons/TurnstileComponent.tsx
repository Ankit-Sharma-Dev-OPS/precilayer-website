
import React from 'react';
import Turnstile from 'react-turnstile';

interface TurnstileComponentProps {
  onVerify: (token: string) => void;
}

const TurnstileComponent: React.FC<TurnstileComponentProps> = ({ onVerify }) => {
    return (
    <Turnstile
      sitekey={process.env.NEXT_PUBLIC_TURNSTILE_SITEKEY ||""}
      onVerify={onVerify}
    />
  );
};

export default TurnstileComponent;
