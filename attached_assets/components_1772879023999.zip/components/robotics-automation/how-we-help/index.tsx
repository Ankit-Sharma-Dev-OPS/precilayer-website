import React from "react";
import Image from "next/image";
import Script from "next/script";
import RoboticsUsp from "../robotics-usp";

const RoboticPageHowWeHelpSection: React.FC = () => {
    return (
        <>
            <section className="pt-24 ">

                <div className="w-full  ">
                    <div>
                        <div className="grid md:grid-cols-2 gap-12 border-top">

                            {/* Left Image */}
                            <div className=" relative h-[400px]">
                                <Image
                                    src="/imgs/how-we-help-bg-v1.jpeg"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-cover shadow-lg"
                                />
                            </div>

                            {/* Right Text Content */}
                            <div className="">
                                <h1 className="text-4xl font-bold text-gray-900">
                                    How We Help Robotics & Automation Companies
                                </h1>

                                <p className="mt-4">
                                    Optimized Manufacturing for Robotics Innovation: We empower robotics and automation companies with precision-engineered components designed for optimized manufacturing. We streamline production processes and deliver reliable parts that accelerate your innovation from concept to market.
                                </p>

                                <div className="mt-6 flex gap-4">

                                    <button
                                        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                        onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10693579-case-study-high-precision-cnc-machined-actuator-components-for-industrial-robotics")}
                                    >
                                        Case Study
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <section>
                <RoboticsUsp />
            </section>
        </>
    );
};

export default RoboticPageHowWeHelpSection;




