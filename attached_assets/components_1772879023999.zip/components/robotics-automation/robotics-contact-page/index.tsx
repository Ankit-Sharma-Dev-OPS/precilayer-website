'use client'
import React, { useState } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Started from "@/app/components/category-page/started";
import { ContactFormData } from '@/types/types';
import { contactUsSubmit, verifyTurnstileToken } from '@/app/actions/actions';
import { isValidEmail } from '@/utils/helper';
import { ButtonLoader } from '@/components/icons';
import { toast } from 'react-toastify';
import TurnstileComponent from '@/components/icons/TurnstileComponent';
// import { useRouter } from "next/router";

interface ContactItems {
  title: string;
  label: string;
}

const contact: ContactItems[] = [
  { title: "Phone:", label: "+1 (917) 730-2990" },
   { title: "Email:", label: process.env.NEXT_PUBLIC_SENDER_EMAIL || '' },
  { title: "Address:", label: "228 Park Ave S, Suite 62588, New York, NY 10003" },
];


interface RoboticsContactPageProps {
  heading: string;
}
const RoboticsContactPage: React.FC<RoboticsContactPageProps> = ({ heading }) => {
  // const router = useRouter();

  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    company: '',
    projectDetails: '',
  });
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [token, setToken] = useState<string>('');
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };


  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {

    e.preventDefault();
    try {
      setError(null);

      if (!formData.name || !formData.email) {
        setError("Please fill in all required fields.");
        return;
      }

      if (!isValidEmail(formData.email)) {
        setError("Please enter a valid email address.");
        return;
      }

      if (!token) {
        setError("Captcha verification failed. Please try again.");
        return;
      }

      const turnstileResponse = await verifyTurnstileToken(token);

      if (turnstileResponse.success) {
        setError(null);
        setIsLoading(true)
        const response = await contactUsSubmit(formData)
        if (response.success) {
          setIsModalOpen(true);
          setFormData({
            name: '',
            email: '',
            company: '',
            projectDetails: '',
          })
          // router.push('/');

        } else {
          setError(response.error || 'Something went wrong.');
        }
      } else {

      }


    } catch (err) {
      toast.error("Something went wrong while submitting contact details. Please try again later.");
    } finally {
      setIsLoading(false)
    }

  };

  const handleTurnstileVerify = (token: string) => {
    setToken(token);
  };

  return (
    <div className="min-h-screen bg-white border-b">
      {heading ? <section className="pt-40 lg:pt-24 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight text-center">{heading}</h1>
        </div>
      </section> : null}
      <Paragraph id="contact" dark={true} title="Contact Methods" items={contact} />

      <section id="form" className="bg-white py-12">
        <div className="mx-auto px-4 sm:px-6 w-screen">
          <div className="text-center">
            <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Online Form</h2>
          </div>
          <form onSubmit={handleSubmit} className="bg-gray-50 w-full md:w-2/4 mx-auto mt-8 p-6 rounded-lg border-1 shadow-lg">
            <label className='py-2 text-sky-500'>* NAME</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="rounded-md w-full my-2 px-4 py-2"
              placeholder='Name'
            />
            <label className='py-2 text-sky-500'>* EMAIL</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="rounded-md w-full my-2 px-4 py-2"
              placeholder='Email'
            />
            <label className='py-2 text-sky-500'>COMPANY</label>
            <input
              type="text"
              name="company"
              value={formData.company}
              onChange={handleChange}
              className="rounded-md w-full my-2 px-4 py-2"
              placeholder='Company'
            />
            <label className='py-2 text-sky-500'>PROJECT DETAILS</label>
            <textarea
              name="projectDetails"
              value={formData.projectDetails}
              onChange={handleChange}
              className="rounded-md min-h-28 w-full my-2 px-4 py-2"
              placeholder='Project details'
            />

            {error && <p className="text-red-500 mt-2">{error}</p>}

            <div className="w-full mt-4 text-center">
              <TurnstileComponent onVerify={handleTurnstileVerify} />
            </div>

            <button
              type="submit"
              className="w-full bg-sky-500 text-white py-2 px-4 rounded-md mt-4 font-semibold hover:bg-sky-600 transition duration-300 flex justify-center items-center"
            >
              {isLoading ? (
                <ButtonLoader />
              ) : (
                "Submit"
              )}
            </button>

          </form>
        </div>
      </section>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md mx-auto">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Thanks for sharing the details! One of our engineers will get in touch with you soon.
            </h3>
            <button
              onClick={() => {
                setIsModalOpen(false)
                window.location.reload()
              }
              }
              className="mt-6 px-6 py-2 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      <Started title="Let’s discuss how we can bring your project to life. Submit your inquiry or call us today!" />

    </div>
  );
};

export default RoboticsContactPage;
