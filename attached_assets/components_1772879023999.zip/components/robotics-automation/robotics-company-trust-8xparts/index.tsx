import React from 'react';

const RobotticsCompanyTrust8xPartsSection = () => {
    const items = [
        { icon: "jet-fighter-up", title: "Fast Lead Times", text: "Expedited prototyping & production" },
        { icon: "bullseye", title: " Industry-Leading Accuracy", text: "±0.005mm tolerances" },
        { icon: "user-tie", title: "Engineering Support", text: "DFM analysis & material recommendations" },
    ];

    return (
        <div className="mx-auto px-2 py-8 border-b">
            <div className="text-center">
                <h2 className="text-4xl font-bold text-gray-900">Why Top Robotics Companies Trust 8X Parts?</h2>
                <p className="mt-4 text-xl text-gray-600">Three Key Differentiators</p>
            </div>
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {items.map((item, index) => (
                    <div key={index} className="flex items-center justify-center gap-3 min-w-0">
                        {/* Icon */}
                        <div className="flex justify-center items-center w-12 h-12">
                            <i className={`fas fa-${item.icon} text-sky-500 text-2xl`} />
                        </div>

                        {/* Text Content */}
                        <div className="min-w-0">
                            <p className="text-base font-bold text-sky-500">{item.title}</p>
                            <p className="text-xs text-gray-600">{item.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default RobotticsCompanyTrust8xPartsSection;
