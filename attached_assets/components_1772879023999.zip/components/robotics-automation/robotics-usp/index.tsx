import React from 'react';

const RoboticsUsp = () => {
  const items = [
    { icon: "compass-drafting", title: "Unmatched Precision", text: "Tight tolerances & high-accuracy components" },
    { icon: "gauge-simple-high", title: "Rapid Production", text: "Fast prototyping & low-volume production" },
    { icon: "globe", title: "Global Manufacturing", text: "USA, Europe & India (No China Sourcing)" },
  ];

  return (
    <div className="mx-auto py-8">
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 justify-items-center gap-6">
        {items.map((item, index) => (
          <div key={index} className="flex flex-col items-center text-center md:text-start md:items-start space-y-3">
            {/* Icon */}
            <div className="flex justify-center items-center w-16 h-16 bg-sky-100 rounded-full mb-4">
              <i className={`fas fa-${item.icon} text-sky-500 text-3xl`} />
            </div>

            {/* Text Content */}
            <div>
              <p className="text-lg font-bold text-sky-500">{item.title}</p>
              <p className="text-sm text-gray-600">{item.text}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RoboticsUsp;
