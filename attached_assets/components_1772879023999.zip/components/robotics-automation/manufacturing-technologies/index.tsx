import React, { forwardRef } from "react";
import Image from "next/image";
import Script from "next/script";
import ManufacturingUsp from "../manufactuing-usp";

// Forward the ref to the section element
const RoboticManufacturingTechnologiesSection = forwardRef<HTMLDivElement, {}>((props, ref) => {
  return (
    <>
      <section ref={ref} className="pt-24">
        <div className="w-full ">
          <div>
            <div className="grid md:grid-cols-2 gap-12 border-top">

              {/* Left Text Content */}
              <div className=" text-left pl-10">
                <h1 className="text-4xl font-bold text-gray-900">
                  Manufacturing Capabilities for Robotics & Automation
                </h1>

                <p className="mt-4">
                  Advanced Manufacturing Technologies: 8xparts.com delivers high-precision components for robotics and automation, combining advanced manufacturing with strict quality control. We help innovators accelerate production with reliable parts built for demanding applications.
                </p>

                <div className="mt-6 flex gap-4 flex justify-start">
                  <button
                    className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                    onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                  >
                    Materials Library
                  </button>
                </div>
              </div>

              {/* Right Image */}
              <div className=" relative h-[400px]">
                <Image
                  src="/imgs/8xParts-robotics-manufacturing-v1.jpg"
                  alt="Robotic components in production"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <ManufacturingUsp />
      </section>
    </>
  );
});

// Set a display name for easier debugging in React DevTools
RoboticManufacturingTechnologiesSection.displayName = 'RoboticManufacturingTechnologiesSection';

export default RoboticManufacturingTechnologiesSection;
