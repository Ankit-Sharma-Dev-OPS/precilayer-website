import Image from "next/image";

interface ImageCardProps {
  src: string;
  alt: string;
}

const ImageCard: React.FC<ImageCardProps> = ({ src, alt }) => (
  <div className="w-[70px] h-[80px] sm:w-[110px] sm:h-[100px] flex items-center justify-center bg-white rounded shadow">
    <Image
      src={src}
      alt={alt}
      className="object-contain w-full h-full"
      width={80}
      height={60}
    />
  </div>
);

export default ImageCard;
