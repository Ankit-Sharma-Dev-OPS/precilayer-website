'use client'; // Mark this as a client component

import { useEffect } from "react";
import { usePathname } from "next/navigation";

declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    heap: any;
    heapReadyCb: any[];
  }
}

export default function AnalyticsComponent() {
  const pathname = usePathname();

  useEffect(() => {
    if (typeof window !== "undefined") {
      // Google Tag Manager
      if (window.gtag) {
        window.gtag("config", "G-8MJ9SYRHZL", {
          page_path: pathname,
        });
      }

      // Heap Analytics
      if (!window.heap) {
        window.heapReadyCb = window.heapReadyCb || [];
        window.heap = window.heap || [];
        window.heap.load = function (e: string, t?: any) {
          window.heap.envId = e;
          window.heap.clientConfig = t || {};
          window.heap.clientConfig.shouldFetchServerConfig = false;

          const script = document.createElement("script");
          script.type = "text/javascript";
          script.async = true;
          script.src = `https://cdn.us.heap-api.com/config/${e}/heap_config.js`;

          const firstScript = document.getElementsByTagName("script")[0];
          firstScript.parentNode?.insertBefore(script, firstScript);

          const methods = [
            "init",
            "startTracking",
            "stopTracking",
            "track",
            "resetIdentity",
            "identify",
            "getSessionId",
            "getUserId",
            "getIdentity",
            "addUserProperties",
            "addEventProperties",
            "removeEventProperty",
            "clearEventProperties",
            "addAccountProperties",
            "addAdapter",
            "addTransformer",
            "addTransformerFn",
            "onReady",
            "addPageviewProperties",
            "removePageviewProperty",
            "clearPageviewProperties",
            "trackPageview",
          ];

          const createMethod = (method: string) => {
            return function (...args: any[]) {
              window.heapReadyCb.push({
                name: method,
                fn: () => {
                  if (window.heap[method]) {
                    window.heap[method].apply(window.heap, args);
                  }
                },
              });
            };
          };

          for (const method of methods) {
            window.heap[method] = createMethod(method);
          }
        };

        window.heap.load("3118503417");
      }
    }
  }, [pathname]);

  return (
    <>
      {/* Google Tag Manager */}
      <script async src="https://www.googletagmanager.com/gtag/js?id=G-8MJ9SYRHZL" />
      <script
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-8MJ9SYRHZL');
          `,
        }}
      />

      {/* Heap Analytics */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            window.heapReadyCb = window.heapReadyCb || [];
            window.heap = window.heap || [];
            heap.load = function(e, t) {
              window.heap.envId = e;
              window.heap.clientConfig = t = t || {};
              window.heap.clientConfig.shouldFetchServerConfig = false;
              
              var a = document.createElement("script");
              a.type = "text/javascript";
              a.async = true;
              a.src = "https://cdn.us.heap-api.com/config/" + e + "/heap_config.js";
              
              var r = document.getElementsByTagName("script")[0];
              r.parentNode.insertBefore(a, r);

              var n = ["init", "startTracking", "stopTracking", "track", "resetIdentity", "identify",
                       "getSessionId", "getUserId", "getIdentity", "addUserProperties", "addEventProperties",
                       "removeEventProperty", "clearEventProperties", "addAccountProperties", "addAdapter",
                       "addTransformer", "addTransformerFn", "onReady", "addPageviewProperties",
                       "removePageviewProperty", "clearPageviewProperties", "trackPageview"];

              var i = function(e) {
                return function() {
                  var t = Array.prototype.slice.call(arguments, 0);
                  window.heapReadyCb.push({
                    name: e,
                    fn: function() {
                      heap[e] && heap[e].apply(heap, t);
                    }
                  });
                };
              };

              for (var p = 0; p < n.length; p++) heap[n[p]] = i(n[p]);
            };
            heap.load("3118503417");
          `,
        }}
      />

      <script id="vtag-ai-js" async src="https://r2.leadsy.ai/tag.js" data-pid="Ov4E7sCHy8zmxoSv" data-version="062024" />
    </>
  );
}
