import React, { forwardRef } from "react";
import Image from "next/image";
import Script from "next/script";
import ManufacturingUsp from "@/components/robotics-automation/manufactuing-usp";

// Forward the ref to the section element
const SatelliteManufacturingTechnologiesSection = forwardRef<HTMLDivElement, {}>((props, ref) => {
    return (
        <>
            <section ref={ref} className="pt-24">
                <div className="w-full mx-2 md:mx-0">
                    <div>

                        <div className="grid md:grid-cols-2 gap-12 border-top">

                            {/* Left Text Content */}
                            <div className=" md:pl-10 !mt-10">
                                <h1 className="text-4xl font-bold text-gray-900">
                                    Precision Manufacturing for Extreme Conditions
                                </h1>

                                <p className="mt-4 ">We specialize in CNC machining, offering 5-axis milling and turning capabilities to achieve high-precision, tight-tolerance parts for aerospace applications. Our additive manufacturing services utilize metal 3D printing to produce lightweight, complex geometries with optimal material performance. We have extensive experience working with exotic materials, including titanium, Inconel, and ceramic matrix composites, to meet demanding specifications. Additionally, our thermal and structural optimization processes are designed to ensure reliability and efficiency in high-radiation and vacuum environments.</p>

                                <div className="mt-6 flex gap-4  justify-start">
                                    <button
                                        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                        onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                                    >
                                        Materials Library
                                    </button>
                                </div>
                            </div>

                            {/* Right Image */}
                            <div className="   relative h-[400px]">
                                <Image
                                    src="/imgs/satellite-space-capabilities.jpg"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-center md:object-cover"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <ManufacturingUsp />
            </section>
        </>
    );
});

// Set a display name for easier debugging in React DevTools
SatelliteManufacturingTechnologiesSection.displayName = 'SatelliteManufacturingTechnologiesSection';

export default SatelliteManufacturingTechnologiesSection;
