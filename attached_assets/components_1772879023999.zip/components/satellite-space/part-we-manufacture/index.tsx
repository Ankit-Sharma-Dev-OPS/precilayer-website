import React from "react";
import Image from "next/image";

interface PartsPost {
    title: string;
    icon: string;
    label: string;
}

const partsArray1: PartsPost[] = [
    {
        title: 'Structural Brackets & Frames',
        icon: 'satellite-space-brackets.jpg',
        label: 'Lightweight, high-strength CNC-machined components',
    },
    {
        title: 'Waveguides & Antenna Components',
        icon: 'waveguide.png',
        label: 'RF-optimized parts for satellite communication',
    },
];

const partsArray2: PartsPost[] = [
    {
        title: 'Propulsion System Components',
        icon: 'satellite-space-propulsion-system-components.jpg',
        label: 'Nozzles, thruster chambers, and fuel system parts',
    },
    {
        title: 'Thermal Management Systems',
        icon: 'satellite-space-thermal-management-system.jpg',
        label: 'Custom heat sinks and radiators for space applications',
    },
    {
        title: 'Electronic Housings & Shielding',
        icon: 'satelite-space-housing-and-shielding.jpg',
        label: 'EMI-resistant enclosures for onboard electronics',
    },
];

const SatellitePartsWeManufacture: React.FC = () => {
    return (
        <section id="industries" className="bg-gray-50 pt-20 pb-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
                <div className="text-center">
                    <h2 className="text-4xl font-bold text-gray-900">Parts We Manufacture for Satellites</h2>
                    <p className="mt-4 text-xl text-gray-600">Critical Components for LEO, GEO & Deep Space Missions</p>
                </div>
                <div className="mt-16 grid md:grid-cols-2 gap-8">
                    {partsArray1.map((post) => (
                        <div key={post.title} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                            <Image src={`/imgs/${post.icon}`} width={200} height={200} className=" w-full h-[250px] mb-2" alt="" />
                            <h3 className="text-xl font-bold text-gray-900 flex">

                                <p className="flex items-center">{post.title}</p>
                            </h3>
                            <p className="mt-2 text-gray-600">{post.label}</p>
                        </div>
                    ))}
                </div>

                <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-start">
                    {partsArray2.map((post, index) => {
                        const isLastItem = index === partsArray2.length - 1;

                        return (
                            <div
                                key={post.title}
                                className={`bg-white rounded-lg p-6 h-[420px] shadow-sm hover:shadow-md transition-shadow
        ${isLastItem ? "md:col-span-2 lg:col-span-1 md:w-[500px] md:mx-auto lg:w-full" : ""}`}
                            >
                                <Image
                                    src={`/imgs/${post.icon}`}
                                    width={200}
                                    height={200}
                                    className="w-full h-[250px] mb-2 object-contain"
                                    alt={post.title}
                                />
                                <h3 className="text-xl font-bold text-gray-900">
                                    <p className="flex items-center">{post.title}</p>
                                </h3>
                                <p className="mt-2 text-gray-600">{post.label}</p>
                            </div>
                        );
                    })}
                </div>

            </div>

        </section>
    );
};

export default SatellitePartsWeManufacture;


