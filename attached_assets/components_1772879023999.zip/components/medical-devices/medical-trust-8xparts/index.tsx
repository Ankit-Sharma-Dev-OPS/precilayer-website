import React from 'react';

const MedicalDevicesTrust8xPartsSection = () => {
    const items = [
        { icon: "ruler-combined", title: "Tight Tolerances (±0.0004 in)", text: "across CNC & additive processes" },
        { icon: "vial-circle-check", title: "Biocompatible Materials", text: "PEEK, Ultem, Titanium, LCP, medical-grade silicones" },
        { icon: "spray-can-sparkles", title: "Cleanroom-Compatible Finishes", text: "for sterilization readiness" },
        { icon: "layer-group", title: "Scalable", text: "from prototypes to low/mid-volume production" },
        { icon: "globe", title: "Zero China Dependency", text: "Manufacturing across U.S., Europe & India" },
    ];


    return (
        <div className="mx-auto px-4 py-12 border-b">
            {/* Title Section */}
            <div className="text-center">
                <h2 className="text-4xl font-bold text-gray-900">Why Medical Device Companies Work With Us
                </h2>
                <p className="mt-4 text-xl text-gray-600">Five Key Differentiators</p>
            </div>

            {/* Content Section */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 justify-self-center md:grid-cols-3 gap-8">
                {items.map((item, index) => (
                    <div key={index} className="flex flex-col items-center text-center md:text-start md:items-start space-y-4">
                        {/* Icon */}
                        <div className="flex justify-center items-center w-16 h-16 bg-sky-100 rounded-full">
                            <i className={`fas fa-${item.icon} text-sky-500 text-3xl`} />
                        </div>

                        {/* Text Content */}
                        <div>
                            <p className="text-lg font-bold text-sky-500">{item.title}</p>
                            <p className="text-sm text-gray-600">{item.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MedicalDevicesTrust8xPartsSection;
