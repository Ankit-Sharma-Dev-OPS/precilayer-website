'use client';
import React from "react";
import Slider from "react-slick";
import Image from "next/image";

interface MedicalDevicesIndustryImageCarouselProps { }

const MedicalInstustryTrustSection: React.FC<MedicalDevicesIndustryImageCarouselProps> = () => {
    const settings = {
        dots: false, // Show navigation dots
        infinite: true, // Infinite looping
        speed: 4000, // Transition speed
        slidesToShow: 4, // Number of images visible at a time
        slidesToScroll: 1, // Number of images to scroll at a time
        autoplay: true, // Enable autoplay
        autoplaySpeed: 50, // Autoplay interval
        responsive: [
            {
                breakpoint: 768, // For smaller screens
                settings: {
                    slidesToShow: 1, // Show 1 image at a time
                },
            },
            {
                breakpoint: 1024, // For medium screens
                settings: {
                    slidesToShow: 2, // Show 2 images at a time
                },
            },
        ],
    };

    const images: string[] = [
        "/imgs/aerogen.jpg",
        "/imgs/teleflex.png",
        "/imgs/medtronic.jpg",
        "/imgs/cook-medical-v1.png",
        "/imgs/Merit-Medical.png",
        "/imgs/integer.jpg",
        "/imgs/jandj.png",
    ];

    return (
        <div className="mt-0 bg-white rounded-lg p-4">
            <p className="mt-8 mb-2 text-4xl font-bold text-gray-900 text-center">
                We Are a Trusted Partner for Medical devices Companies.
            </p>
            <Slider {...settings}>
                {images.map((src, index) => (
                    <div key={index}>
                        <div> {/* Fixed height */}
                            <Image
                                src={src}
                                alt={`Carousel Image ${index + 1}`}
                                width={200}
                                height={200}
                                style={{ objectFit: "contain" }}
                                className="mx-auto h-20"
                            />
                        </div>
                    </div>
                ))}
            </Slider>
        </div>


    );
};

export default MedicalInstustryTrustSection;
