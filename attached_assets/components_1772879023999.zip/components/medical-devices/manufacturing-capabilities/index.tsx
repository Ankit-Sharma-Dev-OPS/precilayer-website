import React, { forwardRef } from "react";
import Image from "next/image";
import Script from "next/script";
import ManufacturingUsp from "../../medical-devices/manufacturing-ups/index";

// Forward the ref to the section element
const MedicalDevicesManufacturingSection = forwardRef<HTMLDivElement, {}>((props, ref) => {
    return (
        <>
            <section ref={ref} className="pt-24">
                <div className="w-full mx-2 md:mx-0">
                    <div>

                        <div className="grid md:grid-cols-2  border-top">

                            {/* Left Text Content */}
                            <div className=" md:pl-10 !mt-10">
                                <h1 className="text-4xl font-bold text-gray-900">
                                    Our Capabilities for Medical Devices
                                </h1>

                                <ul className="list-disc list-inside text-gray-700 text-lg space-y-2 mt-10 ">
                                    <li><strong>Multi-Axis CNC Machining</strong> <span className="text-[16px]">– For titanium, stainless steel, and hard plastics</span></li>
                                    <li><strong>Medical-Grade 3D Printing</strong> <span className="text-[16px]">– MJF, SLA, DLP for prototyping, guides & fit-checks</span></li>
                                    <li><strong>Injection Molding</strong> <span className="text-[16px]">– For validated high-volume parts in Class VI materials</span></li>
                                    {/* <li><strong>Vacuum Casting</strong> <span className="text-[16px]">– (Expanded Below)</span></li> */}
                                </ul>


                                {/* <div className="mt-6 flex gap-4  justify-start">
                                    <button
                                        className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                        onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                                    >
                                        Materials Library
                                    </button>
                                </div> */}
                            </div>

                            {/* Right Image */}
                            <div className="relative h-[400px] border">
                                <Image
                                    src="/imgs/medical-devices-our-cap.jpg"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-cover object-center"
                                />
                            </div>

                        </div>
                    </div>
                </div>
            </section>

            <section>
                <ManufacturingUsp />
            </section>
        </>
    );
});

// Set a display name for easier debugging in React DevTools
MedicalDevicesManufacturingSection.displayName = 'MedicalDevicesManufacturingSection';

export default MedicalDevicesManufacturingSection;
