import React from "react";
import Image from "next/image";
import Script from "next/script";
import RoboticsUsp from "@/components/robotics-automation/robotics-usp";

const MedicalPageHowWeHelpSection: React.FC = () => {
    return (
        <>
            <section className=" ">

                <div className="w-full  ">
                    <div>
                        <div className="grid md:grid-cols-2  border-top">

                            {/* Left Image */}
                            <div className=" relative h-[400px]">
                                <Image
                                    src="/imgs/Vacuum-casting.jpg"
                                    alt="Robotic components in production"
                                    fill
                                    className="object-center md:object-cover"
                                />
                            </div>

                            {/* Right Text Content */}
                            <div className="mt-5 py-2 px-4">
                                <h1 className="text-2xl md:text-4xl font-bold text-gray-900">
                                    Vacuum Casting for Medical Applications
                                </h1>

                                <div className="text-gray-800 ms-1">
                                    <h2 className="text-xl md:text-2xl font-semibold mb-3 ">Precision Soft Parts, Fast.</h2>
                                    <p className="text-lg mb-6">
                                        Vacuum casting is ideal for low-volume medical-grade parts that require soft-touch, flexibility, and surface finish close to production injection molding.
                                    </p>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                                        <div className="mb-6">
                                            <h3 className="text-xl font-semibold  mb-2"> What We Offer:</h3>
                                            <ul className="list-disc list-inside space-y-2 text-sm">
                                                <li>Silicone, polyurethane, and elastomeric cast parts</li>
                                                <li>Skin-contact safe , Class VI-compatible materials</li>
                                                <li>Typical lead time: 7–10 days</li>
                                                <li>Batch size: 1 to 200 units</li>
                                            </ul>
                                        </div>

                                        <div>
                                            <h3 className="text-xl font-semibold  mb-2"> Typical Uses:</h3>
                                            <ul className="list-disc list-inside space-y-2 text-sm">
                                                <li>Seals, valves, diaphragms</li>
                                                <li>Grips, handles, wearable straps</li>
                                                <li>Disposable caps and closures</li>
                                                <li>Medical-grade enclosures and cushioning pads</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

            </section>
            <section>
                <RoboticsUsp />
            </section>
        </>
    );
};

export default MedicalPageHowWeHelpSection;




