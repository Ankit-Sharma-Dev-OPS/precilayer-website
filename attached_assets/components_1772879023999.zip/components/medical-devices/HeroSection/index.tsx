import React from "react";
import Image from "next/image";

import SatellitesIndustryImageCarousel from "../medical-devices-trust/index";
import ImageCard from "@/components/ImageCard";

interface MedicalDevicesSectionProps {
    onViewCapabilitiesButtonClick: () => void; // The function passed from the parent
}


const MedicalDevicesSection: React.FC<MedicalDevicesSectionProps> = ({ onViewCapabilitiesButtonClick }) => {

    const handleMeetOurEngineerClick = () => {
        const meetLink = process.env.NEXT_PUBLIC_ENGINEER_MEET_LINK;
        if (meetLink) {
            window.open(meetLink, "_blank");
        } else {
            console.error("Meeting link is not defined in environment variables.");
        }
    };


    return (
        <section className="pt-24 ">
            <>
            </>
            <div className="">
                <div>
                    <div className="grid md:grid-cols-2   ">

                        {/* Left Image */}
                        <div className=" relative h-[400px]">
                            <Image
                                src="/imgs/hero-medical-devices.jpeg"
                                alt="Robotic components in production"
                                fill
                                className="object-center object-cover"
                            />
                        </div>

                        {/* Right Text Content */}
                        <div className=" p-5 py-10">
                            <h1 className="text-4xl font-bold text-gray-900">

                                Engineering trust, one component at a time
                            </h1>

                            <p className="mt-4">
                                We support medical innovators with ultra-precise components, cleanroom-ready finishes, and biocompatible materials — all manufactured to global standards
                            </p>

                            <div className="mt-6 flex gap-4">

                                <button
                                    className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                                    onClick={() => window.open(process.env.NEXT_PUBLIC_MAKE_URL)}
                                >
                                    Get an Instant Quote
                                </button>

                                <button className="px-6 py-3 border border-gray-300 hover:border-gray-400 text-sky-500 hover:text-sky-600 font-medium rounded-lg transition-colors"
                                    onClick={onViewCapabilitiesButtonClick}
                                >
                                    View Capabilities
                                </button>
                            </div>

                            <div className="flex gap-2 gap-x-5 mt-6 justify-evenly md:justify-start ">
                                <ImageCard
                                    src="/imgs/ISO9001_2015.jpg"
                                    alt="Robotic components in production"
                                />
                                <ImageCard
                                    src="/imgs/iso-13485-new.jpg"
                                    alt="Robotic components in production"
                                />
                                <ImageCard
                                    src="/imgs/fast_delivery.png"
                                    alt="Robotic components in production"
                                />
                            </div>

                        </div>


                    </div>
                    <SatellitesIndustryImageCarousel />

                    <div className="mt-2 flex justify-center flex-col sm:flex-row gap-4">

                        <button className="px-6 py-3 border border-gray-200 hover:border-gray-300 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors" onClick={handleMeetOurEngineerClick}>
                            Schedule a Technical Consultation
                        </button>
                    </div>

                </div>

            </div>

        </section>
    );
};

export default MedicalDevicesSection;




