// 'use client';
// import React, { useState, useEffect } from "react";
// import Dropzone, { DropEvent, FileRejection } from "react-dropzone";

// type FullScreenFileDropProps = {
//   OnDropFunction: (acceptedFiles: File[], fileRejections: FileRejection[], event: DropEvent) => void;
// };

// const FullScreenFileDrop: React.FC<FullScreenFileDropProps> = ({ OnDropFunction }) => {
//   const [isDragActive, setDragActive] = useState<boolean>(false);

//   useEffect(() => {
//     const handleDragOver = (event: DragEvent) => {
//       event.preventDefault();
//       event.stopPropagation();
//       setDragActive(true);
//     };

//     const handleDragLeave = (event: DragEvent) => {
//       event.preventDefault();
//       event.stopPropagation();

//       if (event.clientX === 0 && event.clientY === 0) {
//         setDragActive(false);
//       }
//     };

//     const handleDrop = (event: DragEvent) => {
//       event.preventDefault();
//       event.stopPropagation();
//       setDragActive(false);
//     };

//     window.addEventListener("dragover", handleDragOver);
//     window.addEventListener("dragleave", handleDragLeave);
//     window.addEventListener("drop", handleDrop);

//     return () => {
//       window.removeEventListener("dragover", handleDragOver);
//       window.removeEventListener("dragleave", handleDragLeave);
//       window.removeEventListener("drop", handleDrop);
//     };
//   }, []);

//   return (
//     <div className="full-screen-file-drop">
//       {isDragActive && (
//         <Dropzone
//           onDrop={OnDropFunction}
//           maxFiles={1}  // Only allow a single file to be dropped
//           accept="application/zip, application/pdf, image/*, .stp, .step, .x_t"  // Add file types if needed
//         >
//           {({ getRootProps, getInputProps }) => (
//             <div
//               {...getRootProps()}
//               style={{
//                 position: "fixed",
//                 top: 0,
//                 left: 0,
//                 width: "100vw",
//                 height: "100vh",
//                 backgroundColor: "rgba(0, 0, 0, 0.8)",
//                 display: "flex",
//                 justifyContent: "center",
//                 alignItems: "center",
//                 color: "#fff",
//                 fontSize: "24px",
//                 zIndex: 10001,
//                 cursor: "pointer",
//               }}
//             >
//               <input id="dropFile" {...getInputProps()} name="file" />
//               <label htmlFor="dropFile" className="sub-header text-white">
//                 Drop your file here...
//               </label>
//             </div>
//           )}
//         </Dropzone>
//       )}
//     </div>
//   );
// };

// export default FullScreenFileDrop;
