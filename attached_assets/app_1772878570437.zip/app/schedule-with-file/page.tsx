// 'use client';

// import React, { useCallback, useState } from 'react';
// import FullScreenFileDrop from '@/components/FullScreenFileDrop';
// import { FileRejection, DropEvent } from 'react-dropzone';
// import { Loader2 } from 'lucide-react';
// import ShufflingText from '@/components/ShufflingText';
// import axios from 'axios';

// interface UploadResponse {
//   success: boolean;
//   files?: { fileName: string; fileUrl: string }[];
//   error?: string;
// }

// export default function ScheduleWithFilePage() {
//   const [uploading, setUploading] = useState<boolean>(false);
//   const [uploadedFiles, setUploadedFiles] = useState<{ fileName: string; fileUrl: string }[]>([]);

//   const handleFileUpload = useCallback(
//     async (
//       acceptedFiles: File[],
//       _fileRejections: FileRejection[],
//       _event: DropEvent
//     ) => {
//       if (acceptedFiles.length === 0) return;

//       const file = acceptedFiles[0];
//       console.log('acceptedFiles', acceptedFiles);
//       const formData = new FormData();
//       formData.append('file', file);

//       try {
//         setUploading(true);

//         // Use axios to make the POST request
//         const res = await axios.post('/api/upload-file-for-schedule', formData, {
//           headers: {
//             'Content-Type': 'multipart/form-data', 
//           },
//         });

//         const data: UploadResponse = res.data;
//         console.log('data', data);

//         // if (data.success && data.files) {
//         //   // Set the file data for displaying URLs in the frontend
//         //   setUploadedFiles(data.files);
//         //   // Optionally, redirect or perform other actions
//         //   const calendlyUrl = `https://calendly.com/makeparts/15-min-parts-consult?utm_upload_id=${data.files[0].fileUrl}`;
//         //   window.location.href = calendlyUrl;
//         // } else {
//         //   alert(data.error || 'Upload failed.');
//         // }
//       } catch (error) {
//         alert('An error occurred during file upload.');
//         setUploading(false);
//       }
//     },
//     []
//   );

//   return (
//     <div className="min-h-screen bg-white text-black flex items-center justify-center px-2 relative">
//       <section className="w-full py-16">
//         <div className="max-full mx-auto text-center">
//           <h2 className="text-4xl sm:text-5xl font-bold text-sky-500 mb-4">
//             Join thousands of engineers leveraging our free DFM consultation services to accelerate innovation.
//           </h2>
//           <p className="text-lg text-gray-600">
//             Drag and drop your file anywhere on this page. Once uploaded, you'll be redirected to book a call with us.
//           </p>
//           <div className="margin-auto p-8">
//             {uploading ? (
//               <div className="flex justify-center items-center text-sky-500 space-x-2">
//                 <Loader2 className="w-5 h-5 animate-spin" />
//                 <span className="text-sm">Uploading your file...</span>
//               </div>
//             ) : (
//               <>
//                 <p className="text-gray-500 text-sm">File types: STP, STEP, X_T, Solidworks, Autodesk Inventor, DWG, DXF</p>
//                 <p className="text-gray-500 text-sm">For multiple files, please upload in a zip format</p>
//               </>
//             )}
//           </div>
//         </div>
//         <ShufflingText />
//       </section>

//       <FullScreenFileDrop OnDropFunction={handleFileUpload} />

//       {/* Display uploaded files and links */}
//       {uploadedFiles.length > 0 && (
//         <div className="mt-8 text-center">
//           <h3 className="text-2xl font-semibold text-gray-700">Uploaded Files</h3>
//           <ul className="space-y-2 mt-4">
//             {uploadedFiles.map((file) => (
//               <li key={file.fileUrl} className="text-gray-600">
//                 <p>{file.fileName}</p>
//                 <a
//                   href={file.fileUrl}
//                   target="_blank"
//                   rel="noopener noreferrer"
//                   className="text-blue-500 hover:underline"
//                 >
//                   View File
//                 </a>
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// }

export default function ScheduleWithFilePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center">
      <h1 className="text-4xl font-bold mb-4">🚧 Work in Progress</h1>
      <p className="text-lg text-gray-600">This page is under construction. Please check back soon.</p>
    </div>
  );
}
