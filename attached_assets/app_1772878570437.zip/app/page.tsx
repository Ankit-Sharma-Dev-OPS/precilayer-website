'use client'
import React, { useEffect, useState } from "react";
import '@fortawesome/fontawesome-free/css/all.css';
import Navbar from "@/app/components/layout/navbar";
import Cad from "@/app/components/landing-page/cad";
import Process from "@/app/components/landing-page/process";
import Learnmore from "@/app/components/landing-page/learnmore";
import IndustriesSection from "@/app/components/landing-page/industries";
import Perspectives from "@/app/components/landing-page/perspectives";
import Footer from "@/app/components/layout/footer";
import MainInterCom from "./components/intercom";
import Usp from "./components/landing-page/usp";


export default function Home() {

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation - Simplified */}
      <Navbar title="" />

      {/* Hero Section with Clear CTA */}
      <Cad />

      {/* Simple Process Overview */}
      <Process />

      <Usp />

      {/* Learn More Section */}
      <Learnmore />

      {/* Industries More Section */}
      <IndustriesSection />

      {/* Perspectives Section */}
      <Perspectives />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
      {/* {} */}
      <MainInterCom />
    </div>
  );
}
