'use client';
import React, { useEffect, useRef, useState } from "react";
import '@fortawesome/fontawesome-free/css/all.css';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import RoboticsContactPage from "@/components/robotics-automation/robotics-contact-page";
import SatellitePageHeroSection from "@/components/satellite-space/SatelliteHeroPage";
import SatellitePageHowWeHelpSection from "@/components/satellite-space/how-we-help";
import SatelliteManufacturingTechnologiesSection from "@/components/satellite-space/manufacturing-capabilities";
import SatellitePartsWeManufacture from "@/components/satellite-space/part-we-manufacture";
import SatellitesCompanyTrust8xPartsSection from "@/components/satellite-space/satelite-truct-8xparts";


// export const metadata = {
//   title: 'Robotics Components | 8xparts',
//   description: 'High-precision components for robotics and automation.',
// };


export default function RoboticsLandingPage() {
    const manufacturingTechSectionRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        document.title = 'Satellite & Space  | 8xparts';
    }, []);



    const handleScrollToManufacturingTechSection = () => {

        if (manufacturingTechSectionRef.current) {
            manufacturingTechSectionRef.current.scrollIntoView({
                behavior: 'smooth', // Smooth scroll
                block: 'start', // Align to the start of the section
            });
        }
    };

    return (
        <div className="min-h-screen max-w-screen mx-3 md:mx-0 bg-white">

            {/* Navigation */}
            <Navbar title="" />

            {/* Hero Section */}
            <SatellitePageHeroSection onViewCapabilitiesButtonClick={handleScrollToManufacturingTechSection} />

            {/* Simple Process Overview */}
            <SatellitePageHowWeHelpSection />

            {/* Manufacturing Technologies Section */}
            <SatelliteManufacturingTechnologiesSection ref={manufacturingTechSectionRef} />

            {/* Parts We Manufacture Section */}
            <SatellitePartsWeManufacture />

            {/* Satellites Company Trust 8xParts Section */}
            <SatellitesCompanyTrust8xPartsSection />

            {/* Contact Us Section */}
            <RoboticsContactPage heading="Start Manufacturing Your Space-Ready Components Today!" />

            {/* Footer with Comprehensive Sitemap */}
            <Footer />
        </div>
    );
}
