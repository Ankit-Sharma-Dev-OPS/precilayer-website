'use client';
import React, { useEffect, useRef, useState } from "react";
import '@fortawesome/fontawesome-free/css/all.css';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import RoboticPageHeroSection from "@/components/robotics-automation/robotics-herosection";
import RoboticPageHowWeHelpSection from "@/components/robotics-automation/how-we-help";
import RoboticManufacturingTechnologiesSection from "@/components/robotics-automation/manufacturing-technologies";
import RoboticsPartsWeManufacture from "@/components/robotics-automation/parts-we-manufacture";
import RobotticsCompanyTrust8xPartsSection from "@/components/robotics-automation/robotics-company-trust-8xparts";
import RoboticsContactPage from "@/components/robotics-automation/robotics-contact-page";


// export const metadata = {
//   title: 'Robotics Components | 8xparts',
//   description: 'High-precision components for robotics and automation.',
// };


export default function RoboticsLandingPage() {
  const manufacturingTechSectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    document.title = 'Robotics & Automation | 8xparts';
  }, []);



  const handleScrollToManufacturingTechSection = () => {
    if (manufacturingTechSectionRef.current) {
      manufacturingTechSectionRef.current.scrollIntoView({
        behavior: 'smooth', // Smooth scroll
        block: 'start', // Align to the start of the section
      });
    }
  };

  return (
    <div className="min-h-screen max-w-screen mx-3 md:mx-0 bg-white">

      {/* Navigation */}
      <Navbar title="" />

      {/* Hero Section */}
      <RoboticPageHeroSection  onViewCapabilitiesButtonClick={handleScrollToManufacturingTechSection}/>

      {/* Simple Process Overview */}
      <RoboticPageHowWeHelpSection />

      {/* Manufacturing Technologies Section */}
      <RoboticManufacturingTechnologiesSection ref={manufacturingTechSectionRef} />

      {/* Parts We Manufacture Section */}
      <RoboticsPartsWeManufacture />

      {/* Robotic Company Trust 8xParts Section */}
      <RobotticsCompanyTrust8xPartsSection />

      {/* Contact Us Section */}
      <RoboticsContactPage heading="Start Manufacturing Your Robotics Components Today!" />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
}
