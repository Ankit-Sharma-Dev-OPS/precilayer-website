'use client';
import React, { useEffect, useRef, useState } from "react";
import '@fortawesome/fontawesome-free/css/all.css';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import RoboticsContactPage from "@/components/robotics-automation/robotics-contact-page";
import MedicalDevicesSection from "@/components/medical-devices/HeroSection";
import MedicalPageHowWeHelpSection from "@/components/medical-devices/how-we-help";
import MedicalDevicesManufacturingSection from "@/components/medical-devices/manufacturing-capabilities";
import MedicalDevicesWeManufacture from "@/components/medical-devices/part-we-manfacture";
import MedicalDevicesTrust8xPartsSection from "@/components/medical-devices/medical-trust-8xparts";


// export const metadata = {
//   title: 'Robotics Components | 8xparts',
//   description: 'High-precision components for robotics and automation.',
// };


export default function MedicalDevicesHeroPage() {
    const manufacturingTechSectionRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        document.title = 'Medical devices | 8xparts';
    }, []);



    const handleScrollToManufacturingTechSection = () => {

        if (manufacturingTechSectionRef.current) {
            manufacturingTechSectionRef.current.scrollIntoView({
                behavior: 'smooth', // Smooth scroll
                block: 'start', // Align to the start of the section
            });
        }
    };
    const handleMeetOurEngineerClick = () => {
        const meetLink = process.env.NEXT_PUBLIC_ENGINEER_MEET_LINK;
        if (meetLink) {
            window.open(meetLink, "_blank");
        } else {
            console.error("Meeting link is not defined in environment variables.");
        }
    };

    return (
        <div className="min-h-screen max-w-screen mx-3 md:mx-0 bg-white">

            {/* Navigation */}
            <Navbar title="" />

            {/* Hero Section */}
            <MedicalDevicesSection onViewCapabilitiesButtonClick={handleScrollToManufacturingTechSection} />

            {/* Simple Process Overview */}
            <MedicalDevicesManufacturingSection ref={manufacturingTechSectionRef} />
            <MedicalPageHowWeHelpSection />

            {/* Manufacturing Technologies Section */}

            {/* Parts We Manufacture Section */}
            <MedicalDevicesWeManufacture />

            {/* Satellites Company Trust 8xParts Section */}
            <MedicalDevicesTrust8xPartsSection />
            <div className="bg-white p-6 rounded-xl my-2 text-gray-800  mx-auto">
                <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight text-center mb-5"> Ready to Build Your Next Medical Innovation?</h1>

                <p className=" leading-relaxed text-center ">
                    <span className="text-3xl ">Upload Your CAD File – Get instant DFM feedback & fast quotes</span>
                    <br />
                    <button className="px-6 py-3 border mt-6 border-gray-200 hover:border-gray-300 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors" onClick={handleMeetOurEngineerClick}>
                        Schedule a Technical Consultation
                    </button>
                </p>
            </div>

            
            <hr className="my-6 border-t border-gray-200" />

            {/* Contact Us Section */}
            <RoboticsContactPage heading="" />

            {/* Footer with Comprehensive Sitemap */}
            <Footer />
        </div>
    );
}
