// api/apiActions.ts
import { ContactFormData } from '@/types/types';
import axios from 'axios';

export interface SubscribeResponse {
  success: boolean;
  error?: string;
}

// Function to handle the subscription API request
export const subscribeUser = async (email: string): Promise<SubscribeResponse> => {
  try {
    const response = await axios.post('/api/subscribe', { email });

    if (response.status === 200) {
      return { success: true };
    } else {
      return { success: false, error: 'Something went wrong. Please try again later.' };
    }
  } catch (error) {
    return { success: false, error: 'Unable to subscribe. Please check your network connection.' };
  }
};


// Function to handle the contact us submit API request
export const contactUsSubmit = async (data: ContactFormData): Promise<SubscribeResponse> => {
  try {
    const response = await axios.post('/api/contact-us', data);

    if (response.status === 200) {
      return { success: true };
    } else {
      return { success: false, error: 'Something went wrong. Please try again later.' };
    }
  } catch (error) {
    return { success: false, error: 'Unable to submit contact details. Please check your network connection.' };
  }
};


// Function to hanlde the turnstile verification
export const verifyTurnstileToken = async (token: string) => {
  try {
    const response = await axios.post('/api/verify-turnstile', { token });
    return response.data;
  } catch (error) {
    console.error('Error verifying Turnstile token:', error);
    return { success: false };
  }
};