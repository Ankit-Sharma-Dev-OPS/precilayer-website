'use client'
import React from 'react';
import Image from 'next/image';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";

const IndustryInsightsPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="The Future of Manufacturing: Software-First Approach" />
      
      <section className="pt-40 lg:pt-24 pb-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
              <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight text-center mt-4">The Future of Aerospace Manufacturing: Strategic Lessons from 3D-Printed Twin-Propeller Model Development</h1>
              <Image src="/imgs/industry-airplane.png" width={300} height={300} alt="Industry Airplane" className='m-auto w-3/5' />
              <p className="text-xl text-gray-600 py-8 indent-4">In an era where rapid prototyping and efficient manufacturing processes are crucial for
              maintaining competitive advantage, a groundbreaking study from the Hubei Institute of
              Automotive Technology demonstrates how advanced manufacturing techniques are reshaping
              aerospace development. For engineering teams and procurement leaders navigating this
              evolving landscape, the insights from this twin-propeller model development offer valuable
              strategic lessons.</p>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Breaking Down the Innovation: Key Technical
              Specifications</h2>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Core Aircraft Parameters</h3>
              
              <div className="relative overflow-x-auto p-6 text-xl">
                  <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                      <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                          <tr>
                              <th scope="col" className="px-6 py-3">
                                  Parameter
                              </th>
                              <th scope="col" className="px-6 py-3">
                                  Value
                              </th>
                              <th scope="col" className="px-6 py-3">
                              Strategic Implication
                              </th>
                          </tr>
                      </thead>
                      <tbody>
                          <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                              <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                Total takeoff weight
                              </th>
                              <td className="px-6 py-4">
                              1.62 kg
                              </td>
                              <td className="px-6 py-4">
                              Optimal for prototype testing
                              </td>
                          </tr>
                          <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                              <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                              Maximum lift coefficient
                              </th>
                              <td className="px-6 py-4">
                              0.8
                              </td>
                              <td className="px-6 py-4">
                              Industry-standard performance
                              </td>
                          </tr>
                          <tr className="bg-white border-b dark:bg-gray-800">
                              <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                              Thrust to weight ratio
                              </th>
                              <td className="px-6 py-4">
                              0.8
                              </td>
                              <td className="px-6 py-4">
                              Balanced power efficiency
                              </td>
                          </tr>
                          <tr className="bg-white dark:bg-gray-800">
                              <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                              Wing aspect ratio
                              </th>
                              <td className="px-6 py-4">
                              6.98
                              </td>
                              <td className="px-6 py-4">
                              Enhanced aerodynamic efficiency
                              </td>
                          </tr>
                      </tbody>
                  </table>
              </div>

              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Material Selection and Manufacturing Parameters</h3>
                            
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Primary Material Choice:</span> PLA (Polylactic Acid)
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Environmental sustainability</li>
                        <li>High strength-to-weight ratio</li>
                        <li>Cost-effective for prototyping</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Critical Manufacturing Parameters:</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Printing temperature: 200°C</li>
                        <li>Layer thickness: 0.2mm</li>
                        <li>Fill density: 10%</li>
                        <li>Surface finishing: Post-process sanding for aerodynamic optimization</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Engineering Innovation: The Bevel Gear System</h2>
              <Image src="/imgs/industry-model.png" width={1000} height={1000} alt="Industry model" className='m-auto w-4/5' />
              <p className="text-xl text-gray-600 py-8 indent-4">The study&apos;s approach to power transmission showcases innovative problem-solving in aerospace design:</p>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Technical Specifications:</h3>              
              <ol className="space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400 p-6 text-xl">
                  <li>Module: 1.5mm</li>
                  <li>Configuration: 90° angle transmission</li>
                  <li>Material: 40Cr steel</li>
                  <li>Maximum stress tolerance: 602.6 MPa</li>
                  <li>Actual maximum stress: 489.21 MPa</li>
                  <li>Safety factor: 1.22</li>
              </ol>
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Strategic Advantages:</h3> 
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>Module: 1.5mm</li>
                  <li>Configuration: 90° angle transmission</li>
                  <li>Material: 40Cr steel</li>
                  <li>Maximum stress tolerance: 602.6 MPa</li>
                  <li>Actual maximum stress: 489.21 MPa</li>
                  <li>Safety factor: 1.22</li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Aerodynamic Analysis and Optimization</h2>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">CFD Analysis Results</h3>
              <p className="text-xl text-gray-600 py-8 indent-4">The comprehensive aerodynamic analysis revealed several key findings:</p>          
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Wing Performance</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Elliptical lift distribution</li>
                        <li>Optimized pressure gradients</li>
                        <li>Controlled boundary layer separation</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Fuselage Optimization</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Streamlined profile reducing drag</li>
                        <li>Integrated solar panel placement</li>
                        <li>Optimal structural integrity</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Manufacturing Process Integration</h2>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Critical Success Factors:</h3>
              
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Design Phase</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>CATIA-based surface modeling</li>
                        <li>Integrated structural analysis</li>
                        <li>Optimization for manufacturability</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Production Implementation</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Hybrid manufacturing approach</li>
                        <li>Quality control protocols</li>
                        <li>Assembly optimization</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Testing and Validation</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Comprehensive flight testing</li>
                        <li>Performance validation</li>
                        <li>Iterative improvement process</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Strategic Implications for Procurement</h2>
              <Image src="/imgs/industry-chart.png" width={1000} height={1000} alt="Industry Chart" className='m-auto' />

              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Cost-Benefit Analysis</h3>

              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Traditional vs. Advanced Manufacturing</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>47% reduction in prototype development time</li>
                        <li>35% cost savings in iteration cycles</li>
                        <li>60% improvement in design flexibility</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Quality Control Metrics</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Enhanced consistency in production</li>
                        <li>Reduced material waste</li>
                        <li>Improved part reliability</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Future Applications and Scaling Considerations</h2>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Industry Implementation Roadmap</h3>
              
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Short-term Goals</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Prototype development optimization</li>
                        <li>Material selection refinement</li>
                        <li>Process standardization</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Long-term Strategy</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Production scaling</li>
                        <li>Supply chain integration</li>
                        <li>Quality assurance protocols</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Procurement Strategy Integration with 8xparts</h2>
              
              <h3 className="hidden lg:block lg:text-3xl pl-8 font-bold mt-12">Leveraging Digital Procurement</h3>
              
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Instant Quoting Benefits</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Real-time pricing optimization</li>
                        <li>Material availability tracking</li>
                        <li>Supplier network integration</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Quality Assurance</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Standardized specifications</li>
                        <li>Certified supplier network</li>
                        <li>Quality tracking metrics</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight mb-6">Conclusion and Strategic Recommendations</h2>
              
              <p className="text-xl text-gray-600 py-8 indent-4">For engineering teams and procurement leaders, this study demonstrates the critical importance of:</p>
              
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Integrated Manufacturing Approaches</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Combining traditional and advanced manufacturing</li>
                        <li>Optimizing material selection</li>
                        <li>Streamlining production processes</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Strategic Procurement</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Utilizing digital platforms for efficiency</li>
                        <li>Implementing cost-optimization strategies</li>
                        <li>Maintaining quality standards</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Future-Proofing Operations</span>
                      <ul className="ps-5 mt-2 space-y-1 list-inside" style={{listStyleType: "circle"}}>
                        <li>Adopting advanced manufacturing techniques</li>
                        <li>Integrating digital procurement solutions</li>
                        <li>Maintaining competitive advantage</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>

      <div className="max-w-6xl mx-auto">
      <hr className="mb-6 "/>
        <p className="text-xl text-gray-600 pt-6 pb-12"><i>Ready to optimize your aerospace component procurement?
          Visit <a href="https://8xparts.com" className="text-sky-500">8xparts.com</a> for instant
          quotes and streamlined ordering of both traditional and advanced manufactured parts.
          For detailed technical specifications and manufacturing guidelines, contact our engineering
          support team at support@8xparts.com</i></p>
        </div>
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default IndustryInsightsPage;
