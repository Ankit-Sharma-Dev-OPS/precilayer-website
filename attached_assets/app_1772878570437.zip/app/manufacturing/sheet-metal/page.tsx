'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface FabricationItems {
  title: string;
  label: string;
}

const fabrication: FabricationItems[] = [
  {title: "Laser Cutting & Waterjet Cutting:", label: "Accurate, clean edges in various metal thicknesses."},
  {title: "Bending & Forming:", label: "Achieve complex shapes and folds with our press brake technology."},
  {title: "Welding & Assembly:", label: "MIG, TIG, and spot welding for seamless joins."},
];

interface CommonItems {
  title: string;
  label: string;
}

const common: CommonItems[] = [
  {title: "Steel (CRS, HRS, Stainless)", label: ""},
  {title: "Aluminum", label: ""},
  {title: "Galvanized & Coated Metals", label: ""},
];

interface ApplicationsItems {
  title: string;
  label: string;
}

const applications: ApplicationsItems[] = [
  {title: "Enclosures & Housings",label: ""},
  {title: "Brackets & Mounting Hardware",label: ""},
  {title: "Structural Components",label: ""},
];

const SheetMetalPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Sheet Metal Fabrication | 8xParts';
  }, []);
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Sheet Metal Fabrication Services" 
            intro="Our sheet metal fabrication services cover everything from precision cutting and bending to welding and finishing. Whether you need prototypes or production runs, we deliver sturdy, dimensionally accurate parts that meet your application’s demands."
      />

      <Paragraph id="fabrication" dark={true} title="Fabrication Techniques" items={fabrication} />

      <Paragraph id="common" dark={false} title="Common Metals" items={common} />

      <Paragraph id="applications" dark={true} title="Applications" items={applications} />

      <Started title="Looking for a reliable sheet metal partner? Request a Custom Quote or check our Design Guides for best practices." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default SheetMetalPage;
