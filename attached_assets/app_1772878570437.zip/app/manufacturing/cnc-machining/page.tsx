'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface CapabilitiesItems {
  title: string;
  label: string;
}

const capabilities: CapabilitiesItems[] = [
  { title: "3-Axis & 5-Axis CNC Milling:", label: "Ideal for complex geometries and precise cuts." },
  { title: "CNC Turning:", label: "Efficient production of cylindrical parts and threaded components." },
  { title: "Multi-Axis Machining:", label: "Perfect for intricate parts requiring multiple setups." },
];


interface CommonItems {
  title: string;
  label: string;
}

const common: CommonItems[] = [
  { title: "Metals:", label: "Aluminum, stainless steel, titanium, brass" },
  { title: "Plastics:", label: "ABS, Delrin (POM), polycarbonate, nylon" },
];
interface WhychooseItems {
  title: string;
  label: string;
}

const whychoose: WhychooseItems[] = [
  { title: "Strict Quality Control:", label: "We use advanced inspection tools (CMMs, calipers, gauges) to verify every dimension." },
  { title: "Cost-Effective Production:", label: "Volume discounts and optimized workflows reduce total project costs." },
  { title: "Design-for-Manufacturability (DFM):", label: "Our engineers provide feedback to help refine your part designs." },
];

const CncMachiningPage: React.FC = () => {
  useEffect(() => {
    document.title = 'CNC Machining | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Precision CNC Machining Services"
        intro="Experience reliable, high-precision manufacturing for metals and plastics alike. Our CNC machining facilities use advanced milling, turning, and multi-axis equipment to achieve fine tolerances while minimizing lead times."
      />
      <Paragraph id="capabilities" dark={true} title="Capabilities & Equipment" items={capabilities} />

      <Paragraph id="common" dark={false} title="Common Materials" items={common} />

      <Paragraph id="whychoose" dark={true} title="Key Benefits" items={whychoose} />

      <Started title="Ready to get started? Get a Quote or learn more about our materials in the Materials Library." />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default CncMachiningPage;
