'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface ProcessItems {
  title: string;
  label: string;
}

const process: ProcessItems[] = [
  {title: "Tooling & Mold Design:", label: "1.Expert engineers design and manufacture molds optimized for durability and efficiency."},
  {title: "Material Selection:", label: "Choose from a wide range of thermoplastics and thermosets."},
  {title: "Injection & Cooling:", label: "Automated machines ensure consistency and repeatability."},
  {title: "Quality Assurance:", label: "4.Inspection, dimensional checks, and finishing processes guarantee final part quality."},
];

interface BenefitsItems {
  title: string;
  label: string;
}

const benefits: BenefitsItems[] = [
  {title: "Cost Efficiency at Scale:", label: "Ideal for mid- to high-volume runs."},
  {title: "Consistent Quality:", label: "Minimize part-to-part variation through controlled processes."},
  {title: "Versatility:", label: "Accommodate a variety of polymers and complex part geometries."},
];

const InjectionMoldingPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Injection Molding | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Injection Molding Solutions"
            intro="Leverage the power of additive manufacturing to transform your ideas into functional prototypes or final-use parts. Our 3D printing services enable complex geometries, shorter lead times, and cost-effective production for both prototypes and small-batch runs."
      />
      <Paragraph id="process" dark={true} title="Our Process" items={process} />

      <Paragraph id="benefits" dark={false} title="Benefits" items={benefits} />

      <Started title="Ready to scale up production? Get Started or explore our Quality Standards to see how we maintain excellence." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default InjectionMoldingPage;
