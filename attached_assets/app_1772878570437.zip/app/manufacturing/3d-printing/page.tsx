'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface TechnologiesItems {
  title: string;
  label: string;
}

const technologies: TechnologiesItems[] = [
  { title: "SLS (Selective Laser Sintering):", label: "Ideal for durable, high-precision parts in nylon or similar materials." },
  { title: "SLA (Stereolithography):", label: "Perfect for smooth surface finishes and intricate details using resin-based materials." },
  { title: "MJF (Multi Jet Fusion):", label: "A versatile, cost-effective solution for producing high-quality functional parts with excellent surface finish and durability." },
  { title: "DMLS (Direct Metal Laser Sintering):", label: "A cutting-edge method for creating precise, complex metal components with unmatched strength and reliability." },
  { title: "DLP (Digital Light Processing):", label: "An ideal choice for detailed prototypes and small-scale production with exceptional accuracy and smooth finishes." },
];

interface KeyBenifitsItems {
  title: string;
  label: string;
}

const keyBenifits: KeyBenifitsItems[] = [
  { title: "Design Freedom:", label: "Create complex internal channels and geometric shapes not possible with traditional methods." },
  { title: "Fast Turnaround:", label: "Go from CAD files to physical parts in days, accelerating your product development cycle." },
  { title: "Cost Savings:", label: "Reduce waste and tooling expenses associated with conventional manufacturing." },
];




const PrintingPage: React.FC = () => {
  useEffect (() => {
    document.title = '3D Printing | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="3D Printing Services"
        intro="Leverage the power of additive manufacturing to transform your ideas into functional prototypes or final-use parts. Our 3D printing services enable complex geometries, shorter lead times, and cost-effective production for both prototypes and small-batch runs."
      />
      <Paragraph id="technologies"  dark={true} title="Our 3D Printing Technologies" items={technologies} />

      <section id="materials" className="bg-white py-12">
        <div className="mx-auto px-4 sm:px-6 max-w-6xl">
          <div className="text-center">
            <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Materials & Finishes</h2>
          </div>
        </div>
        <div className="mx-auto mt-16 max-w-6xl">
          <h3 className="mx-auto text-md text-center max-w-6xl">We offer a range of engineering-grade plastics and resins with options for post-processing, such as painting, sanding, or plating.</h3>
        </div>
      </section>

      <Paragraph id="benefits" dark={true} title="Key Benefits" items={keyBenifits} />

      <Started title="Ready to bring your next prototype to life? Request a Quote or learn more about our 3D printing materials in our Materials Library." />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default PrintingPage;
