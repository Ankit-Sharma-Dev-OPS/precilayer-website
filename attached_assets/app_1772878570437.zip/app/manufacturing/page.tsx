'use client'
import React from 'react';
import Head from "@/app/components/category-page/head";
import Section from "@/app/components/category-page/section";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface CapabilitiesItem {
  id: string;
  label: string;
  href: string;
}

const capabilities: CapabilitiesItem[] = [
  {id: "3D-Printing", label: "Rapid prototyping and complex geometries", href: "3d-printing"},
  {id: "CNC Machining", label: "Precision milling and turning", href: "cnc-machining"},
  {id: "Vacuum Casting", label: "Cost-effective short-run production", href: "vacuum-casting"},
  {id: "Sheet Metal", label: "Enclosures, brackets, and structural parts", href: "sheet-metal"},
  {id: "Injection Molding", label: "High-volume plastic part production", href: "injection-molding"},
  {id: "Assembly", label: "Seamless integration of mechanical and electronic components", href: "assembly"},
];

const ManufacturingPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Manufacturing Services | End-to-End Solutions" />
      <Head title="Comprehensive Manufacturing Services"
            intro="Welcome to our all-in-one manufacturing hub. We combine advanced technologies, expert craftsmanship, and rigorous quality control to turn your ideas into tangible products. Whether you’re seeking rapid prototyping, low-volume runs, or high-volume production, our flexible approach ensures you get the right balance of speed, precision, and cost-effectiveness."
      />
      <Section id="manufacturing" title="Our Capabilities" items={capabilities}/>

      <Started title="Ready to bring your next prototype to life? Request a Quote or learn more about our 3D printing materials in our Materials Library." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default ManufacturingPage;
