'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface HowWorksItems {
  title: string;
  label: string;
}

const howworks: HowWorksItems[] = [
  {title: "Master Model Creation:", label: "A 3D-printed or machined master is used."},
  {title: "Silicone Mold Making:", label: "The master is placed in liquid silicone, cured, and then split to form a mold."},
  {title: "Resin Casting:", label: "Resin is poured into the mold under vacuum, removing air bubbles and ensuring consistent detail."},
];


interface ResinItems {
  title: string;
  label: string;
}

const resin: ResinItems[] = [
  {title: "Polyurethane (PU) Resins:", label: "Various grades available, from rigid to flexible."},
  {title: "Clear & Colored Resins:", label: "Ideal for lenses, translucent parts, or final products requiring specific hues."},
];
interface AdvantagesItems {
  title: string;
  label: string;
}

const advantages: AdvantagesItems[] = [
  {title: "Low Upfront Cost:", label: "No expensive steel tooling."},
  {title: "Quick Turnaround:", label: "Perfect for testing market response or refining designs before mass production."},
  {title: "High-Fidelity Reproduction:", label: "Achieve fine details and superior finish."},
];

const VacuumCastingPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Vacuum Casting | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Vacuum Casting Solutions"
            intro="Vacuum casting is a cost-effective process to produce low-volume parts that closely mimic the look and feel of injection-molded components. Ideal for product validation, marketing samples, or functional prototypes, vacuum casting combines speed, detail, and surface finish quality."
      />
      
      <section id="capabilities" className="bg-gray-50 py-12">
          <div className="mx-auto px-4 sm:px-6 max-w-6xl">
            <div className="text-center">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">How It Works</h2>
            </div>
          </div>
          <div className="mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl">
            {howworks.map((item, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-xl font-bold text-sky-500 hover:text-sky-600">{item.title}</h3>
                <p className="mt-2 text-gray-600">{item.label}</p>
              </div>))}
          </div>
      </section>
    
      <section id="common" className="bg-white py-12">
          <div className="mx-auto px-4 sm:px-6 max-w-6xl">
            <div className="text-center">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Resin Options</h2>
            </div>
          </div>
          <div className="mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl">
            {resin.map((item, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-xl font-bold text-sky-500 hover:text-sky-600">{item.title}</h3>
                <p className="mt-2 text-gray-600">{item.label}</p>
              </div>))}
          </div>
      </section>

      <section id="whychoose" className="bg-gray-50 py-12">
          <div className="mx-auto px-4 sm:px-6 max-w-6xl">
            <div className="text-center">
              <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Advantages</h2>
            </div>
          </div>
          <div className="mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl">
            {advantages.map((item, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-xl font-bold text-sky-500 hover:text-sky-600">{item.title}</h3>
                <p className="mt-2 text-gray-600">{item.label}</p>
              </div>))}
          </div>
      </section>

      <Started title="Ready to explore vacuum casting for your next project? Contact Our Team to discuss your requirements." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default VacuumCastingPage;
