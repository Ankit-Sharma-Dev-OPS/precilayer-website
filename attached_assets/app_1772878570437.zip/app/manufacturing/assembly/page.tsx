'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface AssemblyItems {
  title: string;
  label: string;
}

const assembly: AssemblyItems[] = [
  {title: "Mechanical Assembly:", label: "Screws, rivets, adhesives, and welding."},
  {title: "Electronics Integration:", label: "PCB installation, wiring, soldering, and final testing."},
  {title: "Quality & Testing:", label: "Functional, stress, and burn-in tests to validate performance."},
];

interface OutsourceItems {
  title: string;
  label: string;
}

const outsource: OutsourceItems[] = [
  {title: "Time Savings:", label: "Focus on design and innovation rather than coordinating multiple vendors."},
  {title: "Cost Reduction:", label: "Consolidate suppliers, shipping, and labor."},
  {title: "Consistent Quality:", label: "One-stop accountability for product integrity."},
];

const AssemblyPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Assembly and Integration | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Assembly and Integration Services"
            intro="Let us handle sub-assembly or full product assembly to reduce logistical complexities and lead times. We integrate mechanical and electronic components, perform functional testing, and ensure each final product meets your exact requirements."
      />
      <Paragraph id="assembly" dark={true} title="Assembly Capabilities" items={assembly} />

      <Paragraph id="outsource" dark={false} title="Why Outsource Assembly?" items={outsource} />

      <Started title="Interested in streamlining your production process? Reach Out Now to learn how our assembly services can save you time and money." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default AssemblyPage;
