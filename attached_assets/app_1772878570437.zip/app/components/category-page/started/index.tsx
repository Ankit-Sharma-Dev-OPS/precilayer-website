import React from "react";
import Link from "next/link";

type StartedProps = {
    title: string;
};
const Started: React.FC<StartedProps> = ({title}) => {
    return (
        <div className="py-8 bg-gray-50 border-t">
            <div className="grid grid-cols-4 md:flex-row justify-between items-center max-w-6xl mx-auto px-8">
            <p className="col-span-3 bg-white text-center text-md text-gray-600 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">{title}</p>
            <Link href={'/'} className="px-4 mx-auto text-center py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors">
                Get Started
            </Link>
            </div>
        </div>
    );
}
export default Started;