import React from "react";
import Link from "next/link";

type Item = {
    id: string;
    href: string;
    label: string;
}

type SectionProps = {
    id: string;
    title: string;
    items: Item[];
}
const Section: React.FC<SectionProps> = ({id, title, items}) => {
    return (
        <section id={id} className="bg-gray-50 py-12">
            <div className="mx-auto px-4 sm:px-6 max-w-6xl">
            <div className="text-center">
                <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">{title}</h2>
            </div>
            </div>
            <div className="mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl">
            {items.map((item, index) => (
                <Link href={`manufacturing/${item.href}`} key={index} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-xl font-bold text-sky-500 hover:text-sky-600">{item.id}</h3>
                <p className="mt-2 text-gray-600">{item.label}</p>
                </Link>))}
            </div>
        </section>
    )
}

export default Section;