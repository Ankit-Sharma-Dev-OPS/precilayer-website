import React from "react";

type Item = {
  title: string;
  label: string;
}

type ParagraphProps = {
  id: string;
  title: string;
  dark: boolean;
  items: Item[];
  paragraphType?: string;
}
const Paragraph: React.FC<ParagraphProps> = ({ id, dark, title, items, paragraphType }) => {
  return (
    <section id={id} className={`${dark ? "bg-gray-50" : "bg-white"} py-12`}>
      <div className="mx-auto px-4 sm:px-6 max-w-6xl">
        <div className="text-center">
          {paragraphType == "small-header-with-cta" ?
            <>
              <h2
                className="pl-4 text-2xl font-bold text-sky-500 tracking-tight"
              >
                {title}
              </h2>
            </>
            :
            <>
              <h2
                className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight"
              >
                {title}
              </h2>
            </>}

        </div>
      </div>
      {paragraphType == "small-header-with-cta" ?
        <div className="text-center w-full mt-4">

          <button
            className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
            onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
          >
            Explore
          </button>


        </div>
        :
        <>
          <div className={`mx-auto mt-16 grid grid-cols-1 md:grid-cols-2 ${items.length == 3 ? "lg:grid-cols-3" : ""} gap-8 max-w-6xl`}>
            {items.map((item, index) => (
              <div key={index} className={`${dark ? "bg-white" : "bg-gray-50"} rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow`}>
                <h3 className="text-xl font-bold text-sky-500 hover:text-sky-600">{item.title}</h3>
                <p className="mt-2 text-gray-600">{item.label}</p>
              </div>))}
          </div>
        </>
      }

    </section >
  )
}

export default Paragraph;