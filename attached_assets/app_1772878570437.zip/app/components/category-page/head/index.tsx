import React from "react";

type HeadProps = {
    title: string;
    intro: string;
    additionalClasses?: string;
}

const Head: React.FC<HeadProps> = ({ title, intro, additionalClasses }) => {
    return (
        <div className={`${additionalClasses}`}>
            <section className="pt-32  pb-10 ">
                <div className="max-w-6xl mx-auto px-4 sm:px-6 ">
                    <h1 className="text-4xl sm:text-5xl  font-bold text-gray-900 tracking-tight text-center">{title}</h1>
                </div>
            </section>
            <section className="pb-16">
                <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
                    <h2 className="pl-4 text-4xl sm:text-5xl font-bold text-sky-500 tracking-tight">Introduction</h2>
                    <p className="text-md text-gray-600 py-8 indent-4">{intro}</p>
                </div>
            </section>
        </div>
    )
}

export default Head;