'use client';

import React, { useEffect } from 'react';
import Intercom from '@intercom/messenger-js-sdk';

export default function MainInterCom() {
    useEffect(() => {
        Intercom({
            app_id: 'ohp610ec',
        });
    }, []);

    return null;
}
