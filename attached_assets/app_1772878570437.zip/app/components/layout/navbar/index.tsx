'use client';
import Image from "next/image";
import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname, useRouter } from 'next/navigation';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHome } from "@fortawesome/free-solid-svg-icons";
import { faRocket } from "@fortawesome/free-solid-svg-icons";



type TitleComponentProps = {
  title: string;
};

type items = {
  href: string,
  label: string,
}

type DropDownKey = {
  manufacturing: items[],
  resources: items[],
  company: items[],
}

const Navbar: React.FC<TitleComponentProps> = ({ title }) => {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const pathname = usePathname();  // Use usePathname from next/navigation
  const topRef = useRef<HTMLDivElement | null>(null);
  const router = useRouter();
  const [innerWidth, setInnerWidth] = useState<number>(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false); // Track mobile menu open/close
  const [openDropdown, setOpenDropdown] = useState<string | null>(null); // Track dropdown open state

  const dropdownData: DropDownKey = {
    manufacturing: [
      { href: "/manufacturing/3d-printing", label: "3D Printing" },
      { href: "/manufacturing/cnc-machining", label: "CNC Machining" },
      { href: "/manufacturing/vacuum-casting", label: "Vacuum Casting" },
      { href: "/manufacturing/sheet-metal", label: "Sheet Metal" },
      { href: "/manufacturing/injection-molding", label: "Injection Molding" },
      { href: "/manufacturing/assembly", label: "Assembly" },
    ],
    resources: [
      { href: "/resources/materials-library", label: "Materials Library" },
      { href: "/resources/quality-standards", label: "Quality Standards" },
      { href: "https://knowledge.8xparts.com/en/collections/11511425-perspectives", label: "Perspectives" },
      { href: "https://knowledge.8xparts.com/en/articles/10355696-8xparts-faqs", label: "FAQ" }
    ],
    company: [
      { href: "/company/about-us", label: "About Us" },
      { href: "/company/careers", label: "Careers" },
      { href: "/company/contact", label: "Contact" }
    ],
  };

  // Handle screen resize
  useEffect(() => {
    setInnerWidth(window.innerWidth);
    window.addEventListener('resize', () => setInnerWidth(window.innerWidth));

    return () => window.removeEventListener('resize', () => setInnerWidth(window.innerWidth));
  }, []);

  // Handle scroll visibility of "Get Started" button
  useEffect(() => {
    const handleScroll = () => {
      console.log("Scroll event triggered", window.scrollY);
      if (window.scrollY > 600) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    if (pathname === "/") {
      window.addEventListener("scroll", handleScroll);

      return () => {
        window.removeEventListener("scroll", handleScroll);
      };
    } else {
      setIsVisible(true); // Always visible on other pages
    }
  }, [pathname]);

  // Scroll to top when button is clicked
  const scrollToTop = () => {
    if (pathname === '/') {
      if (topRef.current) {
        topRef.current.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      router.push('/');  // Navigate to base route
    }
  };

  // Handle dropdown toggle
  const handleDropdownClick = (dropdownName: string) => {
    setOpenDropdown(openDropdown === dropdownName ? null : dropdownName);
  };

  // Handle mobile menu toggle
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Handle click outside of dropdowns to close them
  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
      if (openDropdown) {
        const dropdownElements = Object.keys(dropdownData).map(name => document.getElementById(`${name}-dropdown`));
        if (dropdownElements.every(dropdownElement => !dropdownElement?.contains(event.target as Node))) {
          setOpenDropdown(null);
        }
      }
    };

    document.addEventListener('click', handleClick);

    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, [openDropdown, dropdownData]);

  const largeScreenPathToShowMenu: Array<string> = [
    '/',
    '/industries/robotics-automation',
    '/industries/satellite-space',
    '/industries/medical-devices',
    '/industries/air-mobility',
  ]

  return (
    <div className="">
      {/* Top reference for scrolling */}
      <div ref={topRef}></div>

      {/* Navbar */}
      <nav className="fixed  w-screen z-50 bg-white lg:border-b ">
        <div className=" mx-auto px-4 sm:px-6 lg:border-none border-b border-gray-100">
          <div className="flex justify-between items-center ">
            {/* Logo */}
            <Link href={"/"}>
              <Image
                src="/imgs/8X-Parts-Logo.svg"
                alt="type"
                width={0}
                height={0}
                className="md:w-40 h-20 w-28 md:h-28 -m-[10px]"
              />
            </Link>

            {/* {title && <h3 className="hidden lg:block lg:text-2xl font-bold">{''}</h3>} */}

            {/* Button and Navbar Links */}
            <div className="flex items-center gap-x-8">
              {/* Mobile Menu Toggle Button */}
              <button className="lg:hidden" onClick={toggleMobileMenu}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
              </button>

              {/* Dropdown Menus for larger screens */}
              {(innerWidth >= 1024) && (
                <div className={`navbar flex items-center space-x-8 ${!isVisible ? "me-10" : ''}`}>
                  {Object.keys(dropdownData).map((dropdownName) => (
                    <div key={dropdownName} className="relative inline-block text-left">
                      <button
                        type="button"
                        className="inline-flex justify-center"
                        onClick={() => handleDropdownClick(dropdownName)}
                      >
                        {dropdownName.charAt(0).toUpperCase() + dropdownName.slice(1)} {/* Capitalized name */}
                        <svg className="-mr-1 size-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fillRule="evenodd" d="M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
                        </svg>
                      </button>
                      <div
                        id={`${dropdownName}-dropdown`}
                        className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white ring-1 shadow-lg ring-black/5 focus:outline-hidden"
                        style={{ display: openDropdown === dropdownName ? 'block' : 'none' }}
                      >
                        <div className="py-1">
                          {dropdownData[dropdownName as keyof typeof dropdownData].map((link) => (
                            <Link key={link.href} href={link.href} className="block px-4 py-2 text-sm text-gray-700">
                              {link.label}
                            </Link>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Get Started Button */}
              {isVisible && (
                <button
                  style={{
                    visibility: isVisible ? "visible" : "hidden",
                    opacity: isVisible ? 1 : 0,
                    transition: "opacity 0.3s ease",
                  }}
                  className="hidden lg:flex border  items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors"
                  onClick={scrollToTop}
                >
                  <FontAwesomeIcon icon={faRocket} />
                  <span className="whitespace-nowrap">Get Started</span>
                </button>
              )}

              {/* <Link
                href={'/'}

                className="hidden  w-full lg:flex items-center justify-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors"
              >
                <FontAwesomeIcon icon={faHome} />
                <span>Home</span>
              </Link> */}
            </div>
          </div>
        </div>

        {/* Title on small screens */}
        {title && <h3 className="block md:text-xl  lg:text-2xl lg:hidden font-bold text-center  ">{title}</h3>}

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <>
            <div className="lg:hidden bg-white shadow-md">
              {Object.keys(dropdownData).map((dropdownName: string) => (
                <div key={dropdownName} className="py-2">
                  <button
                    type="button"
                    className="w-full text-left px-4 py-2 text-sm text-gray-700"
                    onClick={() => handleDropdownClick(dropdownName)}
                  >
                    {dropdownName.charAt(0).toUpperCase() + dropdownName.slice(1)}
                  </button>
                  {openDropdown === dropdownName && (
                    <div className="py-2 pl-4">
                      {dropdownData[dropdownName as keyof DropDownKey].map((link: items) => (
                        <Link key={link.href} href={link.href} className="block text-sm text-gray-700 py-2">
                          {link.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div className="px-2 py-3">
                {isVisible && (
                  <button
                    style={{
                      visibility: isVisible ? "visible" : "hidden",
                      opacity: isVisible ? 1 : 0,
                      transition: "opacity 0.3s ease",
                    }}
                    className="w-full my-1  text-center px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors"
                    onClick={scrollToTop}
                  >
                    <FontAwesomeIcon icon={faRocket} />
                    <span className="whitespace-nowrap">Get Started</span>
                  </button>
                )}
                {/* <Link
                href={'/'}

                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors"
              >
                <FontAwesomeIcon icon={faHome} />
                <span>Home</span>
              </Link> */}
              </div>
            </div>
          </>

        )}
      </nav>
    </div>
  );
};

export default Navbar;
