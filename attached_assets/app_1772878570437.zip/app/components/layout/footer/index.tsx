import React from "react";
import Image from "next/image";
import Link from 'next/link';
import { useRefContext } from "@/context/useRefContext";

const Footer: React.FC = () => {
  const { scrollToViewAllPostComponent } = useRefContext();





  return (
    <footer className="bg-gray-50 border-t border-gray-100 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {/* Company Information */}
          <div className="col-span-2">
            <Link href={"/"}>
              <Image
                src="/imgs/8X-Parts-Logo.svg"
                alt="type"
                width={64}
                height={64}
                className="w-24"
              />
            </Link>
            <p className="text-sm text-gray-600 my-4">Digital manufacturing at your fingertips!</p>
            <div className="flex space-x-4">
              <a href="https://www.linkedin.com/company/8xparts-inc" className="text-gray-400 hover:text-gray-500">
                <i className="fab fa-linkedin text-2xl"></i>
              </a>
              <a href="https://www.x.com" className="text-gray-400 hover:text-gray-500">
                <i className="fas fa-xmark text-2xl"></i>
                {/* <i className="fab fa-twitter text-2xl"></i> */}
              </a>
            </div>
          </div>

          {/* Manufacturing */}
          <div>
            <Link
              href={`/manufacturing`}
              className="text-sm font-semibold text-gray-900"
            >
              Manufacturing
            </Link>
            <ul className="space-y-3 mt-4">
              {[
                "3D Printing",
                "CNC Machining",
                "Vacuum Casting",
                "Sheet Metal",
                "Injection Molding",
                "Assembly",
              ].map((item) => (
                <li key={item}>
                  <Link
                    href={`/manufacturing/${item.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-sm text-gray-600 hover:text-gray-900"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <Link
              href={`/resources`}
              className="text-sm font-semibold text-gray-900"
            >
              Resources
            </Link>
            <ul className="space-y-3 mt-4">
              {[
                "Materials Library",
                "Quality Standards",
                "Perspectives",
                // "Design Guides",
                // "Case Studies",
                "FAQ",
              ].map((item) => (
                <li key={item}>
                  {item === "Perspectives" ? (
                    <a
                     href="https://knowledge.8xparts.com/en/collections/11511425-perspectives"
                      className="text-sm text-gray-600 hover:text-gray-900"
                    >
                      {item}
                    </a>
                  ) : item != "FAQ" ? (
                    // Handle normal link
                    <Link
                      href={`/resources/${item.toLowerCase().replace(/\s+/g, "-")}`}
                      className="text-sm text-gray-600 hover:text-gray-900"
                    >
                      {item}
                    </Link>
                  ) : (
                    // Handle normal link
                    <a
                      href={`https://knowledge.8xparts.com/en/articles/10355696-8xparts-faqs`}
                      
                      className="text-sm text-gray-600 hover:text-gray-900"
                    >
                      {item}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <Link
              href={`/company`}
              className="text-sm font-semibold text-gray-900"
            >
              Company
            </Link>
            <ul className="space-y-3 mt-4">
              {[
                "About Us",
                "Careers",
                "Contact",
                // "Partner Network",
                // "Security",
                // "Terms & Privacy",
              ].map((item) => (
                <li key={item}>
                  <Link
                    href={`/company/${item.toLowerCase().replace(/\s+/g, '-')}`}
                    className="text-sm text-gray-600 hover:text-gray-900"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="mt-12 pt-8 border-t border-gray-200 max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center px-6">
          <div className="flex space-x-6 md:order-2">
            <Link href='/company/terms' className="text-sm text-gray-600 hover:text-gray-900">Terms</Link>
            {/* <Link href='/company/security' className="text-sm text-gray-600 hover:text-gray-900">Security</Link> */}
            <Link href='/company/privacy' className="text-sm text-gray-600 hover:text-gray-900">Privacy</Link>
            {/* <a href="#terms" className="text-sm text-gray-600 hover:text-gray-900">Terms</a>
                  <a href="#privacy" className="text-sm text-gray-600 hover:text-gray-900">Privacy</a>
                  <a href="#security" className="text-sm text-gray-600 hover:text-gray-900">Security</a> */}
          </div>
          <p className="text-sm text-gray-600 md:order-1">
            © 2024 8xParts, Inc. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
