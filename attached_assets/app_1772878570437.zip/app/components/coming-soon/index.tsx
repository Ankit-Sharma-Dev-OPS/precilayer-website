"use client";
import React, { useState, useEffect } from "react";

import Image from "next/image";
import TurnstileComponent from "@/components/icons/TurnstileComponent";
import { isValidEmail } from "@/utils/helper";
import { subscribeUser, verifyTurnstileToken } from "@/app/actions/actions";
import { toast } from "react-toastify";
import dynamic from "next/dynamic";


const Lottie = dynamic(() => import("lottie-react"), { ssr: false });

const ComingSoon: React.FC = () => {
    const [email, setEmail] = useState<string>("");
    const [message, setMessage] = useState<string>("");
    const [animationData, setAnimationData] = useState<any>(null);
    const [isClient, setIsClient] = useState(false);

    // Fetch Lottie animation from the public folder
    useEffect(() => {
        if (!isClient) return;
        fetch("/jsonAnimations/coming-soon.json")
            .then((res) => res.json())
            .then((data) => setAnimationData(data))
            .catch((error) => console.error("Error loading animation:", error));
    }, [isClient]);


    useEffect(() => {
        setIsClient(true);
    }, []);


    // Handle subscription form submission
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [token, setToken] = useState<string>('');
    const lottieOptions = {
        loop: true,
        autoplay: true,
        animationData,
        rendererSettings: {
            preserveAspectRatio: "xMidYMid slice",
        },
    };
    const handleSubscribe = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (!isValidEmail(email)) {
                setError('Please enter a valid email address.');
                return;
            }

            if (!token) {
                setError("Captcha verification failed. Please try again.");
                return;
            }

            const turnstileResponse = await verifyTurnstileToken(token);

            if (turnstileResponse.success) {
                setError(null);
                setIsLoading(true)
                const result = await subscribeUser(email);
                if (result.success) {
                    setIsModalOpen(true);
                    setEmail('');
                } else {
                    setError(result.error || 'Something went wrong.');
                }
            }



        } catch (err) {
            toast.error("Something went wrong while subscribing to new letter. Please try again later.");
        } finally {
            setIsLoading(false);
        }

    };
    const handleTurnstileVerify = (token: string) => {
        setToken(token);
    };

    return (
        <div style={styles.container} className=" ">
            {/* Logo */}
            <div className="grid grid-cols-2 h-40  items-center     w-full">
                <div className=" ms-64 " >
                    <Image
                        src="/imgs/8X-Parts-Logo.svg"
                        alt="type"
                        width={150}
                        height={150}
                    />
                </div>
                <div style={styles.animationContainer} className="">
                    {animationData && isClient ? (
                        <Lottie className="h-[170px]  w-[500px] " animationData={animationData} />
                    ) : (
                        <p>Loading animation...</p>
                    )}
                </div>
            </div>

            {/* Content Card */}
            <div style={styles.card} className="overflow-auto mb-20 scrollbar-none  ">
                <h1 style={styles.title}>We&apos;re Expanding Globally! 🌍</h1>
                <p style={styles.text}>
                    We&apos;re not in your country yet, but stay tuned! We&apos;re rolling out to new locations soon.
                    In the meantime, sign up for updates or send us your RFQs for manufacturing needs.
                </p>



                {/* Manufacturing Capabilities */}
                <h2 className="!my-0" style={styles.subtitle}>Our Manufacturing Capabilities</h2>
                <div style={styles.list} className="w-full    flex  gap-x-56 my-5 justify-center items-center">
                    <div>
                        <li>CNC Machining</li>
                        <li>3D Printing</li>
                        <li>Sheet Metal Fabrication</li>
                        <li>Injection Molding</li>
                        <li>Laser Cutting & Engraving</li>

                    </div>
                    <div>
                        <li> Mold & Die Components</li>
                        <li>Die & Stamping Tooling</li>
                        <li>Vacuum Casting</li>
                        <li>Plastic Extrusion</li>
                        <li>EDM & Wire Cutting</li>

                    </div>
                </div>

                {/* Email Subscription Form */}
                <form onSubmit={handleSubscribe} style={styles.form}>
                    <input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        style={styles.input}
                        className="text-center"
                    />
                    <div className="w-full mt-4">
                        <TurnstileComponent onVerify={handleTurnstileVerify} />
                    </div>
                    <button className="mb-2" type="submit" style={styles.button}>
                        Get Updates
                    </button>
                </form>

                {message && <p style={styles.successMessage}>{message}</p>}

                {/* RFQ Contact Information */}
                <div className="flex justify-center items-center gap-x-2">
                    <p className="text-3xl" style={styles.text}>
                        Need a quote for manufactured parts? Send us your RFQs at:
                    </p>
                    <a href="mailto:info@8xparts.com" className="mb-3" style={styles.text}>info@8xparts.com</a>
                </div>
            </div>
            {/* Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg p-6 max-w-md mx-auto">
                        <h3 className="text-lg font-bold text-gray-900 mb-4">
                            Thank you for subscribing to our newsletter!
                        </h3>
                        <p className="text-gray-600">
                            We’re excited to keep you updated with the latest industry insights, trends, and updates. Stay tuned for valuable content delivered straight to your inbox.
                        </p>
                        <button
                            onClick={() => {
                                setIsModalOpen(false)
                            }}
                            className="mt-6 px-6 py-2   text-white font-medium rounded-lg transition-colors"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

// Inline Styles
const styles: { [key: string]: React.CSSProperties } = {
    container: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        // minHeight: "100vh",
        backgroundColor: "white",
        // padding: "20px",
        fontFamily: "Arial, sans-serif",
    },
    logo: {
        width: "150px",
        // marginBottom: "20px",
    },
    animationContainer: {
        // marginBottom: "20px",
    },
    card: {
        backgroundColor: "#ffffff",
        // padding: "20px",
        borderRadius: "10px",
        // boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        textAlign: "center",
        maxWidth: "1000px",
        width: "100%",
    },
    title: {
        fontSize: "24px",
        fontWeight: "bold",
        color: "#333333",
        marginBottom: "5px",
    },
    subtitle: {
        fontSize: "20px",
        fontWeight: "bold",
        color: "#333333",
        // marginTop: "20px",
    },
    text: {
        fontSize: "18px",
        color: "#333333",
        marginBottom: "5px",
    },
    list: {
        textAlign: "left",
        padding: "0",
        listStyleType: "disc",
        paddingLeft: "20px",
        fontSize: "18px",
        color: "#333333",
        listStyle: "none",
    },
    form: {
        marginTop: "15px",
    },
    input: {
        width: "100%",
        padding: "10px",
        borderRadius: "5px",
        border: "1px solid #cccccc",
        marginBottom: "10px",
        fontSize: "18px",
    },
    button: {
        width: "100%",
        padding: "10px",
        borderRadius: "5px",
        border: "none",
        backgroundColor: "#2A95DB",
        color: "#ffffff",
        cursor: "pointer",
        fontSize: "18px",

    },
    successMessage: {
        marginTop: "10px",
        color: "green",
        fontSize: "14px",
    },
};




export default ComingSoon;
