import React from "react";

interface Step {
  icon: string;
  title: string;
  description: string;
}

const steps: Step[] = [
  { icon: 'fa-upload', title: "Upload", description: "Upload your CAD files in any major format" },
  { icon: 'fa-tags', title: "Quote", description: "Get instant pricing and timeline with your dedicated engineer" },
  { icon: 'fa-headset', title: "Consult", description: "Get dedicated project engineering support for all your queries." },
  { icon: 'fa-wrench', title: "Manufacture", description: "Production Across Trusted Global Facilities" },
  { icon: 'fa-truck', title: "Deliver", description: "Quality-verified parts shipped" },
];

const   ProcessSteps: React.FC = () => {
  return (
    <section id="reveal-trigger" className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <h2 className="text-4xl font-bold text-gray-900 text-center">Process</h2>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-5 gap-8">
          {steps.map((step) => (
            <div key={step.title} className="text-center">
              <h3 className="text-xl font-semibold text-sky-500">
                <i className={`fas ${step.icon} pr-4`}></i>
                {step.title}
              </h3>
              <p className="mt-2 text-sm text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProcessSteps;
