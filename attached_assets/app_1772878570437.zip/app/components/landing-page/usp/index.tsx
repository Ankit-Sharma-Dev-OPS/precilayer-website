import React from 'react'

const Usp = () => {

  const items = [
    { icon: "shield", title: 'Safety', text: 'Built on Trust' },
    { icon: "award", title: 'Quality', text: 'Excellence in Every Part' },
    { icon: "truck", title: 'Delivery', text: 'Rapid Response + Full Visibility' },
    { icon: "dollar", title: 'Cost', text: '40-60% Savings' }
  ];


  return (
    <div className='max-w-6xl mx-auto px-4 sm:px-6 py-16'>
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item, index) => (
            <div key={index} className="grid grid-cols-3 gap-2 p-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-3">
              <div className="col-span-1 flex items-center justify-center">
                <i className={`fas fa-${item.icon} text-sky-500 text-4xl sm:text-5xl`} />
              </div>
              {/* Uncomment if using image instead of icon */}
              {/* <div className="col-span-1 flex items-center justify-center"><img src={`/icons/${item.icon}`} alt="" /></div> */}
              <div className="col-span-2 sm:col-span-4 md:col-span-5 lg:col-span-2">
                <p className="text-lg font-bold text-sky-500 text-center sm:text-2xl">{item.title}</p>
                <p className="text-xs text-gray-600 text-center sm:text-sm">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
    </div>
  )
}

export default Usp