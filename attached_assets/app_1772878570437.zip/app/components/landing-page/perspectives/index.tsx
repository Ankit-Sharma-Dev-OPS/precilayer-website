import { subscribeUser, verifyTurnstileToken } from "@/app/actions/actions";
import { useRefContext } from "@/context/useRefContext";
import { isValidEmail } from "@/utils/helper";
import React, { useState } from "react";
import { ButtonLoader } from "@/components/icons";
import { toast } from "react-toastify";
import TurnstileComponent from "@/components/icons/TurnstileComponent";

interface BlogPost {
  title: string;
  description: string;
  author: string;
  role: string;
  date: string;
  readTime: string;
  category: string;
  link: string;
}

const posts: BlogPost[] = [
  {
    title: 'The Future of Aerospace Manufacturing: Strategic Lessons from 3D-Printed Twin-Propeller Model Development',
    description: "In an era where rapid prototyping and efficient manufacturing processes are crucial for maintaining competitive advantage, a groundbreaking study from the Hubei Institute of Automotive Technology demonstrates how advanced manufacturing techniques are reshaping aerospace development.",
    author: 'Sarah Chen',
    role: 'Head of Engineering',
    date: 'Dec 18, 2023',
    readTime: '5 min read',
    category: 'Industry Insights',
    link: "industry-insights",
  },
  {
    title: '7 Common Injection Molding Defects That Can Double Your Part Costs.',
    description: `When manufacturing plastic parts, defects don't just impact quality - they directly affect your bottom line. Let's examine the most common defects and their cost implications.
    Contact us for expert design review within 24 hours, accurate pricing based on optimal manufacturing conditions, & dedicated engineering support throughout production.`,
    author: 'Michael Rodriguez',
    role: 'Manufacturing Lead',
    date: 'Dec 15, 2023',
    readTime: '7 min read',
    category: 'Technical Guide',
    link: "technical-guide",
  },
];

const PerspectivesSection: React.FC = () => {
  const { viewAllPostsRefValue } = useRefContext();
  const [email, setEmail] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [token, setToken] = useState<string>('');

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!isValidEmail(email)) {
        setError('Please enter a valid email address.');
        return;
      }

      if(!token){
        setError("Captcha verification failed. Please try again.");
        return;
      }

      const turnstileResponse = await verifyTurnstileToken(token);

      if (turnstileResponse.success) {
        setError(null);
        setIsLoading(true)
        const result = await subscribeUser(email);
        if (result.success) {
          setIsModalOpen(true); 
          setEmail('');
        } else {
          setError(result.error || 'Something went wrong.');
        }
      }



    } catch (err) {
      toast.error("Something went wrong while subscribing to new letter. Please try again later.");
    } finally {
      setIsLoading(false);
    }

  };

  const handleTurnstileVerify = (token: string) => {
    setToken(token);
  };

  return (
    <section className="py-16 bg-white" ref={viewAllPostsRefValue}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row justify-between items-baseline mb-12">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Perspectives</h2>
            <p className="mt-2 text-xl text-gray-600">Insights from our team and industry experts</p>
          </div>
          <a href="https://knowledge.8xparts.com/en/collections/11511425-perspectives" className="mt-4 md:mt-0 text-sky-500 hover:text-sky-600 font-medium">
            View all posts →
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {posts.map((post) => (
            <div key={post.title} className="bg-gray-50 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex items-center space-x-2 text-sm text-gray-500 mb-3">
                  <span className="px-2.5 py-0.5 bg-sky-50 text-sky-600 rounded-full text-xs font-medium">
                    {post.category}
                  </span>
                  <span>·</span>
                  <span>{post.readTime}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  <a href={post.link} className="hover:text-sky-600">{post.title}</a>
                </h3>
                <p className="text-gray-600 mb-4">{post.description}</p>
                <a href={post.link} className="float-right mb-4 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors mr-6">
                  Read
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center w-full">
          <div className="inline-flex flex-col items-center">

            <form className="flex flex-col items-center w-full max-w-2xl gap-4 mx-auto p-6 bg-white shadow-lg rounded-lg" onSubmit={handleSubscribe}>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Subscribe to Our Newsletter</h3>
              <p className="text-gray-600 mb-6">Get the latest insights delivered to your inbox</p>

              <div className="w-full">
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-12 rounded-lg border border-gray-300 px-4 focus:border-sky-500 focus:ring-sky-500"
                  required
                />
              </div>

              <div className="w-full mt-4">
                <TurnstileComponent onVerify={handleTurnstileVerify} />
              </div>

              <button
                type="submit"
                className="w-full h-12 px-6 py-2 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors mt-4"
              >
                {isLoading ? (
                  <ButtonLoader />
                ) : (
                  "Subscribe"
                )}
              </button>

              {/* Error message if validation fails */}
              {error && <p className="text-red-500 mt-2 text-center">{error}</p>}
            </form>


          </div>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md mx-auto">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Thank you for subscribing to our newsletter!
            </h3>
            <p className="text-gray-600">
              We’re excited to keep you updated with the latest industry insights, trends, and updates. Stay tuned for valuable content delivered straight to your inbox.
            </p>
            <button
              onClick={() => {
                setIsModalOpen(false)
                window.location.reload()
              }}
              className="mt-6 px-6 py-2 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

export default PerspectivesSection;
