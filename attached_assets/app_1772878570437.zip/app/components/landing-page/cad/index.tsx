'use client';
import Script from "next/script";
import React, { useState, useEffect } from "react";
import IndustryImageCarousel from "../industries/components/IndustryImageCarousel";
import Image from "next/image";
import { ButtonLoader } from "@/components/icons";
import Usp from "../usp";

interface FileUploadProps {
  file: File | null;
  dragActive: boolean;
  handleDrag: (event: React.DragEvent<HTMLDivElement>) => void;
  handleDrop: (event: React.DragEvent<HTMLDivElement>) => void;
  setFile: React.Dispatch<React.SetStateAction<File | null>>;
}


declare global {
  interface Window {
    Calendly?: {
      showPopupWidget: (url: string) => void;
    };
  }
}


const Cad: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [isVisible, setIsVisible] = useState<boolean>(false);

  const [iframeLoading, setIframeLoading] = useState<boolean>(true);

  useEffect(() => {
    const handleScroll = () => {
      // Check if the user has scrolled down more than 100px
      if (window.scrollY > 100) {
        setIsVisible(true); // Show the button
      }
      // else {
      //   setIsVisible(false);
      // }
    };

    // Add scroll event listener when component mounts
    window.addEventListener('scroll', handleScroll);

    // Clean up the event listener when the component unmounts
    // return () => {
    //     window.removeEventListener('scroll', handleScroll);
    // };
  }, []);


  const handleDrag = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragActive(event.type === "dragenter" || event.type === "dragover");
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    setDragActive(false);
    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      setFile(event.dataTransfer.files[0]);
      event.dataTransfer.clearData();
    }
  };

  interface Item {
    icon: string;
    title: string;
    text: string;
  }
  const items: Item[] = [
    { icon: "shield", title: 'Safety', text: 'Built on Trust' },
    { icon: "award", title: 'Quality', text: 'Excellence in Every Part' },
    { icon: "truck", title: 'Delivery', text: 'Rapid Response + Full Visibility' },
    { icon: "dollar", title: 'Cost', text: '40-60% Savings' }
  ];

  const handleMeetOurEngineerClick = () => {
    const meetLink = process.env.NEXT_PUBLIC_ENGINEER_MEET_LINK;
    if (meetLink) {
      window.open(meetLink, "_blank");
    } else {
      console.error("Meeting link is not defined in environment variables.");
    }
  };
  // const handleMeetOurEngineerClick = () => {
  //   if (window.Calendly) {
  //     window.Calendly.showPopupWidget("https://calendly.com/makeparts/15-min-parts-consult");
  //   } else {
  //     console.error("Calendly is not loaded yet.");
  //   }
  // }

  return (
    <section className="pt-24 pb-16">
      <>
        {/* Add Calendly CSS */}
        <link
          href="https://assets.calendly.com/assets/external/widget.css"
          rel="stylesheet"
        />

        {/* Add Calendly Script */}
        <Script
          src="https://assets.calendly.com/assets/external/widget.js"
          strategy="lazyOnload"
          onLoad={() => console.log("Calendly script loaded successfully")}
        />

        {/* Button to trigger Calendly popup */}
      </>
      <div className="max-w-[90%] mx-auto px-6 ">
        <div className="grid  md:grid-cols-12 gap-y-2 md:gap-y-0  md:gap-x-12 items-center">
          {/* Left Content */}
          <div className="md:col-span-5">
            <h1 className="md:text-4xl   text-2xl font-bold text-gray-900 tracking-tight">
              Digital manufacturing at your fingertips!
            </h1>
            <p className="mt-6 text-xl text-gray-600 ">
              Our global network of trusted partners in North America, Europe, India, and beyond ensures top-quality, reliable manufacturing. We prioritize compliance with NDAA standards, excluding production in China, to uphold the highest values and standards.
              <br />
              <br />
              Experience precision engineering, rapid turnaround, and exceptional quality with 8xParts. Optimize your supply chain and meet your production goals with confidence.
            </p>



          </div>

          {/* File Upload Card */}
          <div className="bg-white col-span-7 rounded-lg shadow-lg p-6 border border-gray-100 text-center relative">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Get an Instant Quote for Your Parts</h2>
            {/* <div
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-300 ${
                dragActive ? "border-sky-500 bg-sky-50" : "border-gray-200"
              } ${file ? "border-green-500 bg-green-50" : ""}`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept=".stl,.step,.stp,.igs,.iges"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  if (e.target.files && e.target.files.length > 0) {
                    setFile(e.target.files[0]);
                  }
                }}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="cursor-pointer inline-flex flex-col items-center gap-4"
              >
                <div className="w-12 h-12 rounded-full bg-sky-500 flex items-center justify-center text-white">
                  ↑
                </div>
                <div>
                  <p className="font-medium text-gray-900">
                    {file ? file.name : "Drop your CAD file here"}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Supports STL, STEP, IGES files
                  </p>
                </div>
              </label>
            </div> */}

            {
              iframeLoading &&
              <div className="loader-div">
                <Image src="/imgs/quote-placeholder-1.png" width={1000} height={252} alt="" className="w-full h-[380px]" />
                {/* <div className="loading">
                  <div className="loader w-16 h-16 border-4 border-t-4 border-gray-300 border-t-sky-500 rounded-full animate-spin"></div>
                </div> */}
              </div>
            }
            <iframe
              onLoad={() => setIframeLoading(false)}
              src={`${process.env.NEXT_PUBLIC_MAKE_URL}/create-instant-quotation-iframe`}
              width="100%"
              height="380px"
              className="!h-[380px]"
              title="make.8xparts.com"
              frameBorder="0"
              allowFullScreen
              scrolling="no"
              style={{
                overflow: "hidden",
                border: "none",
                display: iframeLoading ? 'none' : 'block'
              }}
            ></iframe>




            {/* <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Process
              </label>
              <select
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500"
                value={selectedProcess}
                onChange={(e) => setSelectedProcess(e.target.value)}
              >
                <option value="">Choose a process</option>
                <option value="3d-printing">3D Printing</option>
                <option value="cnc-machining">CNC Machining</option>
                <option value="vacuum-casting">Vacuum Casting</option>
                <option value="sheet-metal">Sheet Metal Fabrication</option>
                <option value="injection-molding">
                  Injection Molding / Casting
                </option>
                <option value="assembly">Complete Assembly</option>
              </select>
            </div> */}
            {/* <button style={{ visibility: isVisible ? 'visible' : 'hidden', opacity: isVisible ? 1 : 0, transition: 'opacity 0.3s ease' }} className="mt-6 w-full px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors">
              Get a Quote
            </button> */}
          </div>
        </div>
        <IndustryImageCarousel />
        <div className="mt-2 flex justify-center flex-col sm:flex-row gap-4">
          {/* <button className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors">
                Upload CAD File
              </button> */}
          <button className="px-6 py-3 border border-gray-200 hover:border-gray-300 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors" onClick={handleMeetOurEngineerClick}>
            Schedule a Technical Consultation
          </button>
        </div>
      </div>
    </section>
  );
};

export default Cad;
