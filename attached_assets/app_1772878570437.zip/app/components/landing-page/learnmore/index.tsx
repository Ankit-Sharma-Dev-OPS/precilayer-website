import React from "react";
import { useState } from "react";
import Link from 'next/link';

interface LearnMoreItem {
  icon: string;
  title: string;
  description: string;
  extended: string;
}


const learnMoreItems: LearnMoreItem[] = [
  {
    icon: 'fa-cogs',
    title: "Manufacturing Processes",
    description: "Explore our full range of manufacturing capabilities",
    extended: "Take a deep dive into our comprehensive suite of manufacturing services designed to meet the needs of businesses both large and small. From advanced CNC machining to precision injection molding, we leverage the latest technology and industry best practices to deliver products that match your exact specifications. Whether you need rapid prototyping, low-volume runs, or large-scale production, our flexible approach ensures the perfect balance of speed, quality, and cost-efficiency.",
  },
  {
    icon: 'fa-book',
    title: "Materials Library",
    description: "Browse our extensive selection of materials",
    extended: "Choose from a vast array of materials—from metals like aluminum, stainless steel, and titanium, to engineering-grade plastics such as ABS and polycarbonate—each carefully vetted for quality and performance. Our Materials Library is continually updated with the latest innovations to ensure you have access to the right material for every part of your project. Whether you need corrosion-resistant alloys for outdoor applications or food-grade plastics for consumer products, our team can guide you toward the best-fit option.",
  },
  {
    icon: 'fa-star',
    title: "Quality Standards",
    description: "Learn about our quality control process",
    extended: "We believe that consistent quality is the cornerstone of any successful manufacturing partnership. Our rigorous inspection protocols, modern testing equipment, and adherence to global quality standards—like ISO certifications—ensure that every product meets or exceeds your expectations. Our dedicated Quality Assurance team is trained to catch deviations early and provide prompt solutions, so you can trust that every part we deliver will be ready to perform reliably in its intended application.",
  },
];

const LearnMoreSection: React.FC = () => {
  const [hov, setHov] = useState<string | number>('null');
  const onHover = (index: number) => {
    setHov(index);
  }
  const onLeave = () => {
    setHov("null");
  }
  return (
    <section className="py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="">
          <h2 className="text-4xl font-bold text-gray-900 text-center">Learn More</h2>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            {learnMoreItems.map((item, index) => (
              <div
                key={item.title}
                className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                onMouseEnter={() => onHover(index)}
                onMouseLeave={() => onLeave()}
              >
                <div className="text-sky-500 flex items-center justify-center text-xl">
                  <i className={`fas ${item.icon} pr-4`}></i>
                  <h3 className="font-semibold">{item.title}</h3>
                </div>
                {item.title == "Materials Library" ?
                  <>
                    <p 
                    className="mt-2 text-sm text-gray-600 text-center cursor-pointer text-blue-900"
                    onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                    >{item.description}
                    </p>
                    {/* <button
                      className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
                      onClick={() => window.open("https://knowledge.8xparts.com/en/articles/10479513-materials-library")}
                    >
                      Materials Library
                    </button> */}
                  </>
                  :
                  <>
                    <p className="mt-2 text-sm text-gray-600 text-center">{item.description}</p>
                  </>}
                <p className={`px-4 bg-gray-200 text-gray-600 rounded-lg text-xs mt-0 max-h-0 py-0 opacity-0 overflow-hidden ${hov == index ? "py-4 mt-4 max-h-full opacity-100" : ""}`} style={{ transition: 'max-height 0.3s ease , margin-top 0.3s ease, opacity 0.3s ease' }}>{item.extended}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LearnMoreSection;
