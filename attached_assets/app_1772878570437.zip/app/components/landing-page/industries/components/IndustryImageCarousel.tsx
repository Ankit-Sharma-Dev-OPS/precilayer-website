'use client';
import React from "react";
import Slider from "react-slick";
import Image from "next/image";

interface IndustryImageCarouselProps { }

const IndustryImageCarousel: React.FC<IndustryImageCarouselProps> = () => {
  const settings = {
    dots: false, // Show navigation dots
    infinite: true, // Infinite looping
    speed: 2000, // Transition speed
    slidesToShow: 4, // Number of images visible at a time
    slidesToScroll: 1, // Number of images to scroll at a time
    autoplay: true, // Enable autoplay
    autoplaySpeed: 50, // Autoplay interval
    responsive: [
      {
        breakpoint: 768, // For smaller screens
        settings: {
          slidesToShow: 1, // Show 1 image at a time
        },
      },
      {
        breakpoint: 1024, // For medium screens
        settings: {
          slidesToShow: 2, // Show 2 images at a time
        },
      },
    ],
  };

  const images: string[] = [
    "/imgs/MeritMedicalLogo.png",
    "/imgs/schiebel-logo.png",
    "/imgs/fordNew.jpeg",
    "/imgs/cook-medical-v1.png",
    "/imgs/IntegerLogo.png",
    "/imgs/gm-logo.png",
    "/imgs/JNJLogo.png",
    "/imgs/medtornicNew.jpeg",
    "/imgs/quantumSystemNew.jpeg",
    "/imgs/LnTNew.png",
    "/imgs/ArcelorMittal.png",
    "/imgs/tata.png",
    "/imgs/eatonNew.jpeg",
    "/imgs/ge.jpeg",
    "/imgs/joby.jpeg",
    "/imgs/safran.jpeg"

  ];

  return (
    <div className="mt-0 bg-white rounded-lg p-4">
      <p className="mt-8 mb-2 text-4xl font-bold text-gray-900 text-center">
        Trusted by
      </p>
      <Slider {...settings}>
        {images.map((src, index) => (
          <div key={index}>
            <div> {/* Fixed height */}
              <Image
                src={src}
                alt={`Carousel Image ${index + 1}`}
                width={200} 
                height={200}
                style={{ objectFit: "contain" }}
                className="mx-auto h-20"
              />
            </div>
          </div>
        ))}
      </Slider>
    </div>


  );
};

export default IndustryImageCarousel;
