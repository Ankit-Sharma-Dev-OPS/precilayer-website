import React from "react";
import Image from "next/image";
import Link from 'next/link';


interface IndustriesPost {
  title: string;
  icon: string;
  label: string;
  href?: string,
}

const industries: IndustriesPost[] = [
  {
    title: 'Advanced Air Mobility',
    icon: 'air-mobility.svg',
    label: 'Supporting the next generation of aviation with high-performance, lightweight components',
    href: '/industries/air-mobility',
  },
  {
    title: 'Robotics and Automation',
    icon: 'robotics.svg',
    label: 'Precision parts for autonomous systems and robotic applications',
    href: '/industries/robotics-automation',
  },
  {
    title: 'Satellite & Space Industry',
    icon: 'robotics.svg',
    label: 'High-Precision Manufacturing for Satellites & Spacecraft',


    href: '/industries/satellite-space',
  },
  {
    title: 'Medical Devices',
    icon: 'medical.svg',
    label: 'FDA-compliant manufacturing for medical device innovation',
    href: '/industries/medical-devices',
  },
  {
    title: 'Electric Ground Mobility',
    icon: 'mobility.svg',
    label: 'Advancing electric vehicle technology with rapid manufacturing',
  },
  {
    title: 'Industrial and Energy',
    icon: 'industrial.svg',
    label: 'Robust solutions for industrial equipment and energy systems',
  },
];

const IndustiesSection: React.FC = () => {
  return (
    <section id="industries" className="bg-gray-50 pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">Industries We Serve</h2>
          <p className="mt-4 text-xl text-gray-600">Powering the future of hardware development</p>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {industries.map((post) => (
            <div key={post.title} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <h3 className="text-xl font-bold text-gray-900 flex">
                <Image src={`/icons/${post.icon}`} width={64} height={64} className="h-16 mr-4" alt="" />
                <p className="flex items-center">{post.title}</p>
              </h3>
              {post.title == "Robotics and Automation" || post.title == 'Satellite & Space Industry' || post.title=='Advanced Air Mobility' || post.title=='Medical Devices' ?
                <>
                  <p className="mt-2 text-gray-600">{post.label}.</p>
                  <Link href={post.href || ""} target="_blank" className="underline text-blue-900">
                    Read more
                  </Link>
                </>
                :
                <>
                  <p className="mt-2 text-gray-600">{post.label}</p>
                </>}

            </div>
          ))}
        </div>
        {/* <IndustryImageCarousel/> */}
        {/* <div className="pl-4 grid grid-cols-5 gap-4 items-center bg-white rounded-lg mt-10"> 
              <Image src="/imgs/MeritMedicalLogo.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/ford-logo.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/CookMedical.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/IntegerLogo.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/gm-logo.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/JNJLogo.png" width={160} height={160} alt="" className="w-full" />
              <Image src="/imgs/MedtronicLogo.png" width={160} height={160} alt="" className="w-full" />
            </div> */}
      </div>

    </section>
  );
};

export default IndustiesSection;


