import { Inter } from "next/font/google";
import '@radix-ui/themes/styles.css';
import 'react-toastify/dist/ReactToastify.css';
import "./globals.css";
import { RefProvider } from "@/context/useRefContext";
import AnalyticsComponent from "@/components/AnalyticsComponent"; // Import the AnalyticsComponent component
import { Metadata } from "next";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "8xParts Inc - Quality parts for every project",
  description: "8xParts Inc",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
      </head>
      <body className={inter.className}>
        <RefProvider>
          <AnalyticsComponent />
          {children}
        </RefProvider>
      </body>
    </html>
  );
}
