

import ComingSoon from "../components/coming-soon";

const Page = () => {
    return (
        <div>
            <ComingSoon />
        </div>
    );
};

export default Page;
