'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface MetalsItems {
  title: string;
  label: string;
}

const metals: MetalsItems[] = [
  {title: "Aluminum:", label: "Lightweight, corrosion-resistant"},
  {title: "Stainless Steel:", label: "Durable, heat-resistant"},
  {title: "Brass & Copper:", label: "High conductivity, aesthetic appeal"},
];

interface PlasticsItems {
  title: string;
  label: string;
}

const plastics: PlasticsItems[] = [
  {title: "ABS:", label: "Versatile, impact-resistant"},
  {title: "Polycarbonate", label: "Transparent, high-strength"},
  {title: "Nylon (PA):", label: "Tough, wear-resistant"},
];

interface SpecialtyItems {
  title: string;
  label: string;
}

const specialty: SpecialtyItems[] = [
  {title: "Carbon Fiber Reinforced Polymers", label: ""},
  {title: "Glass-Filled Plastics", label: ""},
  {title: "Brass & Copper:", label: ""},
];

interface LibraryItems {
  title: string;
  label: string;
}

const library: LibraryItems[] = [
  {title: "Compare Mechanical Properties:", label: "Versatile, impact-resistant"},
  {title: "Review Surface Finish Options", label: ""},
  {title: "Identify Best-Fit Applications", label: ""},
];

const MaterialPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Materials Library | 8xParts';
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Materials Library"
            intro="Selecting the right material is critical for performance and cost-efficiency. Our extensive library features detailed information on metals, plastics, and specialty composites, each vetted to ensure reliability in various applications."
      />
      <Paragraph id="metals" dark={true} title="Metals" items={metals} />

      <Paragraph id="plastics" dark={false} title="Plastics" items={plastics} />

      <Paragraph id="specialty" dark={true} title="Specialty Composites" items={specialty} />

      <Paragraph id="library" dark={false} title="Discover our comprehensive material library with typical applications and properties-designed to help you choose the ideal materials for any industry and project." items={library} paragraphType="small-header-with-cta" />
      
      <Started title="Have questions about material compatibility or performance? Contact Our Experts for tailored guidance." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default MaterialPage;
