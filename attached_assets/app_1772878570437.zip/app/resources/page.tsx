'use client'
import React from 'react';
import Image from "next/image";
import Link from 'next/link';
import Head from "@/app/components/category-page/head";
import Section from "@/app/components/category-page/section";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface ResourcesItem {
  id: string;
  href: string;
  label: string;
}

const resources: ResourcesItem[] = [
  {id: "Materials Library", href: "materials-library", label: ""},
  {id: "Quality Standards", href: "quality-standards", label: ""},
  {id: "Blog", href: "blog", label: ""},
  {id: "Design Guides", href: "design-guides", label: ""},
  {id: "Case Studies", href: "case-studies", label: ""},
  {id: "FAQ", href: "faq", label: ""},
];

const ManufacturingPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Your Manufacturing Resource Hub" 
            intro="Empower your team with our curated resources. Find everything you need—from material selection tips and quality certifications to design best practices and real-world success stories."
      />

      <Section id="resources" title="Explore Our Resources" items={resources}/>
    
      <Started title="Have a question? Check out our FAQ or Contact Us for personalized support." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default ManufacturingPage;
