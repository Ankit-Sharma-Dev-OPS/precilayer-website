'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface CaseItems {
  title: string;
  label: string;
}

const cases: CaseItems[] = [
  {title: "Industry:", label: "Consumer, Automotive, Medical, Industrial, etc."},
  {title: "Challenge:", label: "Describe the problem or goal"},
  {title: "Solution:", label: "Manufacturing method, materials, timeline"},
  {title: "Outcome:", label: "Cost savings, improved quality, faster market entry"},
];

const CasePage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Real-World Success Stories" 
            intro="Nothing speaks louder than results. Our case studies illustrate how we’ve helped businesses of all sizes address manufacturing challenges—delivering measurable impact in quality, cost, and speed."
      />

      <Paragraph id="cases" dark={true} title="Case Study Highlights" items={cases} />
      
      <Started title="Ready to write your own success story? Contact Us to discuss how we can bring your product vision to life." />
  
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default CasePage;
