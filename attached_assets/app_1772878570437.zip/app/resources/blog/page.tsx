'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface PossibleItems {
  title: string;
  label: string;
}

const possible: PossibleItems[] = [
  {title: "Product Design & CAD Tips", label: ""},
  {title: "Industry Updates & Trends", label: ""},
  {title: "Real-World Case Studies", label: ""},
  {title: "Q&A with Experts", label: ""},
];

const BlogPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Manufacturing Insights & Industry Trends"
            intro="Explore our blog to discover best practices, deep dives into emerging technologies, and expert advice for optimizing your product development lifecycle. From case studies to how-to articles, we’ve got you covered."
      />
      <Paragraph id="possible" dark={true} title="Possible Blog Categories" items={possible} />

      <Started title="Have a topic you’d like to see covered? Let Us Know, or subscribe to our newsletter for updates." />
    
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default BlogPage;
