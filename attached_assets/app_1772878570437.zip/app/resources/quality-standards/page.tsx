'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface StandardsItems {
  title: string;
  label: string;
}

const standard: StandardsItems[] = [
  { title: "ISO 9001:", label: "Core quality management" },
  { title: "ISO 13485 (if applicable):", label: "Medical device manufacturing requirements" },
  { title: "RoHS Compliance:", label: "Hazardous substance control" },
];

interface InspectionItems {
  title: string;
  label: string;
}

const inspection: InspectionItems[] = [
  { title: "Coordinate Measuring Machines (CMMs)", label: "" },
  { title: "Optical Comparators", label: "" },
  { title: "Material Certifications & Traceability", label: "" },
];

interface ContinuousItems {
  title: string;
  label: string;
}

const continuous: ContinuousItems[] = [
  { title: "Regular Audits", label: "" },
  { title: "Ongoing Training", label: "" },
  { title: "Root Cause Analysis & Corrective Actions", label: "" },
];


const QualityPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Quality Standards | 8xParts';
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Our Commitment to Quality"
        intro="Quality is the backbone of everything we do. We’ve instituted robust inspection protocols, use advanced measurement tools, and continuously refine our processes to maintain best-in-class standards."
      />
      <Paragraph id="standard" dark={true} title="Key Standards & Certifications" items={standard} />

      <Paragraph id="inspection" dark={false} title="Inspection & Testing" items={inspection} />

      <Paragraph id="continuous" dark={true} title="Continuous Improvement" items={continuous} />

      <Started title="Want to see our quality processes in action? Request a Consultation or explore our Case Studies to learn more." />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default QualityPage;
