'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface SampleItems {
  title: string;
  label: string;
}

const sample: SampleItems[] = [
  {title: "What file formats do you accept?", label: "We typically work with STEP, IGES, and STL files. For 2D drawings, DXF or PDF is acceptable."},
  {title: "What are your typical lead times?", label: "Depending on the service, lead times can range from a few days (3D printing) to several weeks (injection molding)."},
  {title: "Do you offer volume discounts?", label: "Yes, we provide tiered pricing based on production volume."},
  {title: "How do you ensure quality?", label: "We follow ISO standards and use advanced inspection tools like CMMs. Learn more in our Quality Standards."},
];

const FaqPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Frequently Asked Questions" 
            intro="Got questions? We’ve compiled a list of answers to help you get started. If you don’t see what you’re looking for, our support team is just a message away."
      />

      {/* <Paragraph id="sample" dark={true} title="Sample Q&A" items={sample} /> */}
      
      <Started title="Still have questions? Contact Us and our team will be happy to assist." />
  
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default FaqPage;
