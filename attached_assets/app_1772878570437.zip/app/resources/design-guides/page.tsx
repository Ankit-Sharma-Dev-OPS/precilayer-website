'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface FeaturedItems {
  title: string;
  label: string;
}

const featured: FeaturedItems[] = [
  {title: "CNC Machining Best Practices", label: ""},
  {title: "3D Printing Design Essentials", label: ""},
  {title: "Injection Molding Part Optimization", label: ""},
  {title: "Sheet Metal Fabrication Tips", label: ""},
];

interface GuidesItems {
  title: string;
  label: string;
}

const guides: GuidesItems[] = [
  {title: "Reduce Errors:", label: "Avoid common pitfalls and rework."},
  {title: "Improve Aesthetics & Functionality:", label: "Learn to balance design intent with manufacturing constraints."},
  {title: "Shorten Lead Times:", label: "Fewer design revisions mean faster turnaround."},
];

const DesignPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      <Head title="Design Guides" 
            intro="Our design guides provide practical insights to ensure your parts are both manufacturable and cost-effective. Leverage these resources early in your design phase to reduce revisions, speed up production, and enhance product performance."
      />

      <Paragraph id="featured" dark={true} title="Featured Guides" items={featured} />

      <Paragraph id="guides" dark={false} title="How These Guides Help" items={guides} />
    
      <Started title="Ready for deeper insights? Download our PDF guides or Contact Our Team for one-on-one design consultations." />

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default DesignPage;
