'use client'
import React from 'react';
import Image from 'next/image';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";

const TechnicalGuidePage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="" />
      
      <section className="pt-40 lg:pt-24 pb-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
              {/* <h1 className="text-2xl sm:text-2xl font-bold text-gray-900 tracking-tight text-center">7 Common Injection Molding Defects That Can Double Your Part Costs</h1> */}
              <p className="text-xl text-gray-600 py-8 indent-4">When manufacturing plastic parts, defects don&apos;t just impact quality - they directly affect your bottom line. Let&apos;s examine the most common defects and their cost implications.</p>
          </div>
      </section>
      <div className='max-w-6xl m-auto grid grid-cols-2 gap-4'>
        <div className="col-span-1 pb-16 bg-white rounded-lg shadow-lg p-8 border border-gray-100 pt-10 mx-auto px-4 sm:px-6">
            <h2 className="pl-4 text-2xl sm:text-2xl font-bold text-sky-500 tracking-tight">1. Flash: The Hidden Material Thief</h2>
            
            <p className="text-md text-gray-600 py-8 indent-4">Flash occurs when molten plastic escapes at the mold parting line or around ejector pins.</p>
            
              <Image src="/imgs/technical-flash.png" width={1000} height={1000} alt="" className='w-3/5 m-auto'/>           
            <ol className="space-y-1 text-gray-500 list-inside dark:text-gray-400 p-6 text-xl">
                <li>
                    <span className="font-semibold text-gray-900 dark:text-white">Cost Impact:</span>
                    <ul className="text-sm mt-2 space-y-1 list-disc list-inside">
                      <li>Material waste: 3-7% increase</li>
                      <li>Secondary operations: $0.10-0.30 per part</li>
                      <li>ool maintenance costs</li>
                      <li>Increased cycle time</li>
                    </ul>
                </li>
                <li>
                    <span className="font-semibold text-gray-900 dark:text-white">Prevention Through Design:</span>
                    <ul className="text-sm mt-2 space-y-1 list-disc list-inside">
                      <li>Surface finish requirement: 16μin Ra maximum</li>
                      <li>Draft angle: 1-2° minimum</li>
                      <li>Parting line surface flatness: ±0.001&ldquo;</li>
                      <li>Proper clamp force calculation: 4-5 tons/in²</li>
                    </ul>
                </li>
            </ol>
        </div>
    {/* <section className="col-span-1  pb-16"> */}
        <div className="col-span-1  pb-16 bg-white rounded-lg shadow-lg p-8 border border-gray-100 pt-10 mx-auto px-4 sm:px-6">
            <h2 className="pl-4 text-2xl sm:text-2xl font-bold text-sky-500 tracking-tight">2. Short Shots: Incomplete Parts, Complete Headaches</h2>
            
            <p className="text-md text-gray-600 py-8 indent-4">Short shots result in immediate part rejection and wasted production time.</p>
            
              <Image src="/imgs/technical-short.png" width={1000} height={1000} alt="" className='w-3/5 m-auto'/>           
            <ol className="space-y-1 text-gray-500  list-inside dark:text-gray-400 p-6 text-xl">
                <li>
                    <span className="font-semibold text-gray-900 dark:text-white">Critical Parameters:</span>
                    <ul className="text-sm mt-2 space-y-1 list-disc list-inside">
                      <li>Flow path ratio (L/T):
                          <ul className="ps-5 mt-2 space-y-1 list-inside"  style={{listStyleType: "circle"}}>
                              <li>PE: 280-100</li>
                              <li>PP: 280-150</li>
                              <li>PC: 160-90</li>
                          </ul>
                      </li>
                      <li>Injection speed: &gt;1 in³/sec</li>
                      <li>Back pressure: 50-100 PSI</li>
                      <li>Hold pressure: 150% of injection pressure</li>
                    </ul>
                </li>
            </ol>
        </div>
    {/* </section> */}
        <div className="col-span-1 pb-16 bg-white rounded-lg shadow-lg p-8 border border-gray-100 pt-10 mx-auto px-4 sm:px-6">
            <h2 className="pl-4 text-2xl sm:text-2xl font-bold text-sky-500 tracking-tight">3. Sink Marks: Surface Defects That Sink Projects</h2>
            
            <p className="text-md text-gray-600 py-8 indent-4">Sink marks appear as depressions in thick sections and near ribs.</p>
            
              <Image src="/imgs/technical-sink.png" width={1000} height={1000} alt="" className='w-3/5 m-auto'/>           
            <ol className="space-y-1 text-gray-500 list-inside dark:text-gray-400 p-6 text-xl">
                <li>
                    <span className="font-semibold text-gray-900 dark:text-white">Design Guidelines:</span>
                    <ul className="text-sm ps-5 mt-2 space-y-1 list-disc list-inside">
                      <li>Maximum wall thickness: 4mm</li>
                      <li>Rib thickness: 40-60% of wall</li>
                      <li>Uniform cooling rate</li>
                      <li>Pack time: 5-15 seconds</li>
                      <li>Cooling time calculation: t²/α</li>
                      <li>Mold temperature: Tg ±30°F</li>
                    </ul>
                </li>
            </ol>
        </div>
    
        <div className="col-span-1 pb-16 bg-white rounded-lg shadow-lg p-8 border border-gray-100 pt-10 mx-auto px-4 sm:px-6">
            <h2 className="pl-4 text-2xl sm:text-2xl font-bold text-sky-500 tracking-tight">4. Weld Lines: The Structural Weak Point</h2>
            
            <p className="text-md text-gray-600 py-8 indent-4">Weld lines form where two flow fronts meet, creating potential failure points.</p>
            
              <Image src="/imgs/technical-weld.png" width={1000} height={1000} alt="" className='w-3/5 m-auto'/>           
            <ol className="space-y-1 text-gray-500 list-inside dark:text-gray-400 p-6 text-xl">
                <li>
                    <span className="font-semibold text-gray-900 dark:text-white">Process Controls:</span>
                    <ul className="text-sm mt-2 space-y-1 list-disc list-inside">
                      <li>Melt temperature by material:</li>
                      <li>Injection velocity &gt; 3 in³/sec</li>
                      <li>Mold temperature = Tg +50°F</li>
                      <li>Second stage pressure &gt; 10,000 PSI</li>
                    </ul>
                </li>
            </ol>
        </div>
      </div>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 sm:text-4xl font-bold text-sky-500 tracking-tight">Preventing Defects with Expert Support</h2>
              
              <p className="text-xl text-gray-600 py-8 indent-4">At 8xparts, we help you avoid these costly defects through:</p>
              
              <ol className="space-y-1 text-gray-500 list-decimal list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Design Review</span>
                      <ul className="ps-5 mt-2 space-y-1 list-disc list-inside" style={{listStyleType: "circle"}}>
                        <li>Material selection optimization</li>
                        <li>Wall thickness analysis</li>
                        <li>Gate location optimization</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Process Parameter Optimization</span>
                      <ul className="ps-5 mt-2 space-y-1 list-disc list-inside" style={{listStyleType: "circle"}}>
                        <li>Temperature profile development</li>
                        <li>Pressure curve optimization</li>
                        <li>Cooling time calculation</li>
                      </ul>
                  </li>
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Continuous Support</span>
                      <ul className="ps-5 mt-2 space-y-1 list-disc list-inside" style={{listStyleType: "circle"}}>
                        <li>Real-time engineering consultation</li>
                        <li>Process troubleshooting</li>
                        <li>Design iteration support</li>
                      </ul>
                  </li>
              </ol>
          </div>
      </section>
      <section className="pb-16">
          <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <h2 className="pl-4 sm:text-4xl font-bold text-sky-500 tracking-tight">Take Action Now</h2>
              
              <p className="text-xl text-gray-600 py-8 indent-4">Don&apos;t let injection molding defects impact your project timeline and budget. Upload your part files to 8xparts.com/upload for:</p>
              
              <ol className="space-y-1 text-gray-500 list-inside dark:text-gray-400 p-6 text-xl">
                  <li>
                      <span className="font-semibold text-gray-900 dark:text-white">Process Controls:</span>
                      <ul className="ps-5 mt-2 space-y-1 list-disc list-inside">
                        <li>Expert design review within 24 hours</li>
                        <li>Accurate pricing based on optimal manufacturing conditions</li>
                        <li>Dedicated engineering support throughout production</li>
                      </ul>
                  </li>
              </ol>
              <p className='flex justify-end'>
                <a href="/" className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium rounded transition-colors mr-6">
                    Get Started
                </a>
              </p>
          </div>
      </section>
      

      <div className="max-w-6xl mx-auto">
      <hr className="mb-6 "/>
        <p className="text-xl text-gray-600 pt-6 pb-12"><i>About 8xparts: We combine cutting-edge technology with expert engineering support to
        revolutionize custom parts manufacturing.</i></p>
        </div>
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default TechnicalGuidePage;
