'use client'
import React from 'react';
import Head from "@/app/components/category-page/head";
import Section from "@/app/components/category-page/section";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface KeysectionsItems {
  id: string;
  href: string;
  label: string;
}

const keysections: KeysectionsItems[] = [
  {id: "About Us", href: "about-us", label: ""},
  {id: "Careers", href: "careers", label: ""},
  {id: "Contact", href: "contact", label: ""},
  {id: "Privacy", href: "privacy", label: ""},
  {id: "Terms", href: "terms", label: ""},
];

const ManufacturingPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Company | About Us, Careers, Contact & More" />
      <Head title="Get to Know Our Company" 
            intro="From our origin story to our global partnerships, learn what drives our team to deliver world-class manufacturing solutions. We’re committed to innovation, quality, and customer success."
      />
      
      <Section id="resources" title="Explore Our Resources" items={keysections}/>
      
      <Started title="Explore each page below or reach out directly if you’d like more information." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default ManufacturingPage;
