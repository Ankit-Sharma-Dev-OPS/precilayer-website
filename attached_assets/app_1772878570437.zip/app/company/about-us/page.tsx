'use client'
import React, { useEffect } from 'react';
import Head from "@/app/components/category-page/head";
import Paragraph from "@/app/components/category-page/paragraph";
import Started from "@/app/components/category-page/started";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";

interface MissionItems {
  title: string; 
  label: string;
}

const mission: MissionItems[] = [
  {title: "Innovation:", label: "Embrace new technologies and processes"},
  {title: "Quality:", label: "Uphold stringent standards from design to delivery"},
  {title: "Collaboration:", label: "Foster strong partnerships, both internally and externally"},
  {title: "Sustainability:", label: "Strive for responsible material usage and waste reduction"},
];

interface HistoryItems {
  title: string;
  label: string;
}

const history: HistoryItems[] = [
  {title: "Founding & Early Milestones", label: ""},
  {title: "Notable Projects & Expansions", label: ""},
  {title: "Future Vision", label: ""},
];
const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'About Us | 8xParts';
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar title="About Us | Our Mission, Values & Team" />
      <Head title="Who We Are"
            intro="We’re a diverse team of engineers, designers, and problem-solvers dedicated to helping you transform ideas into market-ready products. Since our founding, we’ve expanded our capabilities and continually invested in cutting-edge technology to better serve our clients."
      />
      <Paragraph id="mission" dark={true} title="Our Mission & Values" items={mission} />
      
      {/* <Paragraph id="history" dark={false} title="Our History" items={history} /> */}
      
      <Started title="Interested in working with us? Contact Our Team or check out our Careers page." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default AboutPage;
