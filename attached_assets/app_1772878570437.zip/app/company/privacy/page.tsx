'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

const SecurityPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Privacy Policy | Protecting Your Intellectual Property & Data" />
      <section className="pt-32  pb-10">
            <div className="max-w-6xl mx-auto px-4 sm:px-6">
                <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight text-center">8xParts Inc Privacy Policy</h1>
            </div>
        </section>
        <section className="pb-16">
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
                <p className="text-md text-gray-600 py-8 indent-4">8xParts Inc offers a range of services to customers and prospective customers to assist them insourcing and purchasing parts and assemblies. You may interact with 8xParts Inc and provide us information through our software platform, our online marketplace at www.8xparts.com (and all associated subdomains) (the &quot;Website&quot;), or by speaking with our employees and other representatives in support of your sourcing project (collectively, the &quot;Services&quot;). 8xParts Inc (&quot;8xParts&quot; or &quot;we&quot; or &quot;us&quot;) has created this Privacy Policy to explain to you our privacy practices regarding the information we gather from you when you visit Website and utilize the Services.
                <br/><br/>This Privacy Policy aims to give you information on how 8xParts Inc collects and processes your personal data through your use of the Website and our Services for our own purposes (i.e., where we are the Controller). It is intended to meet our duties as a Controller of Transparency under European data protection legislation known as the &quot;GDPR&quot; or &quot;General Data Protection Regulation&quot;. This Privacy Policy does not describe how we process personal data on our customer&aposs or any other person&aposs instructions (i.e., where we act as a Processor).
                <br/><br/>This Privacy Policy is subject to occasional revision, and if we make any material changes in the way we use your personal data, we may notify you by sending you an e-mail to the last e-mail address you provided to us and/or by prominently posting notice of the changes on our Website. Any changes to this Privacy Policy will be effective upon the earlier of thirty (30) calendar days following our dispatch of an e-mail notice to you or thirty (30) calendar days following our posting of notice of the changes on our Website. These changes will be effective immediately for new users of our Services.
                <br/><br/>Please note that at all times you are responsible for updating your personal data to provide us with your most current e-mail address. In the event that the last e-mail address that you have provided us is not valid, or for any reason is not capable of delivering to you the notice described above, our dispatch of the e-mail containing such notice will nonetheless constitute effective notice of the changes described in the notice.
                <br/><br/>If you do not wish to permit changes in our use of your personal data, you must notify us prior to the effective date of the changes that you wish to deactivate your Account with us. Continued use of our Website or Services, following notice of such changes shall indicate your acknowledgement of such changes and agreement to be bound by the terms and conditions of such changes.
                <br/><br/>What Information Do We Collect? We collect information about you in various ways when you use our Website and Services.</p>
            </div>
            <h3 className="max-w-6xl mx-auto mt-16 mb-8 px-8 text-3xl font-bold text-sky-500 hover:text-sky-600">Information You Provide</h3>
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <p className="text-md text-gray-600 py-8 indent-4">We collect the information you voluntarily provide to us. For example: We may collect personal information from you, such as your first and last name, phone number, email address, company name, job title and password when you create an account to log in to our network (&quot;Account&quot;).
              <br/><br/>When you order parts or services on our Website, we will collect all information necessary to complete the transaction, including your name, payment information, billing information and shipping information.
              <br/><br/>We retain information on your behalf, such as parts requirements, specifications, and other related data that you store using your Account.
              <br/><br/>If you provide us feedback or contact us via email, we will collect your name and email address, as well as any other content included in the email, in order to send you a reply.
              <br/><br/>In certain circumstances we may request that you provide us with photocopies of your ID and other related documents for fraud prevention purposes and to verify your identity.
              <br/><br/>When you participate in one of our surveys, we will collect the information you provide.
              <br/><br/>We may also collect personal information at other points on our Website that state that personal information is being collected.
              <br/><br/>If you provide us feedback or contact us via text message (&quot;SMS&quot;), we will collect your name and phone number, as well as any other content included in the SMS, in order to send you a reply.
              </p>
            </div>
            <h3 className="max-w-6xl mx-auto mt-16 mb-8 px-8 text-3xl font-bold text-sky-500 hover:text-sky-600">Information Collected Via Technology</h3>
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <p className="text-md text-gray-600 py-8 indent-4">We collect certain information automatically via various technological means. We collect information via technology in the following ways:
              <br/><br/>Log Files. As is true of most websites, we gather certain information automatically and store it in
              log files. This information includes aggregate information on the pages customers access or visit
              (but not on which pages individual users visit), IP addresses, browser type, Internet Service
              Provider (ISP), operating systems, date/time stamp and clickstream data. We use this
              information to analyze trends, administer the Website and better tailor our Services to our users&apos
              needs.
              <br/><br/>Cookies. Like many online services, we use cookies to collect information. &quot;Cookies&quot; are small
              files that a website or its service provider transfers to your computer&aposs hard drive through your
              Web browser that enables the website&aposs or service provider&aposs systems to recognize your browser
              and capture and remember certain information. We use cookies to help us understand your
              preferences based on previous or current site activity and compile aggregate data about
              Website traffic and Website interaction so that we can offer better Website experiences and
              tools in the future.
              <br/><br/>You can choose to have your computer warn you each time a cookie is being sent, or you can
              choose to turn off all cookies. You do this through your browser (e.g. Microsoft Internet Explorer,
              Mozilla Firefox, Google Chrome, or Apple Safari) settings. Each browser is a little different, so
              look at your browser Help menu to learn the correct way to modify your cookie preferences. If
              you turn cookies off, you won&apost have access to many features that make your Website
              experience more efficient and some of our Services will not function properly. We use cookies
              only to record session information and to tailor marketing information and other services to you.
              We do not use cookies to obtain personally identifiable information.
              <br/><br/>Pixel Tags. In addition, we use &quot;Pixel Tags&quot; (also referred to as clear Gifs, Web beacons, or
              Web bugs). Pixel Tags are tiny graphic images with a unique identifier, similar in function to
              Cookies, that are used to track online movements of Web users. In contrast to Cookies, which
              are stored on a user&aposs computer hard drive, Pixel Tags are embedded invisibly in Web pages.
              Pixel Tags also allow us to send e-mail messages in a format user can read, and they tell us
              whether e-mails have been opened to ensure that we are sending only messages that are of
              interest to our users. We may use this information to reduce or eliminate messages sent to a
              user.
              <br/><br/>Third Party Analytics. We use third party services providers, such as Google Analytics, to help
              analyse how users use the Website (&quot;Analytics Providers&quot;). Analytics Providers use Cookies to
              collect information such as how often users visit the Website, what pages they visit, and what
              other sites they used prior to coming to the Website. We use the information we get from
              Analytics Providers only to improve our Website and Services. Analytics Providers collect only
              the IP address assigned to you on the date you visit the Website, rather than your name or other
              personally identifying information. We do not combine the information generated through the
              use of Analytics Providers with your personal data.
              </p>
            </div>
            <h3 className="max-w-6xl mx-auto mt-16 mb-8 px-8 text-3xl font-bold text-sky-500 hover:text-sky-600">No Special Categories of Personal Data</h3>
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
              <p className="text-md text-gray-600 py-8 indent-4">We do not collect any &quot;Special Categories of Personal Data&quot; about you (this includes details
              about your race or ethnicity, religious or philosophical beliefs, sex life, sexual orientation,
              political opinions, trade union membership, information about your health and genetic and
              biometric data). Nor do we collect any information about criminal convictions and offences.
              </p>
            </div>
            <h3 className="max-w-6xl mx-auto mt-16 mb-8 px-8 text-3xl font-bold text-sky-500 hover:text-sky-600">How Do We Use Your Personal Information General Use</h3>
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
            <p className="text-md text-gray-600 py-8 indent-4">We will only use your personal data for the purposes for which we collected it as listed below,
              unless we reasonably consider that we need to use it for another reason and that reason is
              compatible with the original purpose.
              <br/><br/>If we need to use your personal data for an unrelated purpose, we will update this Privacy Policy
              and we will explain the legal basis which allows us to do so.
              </p>
            </div>
            <h3 className="max-w-6xl mx-auto mt-16 mb-8 px-8 text-3xl font-bold text-sky-500 hover:text-sky-600">What is our &quot;legal basis&quot; for processing your Personal Data?</h3>
            <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
            <p className="text-md text-gray-600 py-8 indent-4">
              In respect of each of the purposes for which we use your personal data, the GDPR requires us
              to ensure that we have a &quot;legal basis&quot; for that use. Most commonly, we will rely on one of the
              following legal bases:
              <br/><br/>- Where we need to perform a contract, we are about to enter into or have entered into with you
              (&quot;Contractual Necessity&quot;).
              <br/><br/>- Where it is necessary for our legitimate interests and your interests and fundamental rights do
              not override those interests (&quot;Legitimate Interests&quot;).
              <br/><br/>- Where we need to comply with a legal or regulatory obligation (&quot;Compliance with Law&quot;).
              <br/><br/>We use your personal information in the following ways:
              <br/><br/>- Facilitate the creation of and secure your Account on our network;
              <br/><br/>- Identify you as a user in our system;
              <br/><br/>- When you create an Account, you will receive e-mail from us to verify ownership of the email
              address provided when your Account was created;
              <br/><br/>- We may use your e-mail address information to provide you with administrative email
              notifications, such as order status information and updates;
              <br/><br/>- Provide the Services you request;
              <br/><br/>- Provide improved administration of our Website and Services;
              <br/><br/>- Respond to your inquires and other requests;
              <br/><br/>- For fraud protection and/or to verify your identity; and
              <br/><br/>Send newsletters, surveys, offers and other promotional materials related to our Services and
              for other marketing purposes of 8xParts Inc.
              <br/><br/>User Testimonials. We often receive testimonials and comments from users who have had
              positive experiences with our Services. We occasionally publish such content. When we publish
              this content, we may identify our users by their first and last name, company name and may
              also indicate their home city. We obtain the user&aposs consent prior to posting his or her name along
              with the testimonial.
              <br/><br/>Creation of Anonymous Data. We may create anonymous information records from your parts
              requirements and any personal information we collect by excluding information (such as your
              name) that makes the information personally identifiable to you. We use this anonymous
              information to analyze request and usage patterns so that we may enhance the content of our
              Website and improve our Services. We reserve the right to use anonymous information for any
              purpose and disclose anonymous information to third parties at our sole discretion.
              <br/><br/>What happens when you do not provide necessary personal data? Where we need to process
              your personal data either to comply with law, or to perform the terms of a contract we have with
              you and you fail to provide that data when requested, we may not be able to perform the
              contract we have or are trying to enter into with you. For example, we may not be able to
              provide you with the functionalities of the Website (e.g., setting up your account or providing a
              quote) or we may not be able to respond to or fulfil a request you make of us (e.g., for product
              information or pricing).
              <br/><br/>In this case, we may have to suspend your Account, but we will notify you if this is the case at
              the time.
              <br/><br/>Do We Share Your Information with Any Third Parties? We disclose your personal information
              as described below and as described elsewhere in this Privacy Policy.
              <br/><br/>Third Party Service Providers. We may share your personal information with third party service
              providers to: provide you with the Services that we offer you through our Website; to conduct
              quality assurance testing; to facilitate the creation of accounts; to provide technical support;
              and/or to provide other services to 8xParts Inc.
              <br/><br/>Supply Chain Partners. In order to fulfill the parts and services you order via the Services,
              8xParts Inc may work with our network of suppliers and logistics partners. As part of this
              process, we may share your information with our partners to enable them to fulfill your orders.
              <br/><br/>Corporate Restructuring. We may share some or all of your personal information in connection
              with or during negotiation of any merger, financing, acquisition or dissolution, transaction or
              proceeding involving sale, transfer, divestiture or disclosure of all or a portion of our business or
              assets. In the event of an insolvency, bankruptcy, or receivership, personal information may also
              be transferred as a business asset. If another company acquires our company, business or
              assets, that company will possess the personal information collected by us and will assume the
              rights and obligations regarding the personal information as described in this Privacy Policy.
              <br/><br/>Other Disclosures. Regardless of any of the choices you make regarding your personal
              information (as described below), 8xParts Inc may disclose personal information if it believes in
              good faith that such disclosure is necessary (a) in connection with any legal investigation; (b) to
              comply with relevant laws or to respond to subpoenas or warrants served on 8xParts Inc; (c) to
              protect or defend the rights of 8xParts Inc or users of the Website or Services; and/or (d) to
              investigate or assist in preventing any violation or potential violation of the law, this Privacy
              Policy or our Terms of Use.
              <br/><br/>How we keep your Personal Data secure. We have put in place commercially reasonable
              security measures to prevent your personal data from being accidentally lost, used or accessed
              in an unauthorized way, altered or disclosed.
              <br/><br/>We have put in place procedures to deal with any actual or suspected personal data breach. In
              the event of any such breach, we have systems in place to work with applicable regulators. In
              addition, in certain circumstances (e.g., where we are legally required to do so) we may notify
              you of breaches affecting your personal data.
              We will only retain your personal data for so long as we reasonably need to use it for the
              purposes set out above, unless a longer retention period is required by law (for example for
              regulatory purposes).
              <br/><br/>We limit access to your personal data to those employees and other staff who have a business
              need to have such access. All such people are subject to a contractual duty of confidentiality.
              <br/><br/>How long we store your Personal Data.
              We will only retain your personal data for so long as we
              reasonably need to use it for the purposes set out above, unless a longer retention period is
              required by law (for example for regulatory purposes).
              <br/><br/>Your Rights Relating to Your Personal Data Under certain circumstances, by law you have the
              right to:
              <br/><br/>Request access to your personal data. This enables you to receive a copy of the personal data
              we hold about you and to check that we are lawfully processing it.
              <br/><br/>Request correction of the personal data that we hold about you. This enables you to have any
              incomplete or inaccurate information we hold about you corrected.
              <br/><br/>Request erasure of your personal data. This enables you to ask us to delete or remove personal
              data where there is no good reason for us to continue to process it. You also have the right to
              ask us to delete or remove your personal data where you have exercised your right to object to
              processing (see below).
              <br/><br/>Object to processing your personal data. This right exists where we are relying on a Legitimate
              Interest as the legal basis for our processing and there is something about your particular
              situation, which makes you want to object to processing on this ground. You also have the right
              to object where we are processing your Personal Data for direct marketing purposes.
              <br/><br/>Request the restriction of processing of your personal data. This enables you to ask us to
              suspend the processing of personal data about you, for example if you want us to establish the
              accuracy or the reason for processing it.
              <br/><br/>Request the transfer of your personal data. We will provide you, or a third party you have
              chosen, your personal data in a structured, commonly used, machine-readable format. Note that
              this right only applies to automated information which you initially provided consent for us to use
              or where we used the information to perform a contract with you.
              <br/><br/>Withdraw consent. This right only exists where we are relying on consent to process your
              personal data (&quot;Consent Withdrawal&quot;).
              <br/><br/>How to exercise your rights. If you want to exercise any of the rights described above (except
              Consent Withdrawal, on which see below), please contact us by e-mail at privacy@8xparts.com
              or you can reach us by telephone at [PHONE NUMBER].
              <br/><br/>We rely on our Legitimate Interests as the legal basis for the processing of your personal data
              that is involved in sending you marketing communications. If you wish to exercise your right to
              object to the processing of your personal data for this purpose, you may do so by following the
              opt-out processes outlined in the marketing email you received or by contacting us directly
              (please see contact information below). Following your exercise of your right to object, we will
              promptly cease processing your personal data for the purpose of sending you marketing
              communications. Despite your indicated e-mail preferences, we may send you service-related
              communications, including notices of any updates to our Terms of Use or Privacy Policy.
              <br/><br/>Typically, you will not have to pay a fee to access your personal data (or to exercise any of the
              other rights outlined above). However, except in relation to Consent Withdrawal, we may charge
              a reasonable fee if your request is clearly unfounded, repetitive or excessive, or, we may refuse
              to comply with your request in these circumstances.
              <br/><br/>We may need to request specific information from you to help us confirm your identity and
              ensure your right to access your personal data (or to exercise any of your other rights). This is a
              security measure to ensure that personal data is not disclosed to any person who has no right to
              receive it. We may also contact you to ask you for further information in relation to your request
              to speed up our response.
              <br/><br/>We try to respond to all legitimate requests within one month. Occasionally it may take us longer
              than a month if your request is particularly complex or you have made a number of requests. In
              this case, we will notify you and keep you updated.
              <br/><br/>Complaints If you would like to make a complaint regarding this Privacy Policy or our practices
              in relation to your Personal Data, please contact us at: privacy@8xparts.com. We will reply to
              your complaint as soon as we can.
              <br/><br/>If you feel that your complaint has not been adequately resolved, please note that the GDPR
              gives you the right to contact your local data protection supervisory authority.
              <br/><br/>Privacy and Third-Party Links This Privacy Policy applies solely to information collected by our
              Website and Services. In an attempt to provide you with increased value, we may include
              third-party links on our Website. These linked sites have separate and independent privacy
              policies, and we do not have control over and do not review these linked sites. We therefore
              have no responsibility or liability for the content and activities of these linked sites. Nonetheless,
              we seek to protect the integrity of our Website and welcome any feedback about</p>
            </div>
        </section>
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default SecurityPage;
