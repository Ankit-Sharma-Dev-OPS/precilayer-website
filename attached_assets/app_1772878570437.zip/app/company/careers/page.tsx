'use client'
import React, { useEffect } from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface WhyItems {
  title: string;
  label: string;
}

const why: WhyItems[] = [
  {title: "Collaborative Culture:", label: "Cross-functional teamwork on every project"},
  {title: "Career Growth:", label: "Professional development programs and mentorship"},
  {title: "Competitive Benefits:", label: "Comprehensive healthcare, retirement plans, and flexible schedules"},
  {title: "Innovation-Driven:", label: "Access to advanced equipment and R&D opportunities"},
];

interface PositionsItems {
  title: string;
  label: string;
}

const positions: PositionsItems[] = [
  {title: "Engineering & Product Development", label: ""},
  {title: "Operations & Logistics", label: ""},
  {title: "Sales & Customer Success", label: ""},
  {title: "Marketing & Communications", label: ""},
];
const CareersPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Careers | 8xParts';
  }, []);
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Careers | Join Our Team of Innovators" />
      <Head title="Build Your Future with Us"
            intro="We’re always seeking passionate individuals to join our mission of redefining what’s possible in manufacturing. Whether you’re a seasoned engineer or new to the industry, you’ll find opportunities to grow and make a real impact."
      />
      <Paragraph id="why" dark={true} title="Why Work Here" items={why} />

      <Paragraph id="positions" dark={false} title="Open Positions" items={positions} />

      <Started title="Ready to take the next step in your career? View Our Current Openings or email us at hr@8xparts.com." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default CareersPage;
