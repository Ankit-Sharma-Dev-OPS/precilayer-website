'use client'
import React from 'react';
import Paragraph from "@/app/components/category-page/paragraph";
import Head from "@/app/components/category-page/head";
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";
import Started from "@/app/components/category-page/started";

interface PartnerItems {
  title: string;
  label: string;
}

const partner: PartnerItems[] = [
  {title: "Regional Specialists:", label: "Local expertise to minimize shipping and lead times"},
  {title: "Process Experts:", label: "Niche technologies like metal 3D printing or complex mold fabrication"},
  {title: "Scale & Volume Providers:", label: "Facilities equipped for large-scale production"},
];

interface BenefitsItems {
  title: string;
  label: string;
}

const benefits: BenefitsItems[] = [
  {title: "Faster Lead Times:", label: "Strategically located partners reduce transit time"},
  {title: "Cost Optimization:", label: "Compare quotes and select the best fit for your budget"},
  {title: "Consistent Quality:", label: "All partners adhere to our strict quality guidelines"},
];
const PartnerPage: React.FC = () => {
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Partner Network | Global Manufacturing Collaborations" />
      <Head title="Global Partner Network" 
            intro="By collaborating with an extensive network of trusted partners, we ensure you have access to specialized processes, regional resources, and diverse manufacturing capabilities. This global ecosystem allows us to meet virtually any product requirement, no matter how complex."
      />
      <Paragraph id="partner" dark={true} title="Types of Partners" items={partner} />

      <Paragraph id="benefits" dark={false} title="Benefits to You" items={benefits} />

      <Started title="Interested in partnering with us or learning more about our network? Contact Us to explore global manufacturing solutions." />
      
      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default PartnerPage;
