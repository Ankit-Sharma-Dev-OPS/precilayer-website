'use client'
import React from 'react';
import Navbar from "@/app/components/layout/navbar";
import Footer from "@/app/components/layout/footer";

const TermsPage: React.FC = () => {
  const indent: string = "    ";
  
  return (
    <div className="min-h-screen bg-white">
      <Navbar title="Terms of Service | User Agreements & Data Protection Policy" />
      <section className="pt-32  pb-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 tracking-tight text-center">Terms of Service</h1>
        </div>
    </section>
    <section className="pb-16">
      <div className="bg-white rounded-lg shadow-lg p-8 border border-gray-100 max-w-6xl pt-10 mx-auto px-4 sm:px-6">
          <p className="text-md text-gray-600 py-8 indent-4">
            These general terms of sale (the &quot;General Terms of Sale&quot;) apply to any purchase of goods and
            services (&quot;Parts&quot;) by a customer (&quot;You&quot;) from 8xParts Inc., having its place of business in New
            York, United States (&quot;8xParts, Company, we, our and us&quot;). All additional terms, guidelines, and
            rules, including our Privacy Policy, and our Terms of Use, are incorporated by reference into
            these General Terms of Sale.
            <br/><br/>
            <b>1. General</b>
            <br/>
            <p className="pl-4"><b>1.1.</b> BY PLACING AN ORDER WITH 8xParts FOR PARTS, INCLUDING BUT NOT LIMITED TO
            THE SUBMISSION OF A PURCHASE ORDER (AN &quot;ORDER&quot;), YOU ACCEPT AND ARE
            BOUND TO THESE GENERAL TERMS OF SALE (ON BEHALF OF YOURSELF OR THE
            ENTITY THAT YOU REPRESENT. IF YOU DO NOT AGREE WITH ALL OF THE PROVISIONS
            OF THESE GENERAL TERMS OF SALE, DO NOT PLACE AN ORDER.<br/></p>
            <p className="pl-4"><b>1.2.</b> YOU REPRESENT AND WARRANT THAT YOU HAVE THE RIGHT, AUTHORITY, AND
            CAPACITY TO ENTER INTO AN AGREEMENT WITH 8xParts (ON BEHALF OF YOURSELF
            OR THE ENTITY THAT YOU REPRESENT). YOU MAY NOT PLACE AN ORDER OR ACCEPT
            THESE GENERAL TERMS OF SALE IF YOU ARE NOT AT LEAST 18 YEARS OLD OR OVER
            THE LEGAL AGE REQUIRED TO ENTER INTO A VALID CONTRACT UNDER LAW
            APPLICABLE TO YOU.<br/></p>
            <p className="pl-4"><b>1.3.</b> With respect to the technical specifications for Your Order only, including material, surface
            finish and quantity, the specifications written on Your quote will prevail over these General
            Terms of Sale and/or any drawings (including 2D technical drawings) or 3D model. In all other
            cases, in the event of a conflict between the provisions contained in the Order and these
            General Terms of Sale, the General Terms of Sale will prevail.<br/></p>
            <p className="pl-4"><b>1.4.</b> No addition, alteration or substitution of these General Terms of Sale will bind 8xParts, even
            if included within an Order, and no pre-printed terms within an Order, will bind 8xParts, unless
            explicitly accepted in writing by 8xParts. All of such nonbinding terms are hereby rejected by
            both parties. 8xParts&apos;s failure to object to provisions contained in any Order or fulfilment of an
            Order shall not be construed as a waiver of these General Terms of Sale nor an acceptance of
            any such provisions.<br/></p>
            <p className="pl-4"><b>1.5.</b> Our website, apps, products, and services are designed for businesses and their
            representatives. We do not target consumers – individuals who seek to use our products and
            services for their personal or household purposes.
            <br/><br/></p>
            <b>2. Orders</b>
            <br/>
            <p className="pl-4"><b>2.1.</b> You are responsible to ensure that all information provided in a quotation request or Order
            is accurate and complete and the specifications for Your Order are in accordance with any
            instructions of 8xParts and take into account all manufacturing and other limitations as specified
            by 8xParts on its website, including its manufacturing standards or as otherwise made available
            to You.<br/></p>
            <p className="pl-4"><b> 2.2.</b> An Order submitted by You constitutes a binding commitment by You to purchase the Parts
            described therein, to which these General Terms of Sale apply.<br/></p>
            <p className="pl-4"><b> 2.3.</b> 8xParts is under no obligation to accept an Order and can reject any Order at its sole
            discretion before it has accepted the Order. Orders are deemed accepted by 8xParts only if
            confirmed by 8xParts in writing, or by 8xParts&apos; fulfilment of the Order. 8xParts may perform a
            credit check on You and require a prepayment by credit card or other assurance of payment
            prior to acceptance.<br/></p>
            <p className="pl-4"><b>2.4. </b> Acceptance of any Order is subject to the conditions precedent that: (i) there are sufficient
            resources available to 8xParts to complete Your Order within the stated timelines and at the
            stated price, (ii) Your Order was not accepted on the basis of incorrect information, including but
            not limited to information regarding pricing and specifications, (iii) the content included in Your
            Order complies with our Content Policy (as defined in Section 10.5) and (iii) the satisfactory
            fulfilment of any credit check or receipt of prepayment or other assurance of payment, as
            requested in 8xParts&apos;s sole discretion. If these conditions precedent are not met, 8xParts is
            entitled to reject or cancel Your Order.<br/></p>
            <p className="pl-4"><b>2.5. </b>8xParts is permitted to apply (i) limited deviations with regard to colour, quantity, size, or
            (shore) hardness of Parts and (ii) limited deviations to Your drawing and/or 3D data as
            necessary to increase the manufacturability of Your Order, unless 8xParts specifically agrees to
            the contrary in writing. Unless You object in writing to such deviations, you assume all
            responsibility and liability for those deviations as part of Your original Order.<br/></p>
            <p className="pl-4"><b>2.6. </b>Any changes made by You to an Order after it has been submitted are subject to 8xParts&apos;s
            acceptance and may be subject to additional charges, including additional delivery charges.<br/></p>
            <p className="pl-4"><b>2.7. </b>Once in production, as the Parts are produced for You based on Your specifications (made
            to order), it is not possible for You to cancel or terminate Your Order. Any unpaid amounts under
            the Order remain payable.<br/><br/></p>
            
            <b>3. Subcontracting</b>
            <br/>
            <p className="pl-4"><b>3.1. </b>You understand and agree that 8xParts may use its worldwide vetted network of
            subcontractors to fulfil Your Order.<br/></p>
            <p className="pl-4"><b>3.2. </b>Orders may be delivered directly from a subcontractor of 8xParts to You and not via or
            through 8xParts. Therefore, it is of utmost importance that You inspect the Parts upon delivery
            and inform 8xParts in case of any discrepancies in accordance with these General Terms of
            Sale.<br/><br/></p>
            
            <b>4. Prices</b>
            <br/>
            <p className="pl-4"><b>4.1. </b>All prices stated by 8xParts are exclusive of value added tax (VAT) or any other taxes,
            governmental fees, assessments or duties, unless expressly stated otherwise herein. You are
            responsible for all taxes associated with the Order (other than taxes based on 8xParts&apos; income).
            Without limiting the foregoing, you shall pay all applicable taxes, governmental fees,
            assessments or duties that 8xParts charges You in addition to the prices quoted.<br/></p>
            <p className="pl-4"><b>4.2. </b>In the event of changes to cost price factors, 8xParts reserves the right to pass on such
            additional costs to You.<br/></p>
            <p className="pl-4"><b>4.3. </b>If special packing or shipping instructions are agreed by 8xParts, you shall be liable for any
            additional charges incurred by 8xParts as a consequence thereof, as indicated by 8xParts.<br/><br/></p>

            <b>5. Payment</b>
            <br/>
            <p className="pl-4"><b>5.1.</b> Unless prepayment is required, you must pay all invoices within 30 days from date of
            invoice.<br/></p>
            <p className="pl-4"><b> 5.2. </b>8xParts may invoice parts of an Order separately.<br/></p>
            <p className="pl-4"><b> 5.3. </b>For all Orders that include tooling, 8xParts may require You to pay the cost of tooling prior
            to acceptance of Your Order. 8xParts is not responsible for any delay in carrying out Your Order
            caused by Your delay in making payments.<br/></p>
            <p className="pl-4"><b>5.4. </b>8xParts may require an advance payment before it fulfils Your Order. 8xParts is not
            responsible for any delay in carrying out Your Order caused by Your delay in making payments.<br/></p>
            <p className="pl-4"><b>5.5. </b>The amounts due shall, unless otherwise agreed, be paid by credit card or bank transfer, as
            indicated by 8xParts. All costs related to the method of payment shall be Your responsibility.<br/></p>
            <p className="pl-4"><b>5.6. </b>All amounts due to be paid by You to 8xParts shall be paid in full and without any deduction.
            You shall not be entitled to any right of setoff. 8xParts shall be entitled to set off any amount due
            by 8xParts to You against amounts due by You to 8xParts.<br/></p>
            <p className="pl-4"><b>5.7. </b>If any amount due is not paid when it becomes due and payable, a late payment interest of
            two percent (2%) per month, or the highest amount permitted by applicable law, whichever is
            less, shall be due and payable with respect to such amount, to be calculated from the time such
            amount became due until the time such amount is paid in full.<br/></p>
            <p className="pl-4"><b>5.8. </b>In addition, 8xParts may, in the event of any overdue payment, suspend any delivery of
            Parts to You or prevent You from placing any future Orders until all amounts due are paid.<br/><br/></p>
            
            <b>6. Specifications of Parts and Tooling</b>
            <br/>
            <p className="pl-4"><b>6.1. </b>You are responsible for providing 8xParts with correct and complete 3D CAD data and/or
            drawings to produce the Parts and tooling. All relevant files required for the production of Your
            Parts and tooling must be uploaded by You to our website or, in the event of a specific or special
            Order, provided to 8xParts in the agreed upon manner and with any and all requirement
            representations and warranties. 8xParts does not have an obligation to review any of the
            specifications, data or drawings that You provide and reserves the right to reject or cancel any
            Order that is not uploaded by You to our website.<br/></p>
            <p className="pl-4"><b>6.2. </b>8xParts uses the 3D CAD data and/or drawings, as may be provided by You, to generate
            Parts and tooling. 2D technical drawings will prevail over 3D CAD models only with respect to
            parameters for tolerances and/or threads, if specified. In all other cases, 3D CAD data will take
            precedence during production, if these have been provided before we accepted Your Order, or
            unless otherwise agreed. 8xParts is not responsible for discrepancies between 3D CAD data
            and 2D technical drawings.<br/></p>
            <p className="pl-4"><b>6.3. </b>If an Order includes threads or specific tolerances, it is Your responsibility to provide a
            technical drawing with the relevant specifications, and to ensure to indicate this in the quotation
            request and to check if this is reflected correctly in the Order.<br/></p>
            <p className="pl-4"><b>6.4.</b> 8xParts will not be responsible for incorrectly designed Parts, Parts that do not assemble
            correctly, Parts with thick cross-sections that produce sink marks, warp, or Parts produced
            based on incorrectly provided CAD data or technical drawings.<br/></p>
            <p className="pl-4"><b>6.5. </b> 8xParts rejects all responsibility for material selection and material suitability for Your
            application. 8xParts is not responsible for the fit or assembly of Parts unless specifically agreed
            upon in writing.<br/></p>
            <p className="pl-4"><b>6.6. </b>Uploading weapons or parts subject to export control regulations such as ITAR, EAR
            beyond EAR99, or EU Dual Use is a violation of our terms of use.<br/><br/></p>
            
            <b>7. Tooling Ownership and Storage</b>
            <br/>
            <p className="pl-4"><b>7.1.  </b> All custom tooling developed by You for Your Parts shall be Your property, however
            reusable proprietary components or components developed by 8xParts or its manufacturing
            partners, will remain the property of 8xParts and/or its manufacturing partners. All custom
            tooling will remain at 8xParts&apos; or its manufacturing partner&apos;s production facility, unless otherwise
            agreed between the parties in writing.<br/></p>
            <p className="pl-4"><b>7.2.  </b> As long as 8xParts is making Parts for You at 8xParts&apos; or its manufacturing partners&apos;
            production facilities, 8xParts will guarantee Your tooling for the agreed upon tool life (as stated
            in the Order). Subject to Section 7.3, 8xParts will, in its sole discretion, repair or replace worn or
            damaged tooling at 8xParts&apos; expense for the agreed upon tool life.<br/></p>
            <p className="pl-4"><b>7.3. </b>After a two-year period of inactivity of the tooling, 8xParts may, in its sole discretion, destroy
            the tooling, including any custom tooling.<br/><br/></p>
            
            <b>8. Delivery, Inspection, Acceptance, Complaints and Retention of Title</b>
            <br/>
            <p className="pl-4"><b>8.1.  </b>Shipments are sent by the commercial carrier selected by 8xParts or its manufacturing
            partners. 8xParts will pre-pay and add delivery costs to the invoice as a convenience and
            courtesy.<br/></p>
            <p className="pl-4"><b>8.2. </b>ALL ORDERS ARE NON-REFUNDABLE ONCE PLACED. 8xParts will use commercially
            reasonable efforts to ship an Order on the agreed upon dates, however shipping or delivery
            dates are estimates only. 8xParts accepts no liability for delays in the delivery or shipment of
            Orders and/or any damage or loss caused as result of such delays. 8xParts&apos; failure to meet a
            shipping date or delivery period shall not constitute a breach of the Order or these General
            Terms of Sale.<br/></p>
            <p className="pl-4"><b>8.3. </b>8xParts shall be entitled to suspend its delivery obligations under an Order in the event
            there are, in 8xParts&apos; sole discretion, reasonable and objective grounds to doubt whether You
            are able or willing to fully and timely fulfil Your payment obligations or whether You fully comply
            with any of the other terms and conditions of these General Terms of Sale.<br/></p>
            <p className="pl-4"><b>8.4. </b>You must inspect the Parts immediately upon receipt and notify 8xParts within Seven (7)
            working days of the date of delivery of the Parts, in writing, if You believe any part of an Order is
            missing, defective, wrong or damaged. Unless You have so notified 8xParts, specifying the
            nature of what is missing, wrong, or damaged within Seven (7) working days of delivery, the
            Parts will be deemed accepted, non-returnable and non-refundable.<br/></p>
            <p className="pl-4"><b>8.5. </b>Any dispute must be raised in the timeframe specific in Section 8.4 herein and if requested
            by 8xParts, You must return the Parts to 8xParts within ten (10) working days from the time of
            the request, unless otherwise agreed in writing by 8xParts. Any Parts that You return to 8xParts
            after the expiry of this period will not be processed or refunded.<br/></p>
            <p className="pl-4"><b>8.6. </b>If after receiving Your Order You alter the Parts in any way without the prior written consent
            thereto of 8xParts, the Parts will be deemed accepted, non-returnable and non-refundable.<br/></p>
            <p className="pl-4"><b>8.7. </b>8xParts shall retain the ownership to the Parts until You have paid all amounts related to the
            delivered Parts in full, including any interests, collection costs or other amounts due with respect
            to such Parts, at which time title to the Parts will pass to You.<br/><br/></p>
            
            <b>9. Intellectual property rights and publicity</b>
            <br/>
            <p className="pl-4"><b>9.1. </b>By providing data to 8xParts, You grant 8xParts an irrevocable, non-exclusive, perpetual,
            royalty-free, fully paid up, worldwide, transferable and sub-licensable right and license to use,
            copy, modify, reproduce, distribute and display the data (including 3D CAD Data and drawings),
            documentation, drawings and specifications You provide for manufacturing the Parts: (i) as
            necessary to produce, ship and sell the Parts to You and (ii) to improve our products and
            services, including, improving our machine learning and pricing algorithms. You hereby
            irrevocably waive (and agree to cause to be waived) any claims and assertions of moral rights
            or attribution with respect to Your data.<br/></p>
            <p className="pl-4"><b>9.2. </b>By placing an Order, you authorize 8xParts to use Your trademarks, logos, name or signs
            for marketing purposes. This means that 8xParts may mention You as a customer of 8xParts on
            our website and in other promotional material such as advertising, press releases, interviews,
            promotional materials or presentations. We will not use Your name if You are a natural person,
            and the substantive content provided by You continues to be governed by the confidentiality
            clauses in these General Terms of Sale.<br/><br/></p>
            
            <b>10. Your representations</b>
            <br/>
            <p className="pl-4"><b>10.1. </b>You represent and warrant that You have the right authority and capacity to enter into
            these General Terms of Sale (on behalf of Yourself or the entity that You represent) and that You
            are authorized to place an Order. You represent and warrant that You are 18 years or older, are
            able to conclude legally binding agreements.<br/></p>
            <p className="pl-4"><b>10.2. </b>You represent and warrant that You have the full right and authority to provide us with all
            data (including 3D CAD data and drawings), documentation, drawings and specifications, all
            data You provide is accurate and truthful, and You are authorized to grant the license referred to
            in Section 9.<br/></p>
            <p className="pl-4"><b>10.3. </b>You also represent and warrant that You will use Parts in strict accordance with all
            applicable U.S. federal, state and local laws and requirements.<br/></p>
            <p className="pl-4"><b>10.4. </b>You represent and warrant that You understand and agree with, including making the
            relevant certifications under, this 8xParts export control policy (the &quot;Export Control Policy&quot;), as
            follows:<br/></p>
            <p className="pl-8"><b>10.4.1. </b>You understand that 8xParts does not accept Export Controlled Data. &quot;Export Controlled
            Data&quot; is defined as data which is controlled for export under U.S. law. This includes (technical)
            data and/or end Parts that are: (1) controlled under the U.S. Munitions List (USML) or (2)
            subject to the Export Administration Regulations (EAR).<br/></p>
            <p className="pl-8"><b>10.4.2.</b> You certify that Your data (including 3D CAD data and drawings) and/or Your Order
            DOES NOT include Export Controlled Data.<br/></p>
            <p className="pl-8"><b>10.4.3. </b>You understand that by uploading Your data to the 8xParts website, You are exporting
            data to another country. 8xParts maintains operations outside of the U.S., employs non-U.S.
            persons, and has non-U.S. manufacturing partners.<br/></p>
            <p className="pl-8"><b>10.4.4. </b>You certify that You understand that it is Your responsibility to determine and provide the
            appropriate export classification for the products and related technology and software to be
            provided to 8xParts and to comply with prohibition on Export Controlled Data provided herein.
            8xParts relies entirely on You to provide accurate information for purposes of compliance with
            applicable export control laws. The export classification indicates whether the product and
            related technologies are controlled, the relevant jurisdiction or jurisdictions, when an export
            license is required, and whether the product and technology qualify for a license exception. An
            incorrect classification could result in export control violations, which could in turn lead to
            significant fines and other sanctions.<br/></p>
            <p className="pl-8"><b>10.4.5. </b>You represent and warrant that the production, shipping, sale and use of the Parts or
            tooling by us in response to Your Order, does not violate any export control laws or regulations.<br/></p>
            <p className="pl-8"><b>10.4.6. </b>You represent and warrant that You will not, directly or indirectly, (i) sell, export, reexport,
            transfer, divert, or otherwise dispose of any products, software, or technology (including
            products derived from or based on such technology) received from 8xParts to any destination,
            entity, or person prohibited by the laws or regulations of the U.S. and/or Your local jurisdiction or
            (ii) use Parts for any use prohibited by the laws or regulations of the U.S. and/or Your local
            jurisdiction, without obtaining prior authorization from the competent government authorities as
            required by those laws and regulations.<br/></p>
            <p className="pl-8"><b>10.4.7. </b>You may not use 8xParts&apos; services if You are the subject of U.S. sanctions or of
            sanctions consistent with U.S. law imposed by the governments of the country where You are
            using 8xParts&apos; services.<br/></p>
            <p className="pl-4"><b>10.5. </b>You further represent and warrant that Your uploaded data (including 3D CAD data and
            drawings) and/or Your Order comply with, and do not violate, the following 8xParts content
            policy (the &quot;Content Policy&quot;). You represent and warrant that Your uploaded data (including 3D
            CAD data and drawings), Your Order and/or the production, shipping, sale and use of the Parts
            or tooling by us:<br/></p>
            <p className="pl-8"><b>10.5.1. </b>Does not contain any weapons. Weapons is broadly defined as:
            Firearms, firearm component parts, or ammunition. This includes (1) any device which will or is
            designed to or may readily be converted to expel a projectile by the action of an explosive; (2)
            any device capable of being concealed on the person from which a shot can be discharged
            through the energy of an explosive; (3) any component part integral to the safe firing of a
            projectile by means of an explosive from a device described in (1) or (2); and (4) ammunition
            including cartridge cases, primers, bullets, or propellent powder designed for use in any firearm;
            Bladed weapons. This includes knives designed to cause bodily harm and any part or
            component thereof. A bladed weapon includes automatic knives, knives that are undetectable
            by a metal detector, stilettos, switchblades, butterfly knives, throwing knives, folding knives,
            gravity knives, and disguised knives (for example, a sword cane).
            Explosive devices. This includes grenades, rockets, explosives, incendiary devices, missiles,
            land mines, and related parts or components thereof;
            Toy guns or other items with arms-like appearance. This includes paintball guns, airsoft guns,
            training weapons, mock guns, mock weapons, weapon replicas and items that look like a gun or
            other weapon; and
            Arms-related items and/or weapon accessories. Accessories, parts or components to any
            weapon if that accessory/part/component contributes to the functioning of the weapon and/or
            attaches to the item. For example, this includes scopes, mounts and knife handles because they
            are attached to a weapon but would not include a knife case or holster because they are neither
            attached to nor contribute to the functioning of the weapon.<br/></p>
            <p className="pl-8"><b>10.5.2. </b>Does not contain any critical (functional) parts for aerospace, watercraft, offshore,
            automotive and or medical applications;<br/></p>
            <p className="pl-8"><b>10.5.3. </b> Does not violate, misappropriate or infringe any intellectual party rights (including but not
            limited to any copyright, patent, design right, trademark, trade secret or any other proprietary
            rights) or any third-party rights;<br/></p>
            <p className="pl-8"><b>10.5.4. </b>Does not contain information, which is false, inaccurate, misleading, harassing, racially
            or ethnically offensive, discriminatory, harmful to minors, libelous or defamatory, including
            information used to produce counterfeit goods;<br/></p>
            <p className="pl-8"><b>10.5.5. </b>Is not contrary to or in violation of any applicable law or regulations or public policy; and<br/></p>
            <p className="pl-8"><b>10.5.6. </b>Does not violate our Export Control Policy.<br/></p>
            <p className="pl-4"><b>10.6. </b>Please be informed that the uploading of data (including 3D CAD data and drawings) to
            manufacture firearm may be punishable by law. 8xParts has a (statutory) obligation to report
            data and/or Orders for firearms that it considers reasonably suspicious.<br/></p>
            <p className="pl-4"><b>10.7. </b>8xParts reserves the right to reject any Order that is based on data it feels—in its
            discretion—violates this Content Policy. It is and remains Your sole responsibility to comply with
            this Content Policy when uploading data to our website and placing Orders. 8xParts is not
            obliged to check the uploaded data before accepting or executing any Order or having the Parts
            manufactured by its manufacturing partners.<br/></p>
            <p className="pl-4"><b>10.8. </b>IF YOU HAVE ANY DOUBT WHETHER YOUR DATA (INCLUDING 3D CAD DATA AND
            DRAWINGS) YOUR ORDER AND/OR THE PRODUCTION, SHIPPING, SALE AND USE OF
            THE PARTS OR TOOLING BY US IS PERMITTED UNDER OUR CONTENT POLICY, DO NOT
            UPLOAD YOUR DATA.<br/></p>
            <p className="pl-4"><b>10.9. </b>We reserve the right (but have no obligation) to review any data provided by You, and to
            investigate and/or take appropriate action against You in our sole discretion if You violate our
            Content Policy, any other provision of these General Terms of Sale or otherwise create liability
            for us or any other person. Such action may include removing or modifying Your data,
            terminating Your account, and/or reporting You to law enforcement authorities. Any attempt by
            You to damage our website or to undermine the legitimate operations of 8xParts&apos; business or
            services may be a violation of criminal and civil laws and should any such attempt be made; we
            reserve the right to seek damages from You to the fullest extent permitted by law.<br/><br/></p>
            
            <b>11. Force Majeure</b>
            <br/>
            <p className="pl-4"><b>11.1. </b>8xParts shall not be responsible for any delay or failure in delivery or performance of any
            of its duties under any Order due to events beyond its reasonable control or acts or omissions
            or any other occurrence commonly known as force majeure, including but not limited to war,
            riots, acts of terrorism, acts of God, pandemics, nature disasters, embargoes, strikes, or other
            concerted acts of workers, casualties or accidents, failure by any 8xParts&apos; manufacturing partner
            to meet their obligations or any other causes or circumstances that prevent or hinder the
            manufacture or delivery of the Parts.<br/></p>
            <p className="pl-4"><b>11.2. </b>8xParts may suspend performance under an Order for so long as such performance is
            delayed by such occurrence or cancel the Order at its sole discretion, in which case 8xParts is
            not liable for any resulting damages.<br/></p>
            <p className="pl-4"><b>11.3. </b>Nothing in this Section 11 will excuse You from Your payment obligations for amounts due
            and payable under an Order.<br/><br/></p>
            
            <b>12. DISCLAIMER OF WARRANTIES</b>
            <br/>
            <p className="pl-4"><b>12.1. </b>ANY PARTS OR TOOLING IS PROVIDED ON AN &quot;AS-IS&quot; AND &quot;AS AVAILABLE&quot; BASIS,
            AND, TO THE EXTENT PERMITTED BY APPLICABLE LAW, 8xParts (AND OUR
            MANUFACTURING PARTNERS) EXPRESSLY DISCLAIM ANY AND ALL WARRANTIES AND
            CONDITIONS OF ANY KIND, WHETHER EXPRESS, IMPLIED, CONTRACTUAL OR
            STATUTORY, INCLUDING BUT NOT LIMITED TO ALL WARRANTIES, REPRESENTATIONS,
            GUARANTEES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
            PURPOSE, TITLE, QUIET ENJOYMENT, ACCURACY, OR NON-INFRINGEMENT. IF
            MANDATORY LAW REQUIRES ANY (STATUTORY) WARRANTIES WITH RESPECT TO THE
            PARTS OR TOOLING, ALL SUCH WARRANTIES ARE LIMITED IN DURATION TO NINETY
            (90) DAYS FROM THE DATE OF DELIVERY.<br/></p>
            <p className="pl-4"><b>12.2. </b>You hereby release and forever discharge 8xParts (and our officers, employees, agents,
            successors, and assigns) from, and hereby waive and relinquish, each and every past, present
            and future dispute, claim, controversy, demand, right, obligation, liability, action and cause of
            action of every kind and nature (including personal injuries, death, and property damage), that
            has arisen or arises directly or indirectly out of, or that relates directly or indirectly to, the Parts
            and/or Your Order.<br/></p>
            <p className="pl-4"><b>12.3. </b>In the event that mandatory law does not allow any of the exclusions or limitations of
            liability or any of the disclaimers of warranties mentioned in these General Terms of Sale, such
            exclusions, limitations or disclaimers shall be limited to the maximum extent permitted by
            applicable law.<br/></p>
            <p className="pl-4"><b>12.4. </b>No advice or information, whether oral or written, obtained from 8xParts, through the
            website or any representative will create any warranty not expressly made herein.<br/><br/></p>
            
            <b>13. LIMITATION OF LIABILITY</b>
            <br/>
            <p className="pl-4"><b>13.1. </b>TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAW, AND SUBJECT
            TO THE FINAL PARAGRAPH OF THIS SECTION, 8xParts (AND OUR MANUFACTURING
            PARTNERS) DO(ES) NOT ACCEPT LIABILITY FOR PARTS NOT BEING AVAILABLE FOR
            USE, OR FOR LOST REVENUE OR PROFITS OR LOSS OF BUSINESS OR OTHER
            ECONOMIC LOSS.<br/></p>
            <p className="pl-4"><b>13.2. </b>TO THE MAXIMUM EXTENT PERMITTED UNDER APPLICABLE LAW, AND SUBJECT
            TO THE FINAL PARAGRAPH OF THIS SECTION, 8xParts (AND OUR MANUFACTURING
            PARTNERS) WILL NOT BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY CLAIMS,
            ACTIONS, INJURY, PERSONAL INJURY OR DEATH, LOST PROFITS, LOST DATA, LOST
            INCOME, LOSS OR DAMAGE TO PROPERTY, COSTS OF PROCUREMENT OR
            SUBSTITUTE PRODUCTS OR ANY DIRECT OR INDIRECT, COMPENSATORY,
            CONSEQUENTIAL, EXEMPLARY, INCIDENTAL, SPECIAL OR PUNITIVE DAMAGES UNDER
            ANY LEGAL THEORY OR FORM OF ACTION (INCLUDING BUT NOT LIMITED TO
            CONTRACT, NEGLIGENCE, STRICT LIABILITY IN TORT OR WARRANTY OF ANY KIND)
            ARISING OUT OF OR RELATED TO PARTS, TOOLING, ORDERS, DELIVERY, OR
            OTHERWISE RELATING THESE GENERAL TERMS OF SALE, EVEN IF ADVISED OF THE
            POSSIBILITY OF SUCH DAMAGE, OR FOR ANY CLAIM BY ANY THIRD PARTY.<br/></p>
            <p className="pl-4"><b>13.3. </b>TO THE MAXIMUM EXTENT PERMITTED BY LAW, NOTWITHSTANDING ANYTHING
            TO THE CONTRARY CONTAINED HEREIN, OUR LIABILITY TO YOU FOR ANY DAMAGES
            ARISING FROM OR RELATED TO ANY ORDER AND/OR THESE GENERAL TERMS OF
            SALE (FOR ANY CAUSE WHATSOEVER AND REGARDLESS OF THE FORM OF THE
            ACTION), WILL AT ALL TIMES BE LIMITED TO A MAXIMUM OF THE AMOUNT PAID BY YOU
            TO US UNDER THE ORDER UNDER WHICH THE LIABILITY AROSE. THE EXISTENCE OF
            MORE THAN ONE CLAIM WILL NOT ENLARGE THIS LIMIT. YOU AGREE THAT OUR
            MANUFACTURING PARTNERS WILL HAVE NO LIABILITY OF ANY KIND ARISING FROM OR
            RELATING TO THESE GENERAL TERMS OF SALE.<br/></p>
            <p className="pl-4"><b>13.4. </b>Because some jurisdictions limit or do not allow certain exclusions or limitations of
            warranties or liability, Sections 12 and/or 13 may not partially or entirely apply to You. To the
            extent that any such limitation or exclusion of liability or warranty is circumscribed, it shall be
            limited to the least extent possible under applicable law.<br/><br/></p>
            
            <b>14. Indemnification</b>
            <br/>
            <p className="pl-4"><b>14.1. </b>You agree to indemnify and hold 8xParts (and its officers, directors, employees,
            representatives and agents), its affiliates (and their officers, directors, employees,
            representatives and agents), and its and its affiliates&apos; (sub)contractors (including manufacturing
            partners) harmless from and against any and all loss, liability, penalty, third party claims,
            damages, demands, costs and other expenses (including reasonable attorneys&apos; fees and court
            costs and litigation expenses) arising out of or relating to:
            <br/>(a) Your breach of these General Terms of Sale;
            <br/>(b) Your violation of any law or the rights of a third party;
            <br/>(c) Your use of our website;
            <br/>(d) Your data (including 3D CAD data and drawings);
            <br/>(e) The manufacture of Parts based on Your data;
            <br/>(f) The Parts manufactured for You;
            <br/>(g) Your use of the Parts; and
            <br/>(h) Your Order.<br/></p>
            <p className="pl-4"><b>14.2. </b>You will, if instructed by us, defend us from any third party claim covered by the indemnity
            under Section 14.1 (&quot;Third Party Claim&quot;), at Your expense, using counsel reasonably acceptable
            to us. You will not consent to any settlement or judgment of any Third Party Claim without our
            prior written consent. We may participate in the defense of any Third Party Claim with our own
            counsel at our own expense.<br/></p>
            <p className="pl-4"><b>14.3. </b>8xParts reserves the right, at Your expense, to assume the exclusive defense and control
            of any matter for which You are required to indemnify us, and You agree to cooperate with our
            defense of these claims. You agree not to settle any matter without our prior written consent. We
            will use reasonable efforts to notify You of any such claim, action or proceeding upon becoming
            aware of it.<br/><br/></p>
            
            <b>15. Confidentiality</b>
            <br/>
            <p className="pl-4"><b>15.1. </b>8xParts shall not disclose, and shall procure that its employees and (sub)contractors shall
            not disclose, any data (including 3D CAD data), documentation, drawings and specifications
            provided by You, other than (i) to its affiliates and (sub)contractors as necessary to produce,
            ship and sell the Parts to You and (ii) to improve our products and services. This restriction will
            not apply in the event of a legal obligation or duty to disclose the information, or when the
            information is or becomes (publicly) known or is independently developed by 8xParts, its
            employees or its contractors without the use of such information, or if the information is
            disclosed to 8xParts by a third party.<br/></p>
            <p className="pl-4"><b>15.2. </b>You are not allowed to use 8xParts trademarks, trade names or any other indications in
            relation to the Parts, or to publicly make any reference to 8xParts, whether in press releases,
            advertisements, sales literature or otherwise, except with 8xParts prior written consent.<br/><br/></p>

            <b>16. Termination</b>
            <br/>
            <p className="pl-4"><b>16.1. </b>Without prejudice to any other rights 8xParts may have under these General Terms of
            Sale or the applicable laws, 8xParts has the right to immediately terminate Your Order and/or
            Your account in whole or in part if, in its sole discretion:
            <br/></p>
            <p className="pl-8"><b>a. </b>You are declared bankrupt, are granted a (temporary) moratorium on payment of Your debts,
            if You have filed a petition for bankruptcy or if a receiver is appointed for You,
            <br/></p>
            <p className="pl-8"><b>b. </b>You go into liquidation or there is a threat of suspension of payments,
            <br/></p>
            <p className="pl-8"><b>c. </b>You cease, or threaten to cease, to carry on Your business,
            <br/></p>
            <p className="pl-8"><b>d. </b>You or Your representatives makes any libelous or slanderous statement, or is hostile or
            abusive against 8xParts, its employees or its representatives; or
            <br/></p>
            <p className="pl-8"><b>e. </b>You breach these General Terms of Sale.
            <br/></p>
            <p className="pl-4"><b>16.2. </b>Upon termination pursuant to Section 16.1, 8xParts shall not have any liability for or
            obligation to deliver the Parts. Any amounts that You paid 8xParts are non-refundable, and any
            amounts that You still owe 8xParts under the Order become immediately due and payable in
            full.
            <br/></p>
            <p className="pl-4"><b>16.3. </b>Except as otherwise expressly provided in these General Terms of Sale, You are not
            entitled to terminate an Order.
            <br/><br/></p>
            
            <b>17. Miscellaneous</b>
            <br/>
            <p className="pl-4"><b>17.1. </b>If any provision of these General Terms of Sale is, for any reason, held to be invalid or
            unenforceable, the other provisions of these General Terms of Sale will be unimpaired and the
            invalid or unenforceable provision will be deemed modified so that it most closely matches the
            original provision and is valid and enforceable to the maximum extent permitted by law. The
            remaining provisions shall be enforced.
            <br/></p>
            <p className="pl-4"><b>17.2. </b>These General Terms of Sale shall be construed as if both parties drafted it jointly and
            shall not be construed against either party as principal drafter.
            <br/></p>
            <p className="pl-4"><b>17.3. </b>A waiver by us of any right or remedy under these General Terms of Sale shall only be
            effective if it is in writing, executed by a duly authorized representative of ours and shall apply
            only to the circumstances for which it is given. Our failure to exercise or enforce any right or
            provision of these General Terms of Sale shall not operate as a waiver of such right or remedy,
            nor shall it prevent any future exercise or enforcement of such right or remedy. No single or
            partial exercise of any right or remedy shall preclude or restrict the further exercise of any such
            right or remedy or other rights or remedies.
            <br/></p>
            <p className="pl-4"><b>17.4. </b>Orders and these General Terms of Sale, including Your rights and obligations therein,
            may not be assigned, subcontracted, delegated, or otherwise transferred by You without our
            prior written consent, and any attempted assignment, subcontract, delegation, or transfer in
            violation of the foregoing will be null and void. 8xParts may freely assign any Order or these
            General Terms of Sale. The terms and conditions set forth in any Order or these General Terms
            of Sale shall be binding upon assignees.
            <br/></p>
            <p className="pl-4"><b>17.5. </b>All notices sent under these General Terms of Sale shall be in writing and delivered by
            prepaid commercial courier or by email. Notices to 8xParts shall be sent to [8xParts Address]
            and [email] and notices to You shall be sent to the contact person provided by You in Your
            Order. Notices are deemed delivered upon dispatch of mail or email.
            <br/></p>
            <p className="pl-4"><b>17.6. </b>These General Terms of Sale, together with an accepted Order, the Privacy Policy
            (defined below) and our 8xParts Terms of Use, constitute the entire agreement between the
            parties relating to the subject matter herein and supersedes all previous agreements,
            arrangements and undertakings between the parties with respect to that subject matter.
            <br/></p>
            <p className="pl-4"><b>17.7. </b>All provisions within these General Terms of Sale which by their nature are intended,
            whether express or implied, to survive the termination or the expiration of an Order, including
            but not limited to Your payment obligations and Sections 2 through 18 shall survive.
            <br/></p>
            <p className="pl-4"><b>17.8. </b>These General Terms of Sale are subject to occasional revision. If we make any
            substantial changes, we may notify You by sending You an e-mail to the last e-mail address You
            provided to us (if any), and/or by prominently posting notice of the changes on our website. You
            are responsible for providing us with Your most current e-mail address. In the event that the last
            e-mail address that You have provided us is not valid, or for any reason is not capable of
            delivering to You the notice described above, our dispatch of the e-mail containing such notice
            will nonetheless constitute effective notice of the changes described in the notice.
            <br/></p>
            <p className="pl-4"><b>17.9. </b>Copyright © 2024 8xParts Inc. All rights reserved. All trademarks, logos and service marks
            (&quot;Marks&quot;) displayed on our website or any Order are our property or the property of other third
            parties. You are not permitted to use these Marks without our prior written consent or the
            consent of such third party which may own the Marks.
            <br/><br/></p>
            
            <b>18. Governing Law and Exclusive Forum</b>
            <br/>
            <p className="pl-4"><b>18.1. </b>The laws of the State of New York will apply to any disputes arising out of or relating to
            these General Terms of Sale, without regard to conflict of laws principles. The applicability of the
            UN Convention on the International Sale of Goods is excluded.
            <br/></p>
            <p className="pl-4"><b>18.2. </b>Unless provided otherwise by operation of applicable mandatory law, any dispute, claim,
            clause of action or proceeding arising out of, or in connection with, these General Terms of Sale,
            the relationship between 8xParts and You or Your use of our services, on any basis whatsoever,
            shall be brought in the state or federal courts located in New York, New York, and the parties
            shall submit to the exclusive jurisdiction of such courts and waive any and all jurisdictional,
            venue and inconvenient forum objections to such courts.
            <br/></p>
            </p>
          </div>
        </section>

      {/* Footer with Comprehensive Sitemap */}
      <Footer />
    </div>
  );
};

export default TermsPage;
