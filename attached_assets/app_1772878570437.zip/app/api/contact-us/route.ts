import { NextResponse } from 'next/server';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import { isValidEmail } from '@/utils/helper';

const sesClient = new SESClient({
  region: process.env.AWS_SES_REGION,
  credentials: {
    accessKeyId: process.env.AWS_SES_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY!,
  },
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, company, projectDetails } = body;

    console.log('req.body',body)

    if (!name || !email || !isValidEmail(email)) {
      return NextResponse.json({ success: false, error: 'Invalid input data' }, { status: 400 });
    }

    const receiverEmails = process.env.RECEIVER_EMAIL?.split(',') || [];

    if (receiverEmails.length === 0) {
      return NextResponse.json({ success: false, error: 'No receiver email addresses configured' }, { status: 400 });
    }

    const emailBody = `
      Name: ${name}
      Email: ${email}
      Company: ${company || 'Not provided'}
      Project Details: ${projectDetails || 'Not provided'}
    `;

    const params = {
      Source: process.env.SENDER_EMAIL!,
      Destination: {
        ToAddresses: receiverEmails,
      },
      Message: {
        Subject: {
          Data: `New enquiry from ${name}`,
        },
        Body: {
          Text: {
            Data: emailBody,
          },
        },
      },
    };

    await sesClient.send(new SendEmailCommand(params));

    return NextResponse.json({ success: true, message: 'Thanks for sharing the details! One of our engineers will get in touch with you soon.' });
  } catch (error) {
    console.error('Error sending email:', error);
    return NextResponse.json({ success: false, error: 'Failed to send email' }, { status: 500 });
  }
}
