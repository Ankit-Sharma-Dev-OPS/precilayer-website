import { NextRequest, NextResponse } from "next/server";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

// Initialize AWS S3 client using SDK v3
const s3 = new S3Client({
  region: process.env.AWS_SES_REGION,
  credentials: {
    accessKeyId: process.env.AWS_SES_ACCESS_KEY_ID as string,
    secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY as string,
  },
});

const Bucket = process.env.AWS_S3_QUAOAR_BUCKET_NAME as string; // Bucket name

// Endpoint to upload a file to the bucket
export async function POST(request: NextRequest) {
  try {
    // Parse form data and extract the file
    const formData = await request.formData();
    const files = formData.getAll("file") as File[];

    const response = await Promise.all(
      files.map(async (file) => {
        const arrayBuffer = await file.arrayBuffer();
const Body = Buffer.from(arrayBuffer);
        
        const fileKey = `file-uploaded-for-calendly/${Date.now()}_${file.name}`;
        
        // Upload file to S3
        await s3.send(
          new PutObjectCommand({
            Bucket,
            Key: fileKey,
            Body,
          })
        );

        // Generate the public URL for the uploaded file
        const fileUrl = `https://${Bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${fileKey}`;

        return { fileName: file.name, fileUrl }; 
      })
    );

    // Return success response with file metadata
    return NextResponse.json({ success: true, message: "Files uploaded successfully", files: response });
  } catch (error) {
    console.error("Error uploading files:", error);
    return NextResponse.json({ success: false, error: "Failed to upload files" }, { status: 500 });
  }
}
