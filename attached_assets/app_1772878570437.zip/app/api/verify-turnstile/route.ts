import { NextResponse } from 'next/server';
import axios from 'axios';

interface TurnstileResponse {
  success: boolean;
  'error-codes'?: string[];
}

export async function POST(req: Request) {
  const { token } = await req.json(); // Parse the incoming request body

  // Ensure that the token is provided
  if (!token) {
    return NextResponse.json(
      { success: false, error: 'Token is required' },
      { status: 400 }
    );
  }

  try {
    // Send the token to Turnstile's verification endpoint
    const response = await axios.post<TurnstileResponse>(
      'https://challenges.cloudflare.com/turnstile/v0/siteverify',
      new URLSearchParams({
        secret: process.env.TURNSTILE_SECRET_KEY || '',  // Use your Turnstile secret key here
        response: token,
      })
    );

    const data = response.data;

    if (data.success) {
      // Verification was successful
      return NextResponse.json({ success: true });
    } else {
      // Verification failed, optionally log the error codes
      console.error('Turnstile verification failed:', data['error-codes']);
      return NextResponse.json(
        { success: false, error: 'Turnstile verification failed' },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Error verifying Turnstile token:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
