import { NextResponse } from 'next/server';
import { SESClient, SendEmailCommand } from '@aws-sdk/client-ses';
import axios from 'axios';
import { isValidEmail } from '@/utils/helper';

const sesClient = new SESClient({
  region: process.env.AWS_SES_REGION,
  credentials: {
    accessKeyId: process.env.AWS_SES_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY!,
  },
});

// export async function POST(req: Request) {
//   try {
//     const body = await req.json();
//     const { email } = body;

//     const ip = req.headers.get('x-forwarded-for') || req.headers.get('host');
//     let location = 'Location could not be determined';
//     try {
//       const ipResponse = await axios.get(`http://ip-api.com/json/${ip}`);

//       if (ipResponse.data && ipResponse.data.city) {
//         location = `${ipResponse.data.city}, ${ipResponse.data.country}`;
//       }
//     } catch (error) {
//       console.error('Error fetching location:', error);
//     }

//     if (!email || !isValidEmail(email)) {
//       return NextResponse.json({ success: false, error: 'Invalid email address' }, { status: 400 });
//     }

//     const receiverEmails = process.env.RECEIVER_EMAIL?.split(',') || [];

//     if (receiverEmails.length === 0) {
//       return NextResponse.json({ success: false, error: 'No receiver email addresses configured' }, { status: 400 });
//     }

//     const emailBody = `
//       Hi,

//       A new email has subscribed on 8xparts.com.

//       Email Id: ${email}
//       IP: ${ip || 'Not available'}
//       Location: ${location}
//     `;

//     const params = {
//       Source: process.env.SENDER_EMAIL!,
//       Destination: {
//         ToAddresses: receiverEmails,
//       },
//       Message: {
//         Subject: {
//           Data: 'New Subscriber',
//         },
//         Body: {
//           Text: {
//             Data: emailBody,
//           },
//         },
//       },
//     };

//     await sesClient.send(new SendEmailCommand(params));

//     return NextResponse.json({ success: true });
//   } catch (error) {
//     console.error('Error sending email:', error);
//     return NextResponse.json({ success: false, error: 'Failed to send email' }, { status: 500 });
//   }
// }

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email } = body;
    // Extract IP and location from Cloudflare headers
    const ip = req.headers.get('cf-connecting-ip') || 'Unknown IP';
    const city = req.headers.get('cf-city') || 'Unknown City';
    const country = req.headers.get('cf-ipcountry') || 'Unknown Country';
    const location = `${city}, ${country}`;
    if (!email || !isValidEmail(email)) {
      return NextResponse.json({ success: false, error: 'Invalid email address' }, { status: 400 });
    }
    const receiverEmails = process.env.RECEIVER_EMAIL?.split(',') || [];
    if (receiverEmails.length === 0) {
      return NextResponse.json({ success: false, error: 'No receiver email addresses configured' }, { status: 400 });
    }
    const emailBody = `
      Hi,
      A new email has subscribed on 8xparts.com.
      Email Id: ${email}
      IP: ${ip || 'Not available'}
      Location: ${location}
    `;
    const params = {
      Source: process.env.SENDER_EMAIL!,
      Destination: {
        ToAddresses: receiverEmails,
      },
      Message: {
        Subject: {
          Data: 'New Subscriber',
        },
        Body: {
          Text: {
            Data: emailBody,
          },
        },
      },
    };
    await sesClient.send(new SendEmailCommand(params));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error sending email:', error);
    return NextResponse.json({ success: false, error: 'Failed to send email' }, { status: 500 });
  }
}









